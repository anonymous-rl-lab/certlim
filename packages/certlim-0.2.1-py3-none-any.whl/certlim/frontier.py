"""Certification frontier over a grid of block lengths."""

from __future__ import annotations

from dataclasses import asdict, dataclass

from .core import ZERO_TOL, StateSpaceTooLarge
from .experiment import Experiment

__all__ = ["FrontierPoint", "Frontier", "frontier"]


@dataclass(frozen=True)
class FrontierPoint:
    """One block length on the certification frontier."""

    n: int
    states: int
    delta: float
    decisiveness: float
    bound: float
    slack: float
    margin: float
    gate: int

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class Frontier:
    """The frontier over an ``n``-grid, plus the checks it makes available."""

    points: tuple[FrontierPoint, ...]
    alpha: float
    beta: float
    skipped: tuple[tuple[int, str], ...] = ()

    def __iter__(self):
        return iter(self.points)

    def __len__(self) -> int:
        return len(self.points)

    @property
    def n_grid(self) -> tuple[int, ...]:
        return tuple(p.n for p in self.points)

    def bound_holds(self, tol: float = ZERO_TOL) -> bool:
        """Whether decisiveness stays under the certification bound at every point.

        A violation means a numerical fault, not a counterexample: the bound is a
        theorem. Treat a ``False`` here as a bug report.
        """
        return all(p.decisiveness <= p.bound + tol for p in self.points)

    def max_excess(self) -> float:
        """Largest amount by which decisiveness exceeds its bound (negative is good)."""
        return max((p.decisiveness - p.bound for p in self.points), default=float("-inf"))

    def is_monotone(self, tol: float = ZERO_TOL) -> bool:
        """Whether ``Delta`` and decisiveness are non-decreasing across the grid.

        Both grow with ``n``: more units can only sharpen the separation, and any
        rule may ignore the extra units.
        """
        deltas = [p.delta for p in self.points]
        ds = [p.decisiveness for p in self.points]
        return all(b - a >= -tol for a, b in zip(deltas, deltas[1:])) and all(
            b - a >= -tol for a, b in zip(ds, ds[1:])
        )

    def units_for(self, target: float) -> int | None:
        """Smallest gridded block length reaching ``target`` decisiveness, if any.

        Evaluated at the ``alpha`` and ``beta`` this frontier was computed with;
        a different error budget needs a new frontier.
        """
        if not 0.0 < target <= 1.0:
            raise ValueError("target decisiveness must lie in (0, 1]")
        for p in self.points:
            if p.decisiveness >= target:
                return p.n
        return None

    def to_records(self) -> list[dict]:
        return [p.as_dict() for p in self.points]

    def to_csv(self, path) -> None:
        import csv

        rows = self.to_records()
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    def __str__(self) -> str:
        head = f"{'n':>4} {'states':>8} {'Delta':>9} {'D':>9} {'bound':>9} {'slack':>9} {'gate':>5}"
        body = "\n".join(
            f"{p.n:>4} {p.states:>8} {p.delta:>9.6f} {p.decisiveness:>9.6f} "
            f"{p.bound:>9.6f} {p.slack:>9.6f} {p.gate:>5}"
            for p in self.points
        )
        tail = ""
        if self.skipped:
            tail = "\n" + "\n".join(f"  n={n} skipped: {why}" for n, why in self.skipped)
        return f"{head}\n{body}{tail}"


def frontier(
    experiment: Experiment,
    n_grid=(1, 2, 3, 4, 5, 6, 8, 10),
    alpha: float = 0.05,
    beta: float = 0.05,
    *,
    skip_oversized: bool = True,
) -> Frontier:
    """Compute ``Delta(n)``, exact decisiveness and the bound over ``n_grid``.

    The grid is sorted and de-duplicated first, so :meth:`Frontier.is_monotone`
    tests the quantities rather than the order they were requested in.

    Points whose exact enumeration would exceed the experiment's ``max_states``
    are skipped and listed, rather than silently truncating the grid.
    """
    grid = sorted({int(n) for n in n_grid})
    if not grid:
        raise ValueError("n_grid is empty")
    if grid[0] < 1:
        raise ValueError(f"block lengths must be at least 1; got {grid[0]}")
    points: list[FrontierPoint] = []
    skipped: list[tuple[int, str]] = []
    for n in grid:
        try:
            delta = experiment.delta(n)
            dec = experiment.decisiveness(n, alpha, beta)
        except StateSpaceTooLarge as exc:
            if not skip_oversized:
                raise
            skipped.append((n, str(exc)))
            continue
        bound = min(1.0, alpha + beta + delta)
        points.append(
            FrontierPoint(
                n=n,
                states=experiment.state_count(n),
                delta=delta,
                decisiveness=dec,
                bound=bound,
                slack=bound - dec,
                margin=0.5 * delta,
                gate=experiment.gate(n),
            )
        )
    if not points:
        raise ValueError("no grid point could be evaluated; lower n or coarsen the alphabet")
    return Frontier(tuple(points), alpha=alpha, beta=beta, skipped=tuple(skipped))
