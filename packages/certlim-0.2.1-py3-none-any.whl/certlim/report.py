"""Single-file HTML certification report.

Assembles the diagnosis, the frontier, the finite-sample calibration and the
deployable rule into one page that can be filed as an audit record.

The output is self-contained: no external stylesheet, script, font or image, so
it survives being emailed, archived or opened on an air-gapped machine. It is
also byte-deterministic for a given set of inputs unless a ``timestamp`` is
supplied, so two runs of the same analysis produce the same file and a diff
means something changed.
"""

from __future__ import annotations

import html
from dataclasses import dataclass

import numpy as np

from .calibration import BootstrapResult, PermutationResult, bootstrap_delta, permutation_test
from .core import StateSpaceTooLarge
from .experiment import Experiment
from .frontier import Frontier, frontier as build_frontier
from .rules import ThreeStateRule, build_rule

__all__ = ["ReportData", "build", "write"]

_E = html.escape


# --------------------------------------------------------------------- assembly
@dataclass(frozen=True)
class ReportData:
    """Everything the page renders, gathered before any HTML is produced."""

    experiment: Experiment
    diagnosis: object
    frontier: Frontier
    rule: ThreeStateRule
    permutation: PermutationResult | None
    bootstrap: BootstrapResult | None
    title: str
    subject: str | None
    timestamp: str | None
    notes: tuple[str, ...]


def _gather(
    experiment: Experiment,
    *,
    n_grid,
    alpha: float,
    beta: float,
    rule_n: int | None,
    unit_counts,
    labels,
    blocks,
    smoothing: float,
    n_permutations: int,
    n_resamples: int,
    seed: int,
    title: str,
    subject: str | None,
    timestamp: str | None,
    notes,
) -> ReportData:
    diagnosis = experiment.diagnose()
    front = build_frontier(experiment, n_grid=n_grid, alpha=alpha, beta=beta)

    if rule_n is None:
        target = diagnosis.n_star if diagnosis.n_star else front.n_grid[-1]
        rule_n = min(target, front.n_grid[-1])
    try:
        rule = build_rule(experiment, n=rule_n, alpha=alpha, beta=beta)
    except StateSpaceTooLarge:
        rule = build_rule(experiment, n=front.n_grid[0], alpha=alpha, beta=beta)

    perm = boot = None
    if unit_counts is not None and labels is not None:
        perm = permutation_test(unit_counts, labels, blocks=blocks, smoothing=smoothing,
                                n_permutations=n_permutations, seed=seed)
        boot = bootstrap_delta(unit_counts, labels, smoothing=smoothing,
                               n_resamples=n_resamples, seed=seed)
    return ReportData(
        experiment=experiment, diagnosis=diagnosis, frontier=front, rule=rule,
        permutation=perm, bootstrap=boot, title=title, subject=subject,
        timestamp=timestamp, notes=tuple(notes or ()),
    )


# ------------------------------------------------------------------------ chart
def _chart(front: Frontier) -> str:
    """Inline SVG of Delta, decisiveness and the bound against block length."""
    pts = list(front.points)
    if len(pts) < 2:
        return '<p class="muted">A single grid point: nothing to plot.</p>'

    w, h = 640, 260
    ml, mr, mt, mb = 46, 108, 14, 34
    pw, ph = w - ml - mr, h - mt - mb
    xs = [p.n for p in pts]
    x0, x1 = min(xs), max(xs)
    y1 = max(1.0, max(p.bound for p in pts))

    def px(n): return ml + (n - x0) / max(x1 - x0, 1) * pw
    def py(v): return mt + (1 - v / y1) * ph

    def path(values, klass):
        d = " ".join(("M" if i == 0 else "L") + f"{px(n):.1f},{py(v):.1f}"
                     for i, (n, v) in enumerate(zip(xs, values)))
        return f'<path class="{klass}" d="{d}"/>'

    grid, ticks = [], []
    for frac in (0.0, 0.25, 0.5, 0.75, 1.0):
        v = frac * y1
        y = py(v)
        grid.append(f'<line class="grid" x1="{ml}" y1="{y:.1f}" x2="{ml+pw}" y2="{y:.1f}"/>')
        ticks.append(f'<text class="tick" x="{ml-8}" y="{y+3.5:.1f}" text-anchor="end">{v:.2f}</text>')
    for n in xs:
        ticks.append(f'<text class="tick" x="{px(n):.1f}" y="{mt+ph+18}" text-anchor="middle">{n}</text>')

    dots = "".join(
        f'<circle class="dot-{k}" cx="{px(p.n):.1f}" cy="{py(v):.1f}" r="2.6"/>'
        for k, series in (("bound", [p.bound for p in pts]),
                          ("delta", [p.delta for p in pts]),
                          ("dec", [p.decisiveness for p in pts]))
        for p, v in zip(pts, series)
    )
    legend = "".join(
        f'<line class="{k}" x1="{ml+pw+14}" y1="{mt+8+i*20}" x2="{ml+pw+34}" y2="{mt+8+i*20}"/>'
        f'<text class="legend" x="{ml+pw+40}" y="{mt+12+i*20}">{lab}</text>'
        for i, (k, lab) in enumerate((("bound", "bound α+β+Δ"), ("delta", "Δ(n)"),
                                      ("dec", "𝒟(n) attained"))))
    return (
        f'<svg class="chart" viewBox="0 0 {w} {h}" role="img" '
        f'aria-label="Certification frontier against block length">'
        + "".join(grid)
        + path([p.bound for p in pts], "bound")
        + path([p.delta for p in pts], "delta")
        + path([p.decisiveness for p in pts], "dec")
        + dots + "".join(ticks) + legend
        + f'<text class="axis" x="{ml+pw/2:.0f}" y="{h-4}" text-anchor="middle">'
          f'independent evidence units n</text></svg>'
    )


# ------------------------------------------------------------------------- CSS
_CSS = """
:root{--ink:#1a1d21;--mute:#666d75;--line:#dde1e6;--bg:#fff;--panel:#f7f8fa;
--ok:#2f6b4f;--warn:#8a6d1f;--stop:#9c3a35;--delta:#2f5d8c;--dec:#39735a;--bound:#a64b47}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]){--ink:#e8eaed;--mute:#9aa2ab;
--line:#343a41;--bg:#16181c;--panel:#1e2126;--ok:#6fc09a;--warn:#d8b45a;--stop:#e0827c;
--delta:#7fb2e5;--dec:#7fc8a6;--bound:#e69b96}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.wrap{max-width:52rem;margin:0 auto;padding:2.5rem 1.5rem 4rem}
h1{font-size:1.5rem;margin:0 0 .3rem;letter-spacing:-.01em}
h2{font-size:1.05rem;margin:2.4rem 0 .7rem;padding-bottom:.35rem;border-bottom:1px solid var(--line)}
h3{font-size:.93rem;margin:1.4rem 0 .4rem}
p{margin:.6rem 0}
.muted{color:var(--mute);font-size:.87rem}
.meta{display:grid;grid-template-columns:auto 1fr;gap:.15rem 1rem;font-size:.85rem;
color:var(--mute);margin:.8rem 0 0}
.meta b{font-weight:600;color:var(--ink)}
code,.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:.85em}
.verdict{margin:1.6rem 0;padding:1rem 1.15rem;border-radius:6px;border:1px solid var(--line);
background:var(--panel);border-left:4px solid var(--mute)}
.verdict.ok{border-left-color:var(--ok)} .verdict.warn{border-left-color:var(--warn)}
.verdict.stop{border-left-color:var(--stop)}
.verdict .tag{font-size:.72rem;letter-spacing:.09em;text-transform:uppercase;font-weight:700}
.verdict.ok .tag{color:var(--ok)} .verdict.warn .tag{color:var(--warn)}
.verdict.stop .tag{color:var(--stop)}
.verdict p{margin:.4rem 0 0}
table{border-collapse:collapse;width:100%;font-size:.87rem;margin:.7rem 0}
th,td{padding:.36rem .55rem;border-bottom:1px solid var(--line);text-align:right}
th:first-child,td:first-child{text-align:left}
thead th{font-weight:600;font-size:.78rem;letter-spacing:.03em;text-transform:uppercase;
color:var(--mute)}
tbody tr:last-child td{border-bottom:none}
.kv{display:grid;grid-template-columns:auto 1fr;gap:.2rem .9rem;font-size:.88rem;margin:.6rem 0}
.kv b{font-weight:600}
.scroll{overflow-x:auto}
.chart{width:100%;height:auto;margin:.6rem 0 .2rem}
.chart .grid{stroke:var(--line);stroke-width:1}
.chart path{fill:none;stroke-width:1.8}
.chart .delta,.chart .dot-delta{stroke:var(--delta)} .chart .dot-delta{fill:var(--delta)}
.chart .dec,.chart .dot-dec{stroke:var(--dec)} .chart .dot-dec{fill:var(--dec)}
.chart .bound,.chart .dot-bound{stroke:var(--bound)} .chart .dot-bound{fill:var(--bound)}
.chart .bound{stroke-dasharray:5 3}
.chart .tick,.chart .legend,.chart .axis{fill:var(--mute);font-size:10px;stroke:none;
font-family:inherit}
.note{border-left:3px solid var(--line);padding:.1rem 0 .1rem .85rem;color:var(--mute);
font-size:.87rem;margin:.9rem 0}
footer{margin-top:3rem;padding-top:.9rem;border-top:1px solid var(--line);
color:var(--mute);font-size:.8rem}
@media print{body{background:#fff;color:#000}.wrap{max-width:none;padding:0}
h2{page-break-after:avoid}table,.verdict,.chart{page-break-inside:avoid}}
"""


# ------------------------------------------------------------------- rendering
def _verdict_block(data: ReportData) -> str:
    d = data.diagnosis
    kind = {"permanent": ("stop", "Permanent obstruction"),
            "delayed": ("warn", "Delayed separation"),
            "immediate": ("ok", "Immediate separation"),
            "undetermined": ("warn", "Undetermined")}[d.region]
    klass, label = kind
    action = {
        "permanent": "Change the acquisition protocol. More of this channel cannot help.",
        "delayed": f"Collect {d.n_star} independent units of this channel.",
        "immediate": "Structure is not the constraint; confidence, cost and transport are.",
        "undetermined": "Raise the state budget or coarsen the alphabet, then re-run.",
    }[d.region]
    return (
        f'<div class="verdict {klass}"><span class="tag">{_E(label)}</span>'
        f"<p>{_E(d.explain())}</p>"
        f'<p><b>Action:</b> {_E(action)}</p></div>'
    )


def _diagnosis_section(data: ReportData) -> str:
    d = data.diagnosis
    e = data.experiment
    ns, nu = e.n_models
    rows = [
        ("Evidence alphabet", f"{e.alphabet_size} symbols"),
        ("Registered models", f"{ns} safe, {nu} unsafe"),
        ("Δ(1), composite separation", f"{d.delta_one:.6f}"),
        ("Minimum pairwise TV", f"{d.pairwise_min_tv:.6f}"),
        ("Exact cross-grade collision", "yes" if d.exact_collision else "no"),
        ("n★, first separable block", "none" if d.n_star is None else str(d.n_star)),
        ("Structural search ceiling", f"{d.stopping_bound} (searched to {d.searched_to})"),
    ]
    body = "".join(f"<b>{_E(k)}</b><span>{_E(v)}</span>" for k, v in rows)
    extra = ""
    if d.collision_from_tied_counts:
        pairs = ", ".join(f"safe #{i} / unsafe #{j}" for i, j in d.collision_pairs[:4])
        extra += (
            '<div class="note"><b>Read the permanent verdict with care.</b> The colliding '
            f"models ({_E(pairs)}) have identical <em>observed counts</em>, not merely "
            "identical fitted laws. On a small alphabet with few draws per unit, two units "
            "from different populations tie by chance. If each registered model is a single "
            "physical unit rather than a cohort, aggregate first and re-run before treating "
            "this as a structural obstruction.</div>"
        )
    if d.delta_one <= 1e-9 < d.pairwise_min_tv:
        extra = (
            '<div class="note">Every safe/unsafe pair is separated, yet the two convex '
            "hulls still meet. A criterion built on pairwise distances would have "
            "reported success here; the composite geometry is what governs.</div>"
        )
    return f'<h2>1 · Structural diagnosis</h2><div class="kv">{body}</div>{extra}'


def _frontier_section(data: ReportData) -> str:
    f = data.frontier
    head = ("<thead><tr><th>n</th><th>states</th><th>Δ(n)</th><th>𝒟(n)</th>"
            "<th>bound</th><th>slack</th><th>gate</th></tr></thead>")
    rows = "".join(
        f"<tr><td>{p.n}</td><td>{p.states:,}</td><td>{p.delta:.6f}</td>"
        f"<td>{p.decisiveness:.6f}</td><td>{p.bound:.6f}</td><td>{p.slack:.6f}</td>"
        f"<td>{'closed' if p.gate else 'open'}</td></tr>" for p in f.points)
    checks = (
        f"Bound respected at every point: <b>{'yes' if f.bound_holds() else 'NO'}</b> "
        f"(largest excess {f.max_excess():.2e}). "
        f"Δ and 𝒟 non-decreasing: <b>{'yes' if f.is_monotone() else 'NO'}</b>."
    )
    skipped = ""
    if f.skipped:
        items = "".join(f"<li>n = {n}: {_E(why.split('.')[0])}</li>" for n, why in f.skipped)
        skipped = f'<div class="note">Grid points not evaluated:<ul>{items}</ul></div>'
    return (
        f"<h2>2 · Certification frontier</h2>"
        f'<p class="muted">Error budget α = {f.alpha:g}, β = {f.beta:g}. '
        f"𝒟 is the exact best worst-case decisiveness; the bound is what no rule can exceed.</p>"
        f"{_chart(f)}"
        f'<div class="scroll"><table>{head}<tbody>{rows}</tbody></table></div>'
        f"<p>{checks}</p>{skipped}"
        f'<div class="note">A violation of either check would indicate a numerical fault, '
        f"not a counterexample: both are theorems about the registered classes.</div>"
    )


def _calibration_section(data: ReportData) -> str:
    if data.permutation is None:
        return (
            "<h2>3 · Finite-sample calibration</h2>"
            '<div class="note">Not run. No per-unit counts were supplied, so the '
            "separation above is a population quantity computed from the registered "
            "laws. Whether finite data establish it is a separate question.</div>"
        )
    p, b = data.permutation, data.bootstrap
    rows = [
        ("Plug-in Δ(1)", f"{p.observed:.6f}"),
        ("Permutation p-value", f"{p.p_value:.4f} over {p.n_permutations} permutations"),
        ("Null mean / q95", f"{p.null_mean:.4f} / {p.null_q95:.4f}"),
        ("Blocked permutation", "yes" if p.blocked_by else "no"),
        ("Whole-unit bootstrap median", f"{b.median:.6f}"),
        ("Bootstrap 95% interval", f"[{b.ci_low:.4f}, {b.ci_high:.4f}] over {b.n_resamples} resamples"),
    ]
    body = "".join(f"<b>{_E(k)}</b><span>{_E(v)}</span>" for k, v in rows)
    return (
        f"<h2>3 · Finite-sample calibration</h2><div class=\"kv\">{body}</div>"
        f'<div class="note">{_E(p.note)} Resampling is over whole physical units; '
        "resampling rows or repeated measurements instead would understate the interval "
        "and inflate significance.</div>"
    )


def _rule_section(data: ReportData) -> str:
    r = data.rule
    prof = r.error_profile(data.experiment)
    rows = [
        ("Block length", f"{r.n} independent units"),
        ("Evidence states", f"{len(r.states):,}"),
        ("Attained decisiveness", f"{r.decisiveness:.6f}"),
        ("Forced Alert rate", f"{r.alert_rate_floor():.6f}"),
        ("Unsafe → Certify (worst case)", f"{prof['unsafe_to_certify']:.6f} against α = {r.alpha:g}"),
        ("Safe → Reject (worst case)", f"{prof['safe_to_reject']:.6f} against β = {r.beta:g}"),
    ]
    body = "".join(f"<b>{_E(k)}</b><span>{_E(v)}</span>" for k, v in rows)

    order = np.argsort(-(r.certify_prob + r.reject_prob))[:12]
    head = ("<thead><tr><th>counts</th><th>P(Certify)</th><th>P(Reject)</th>"
            "<th>P(Alert)</th></tr></thead>")
    trs = "".join(
        f'<tr><td class="mono">{_E(str(r.states[i].tolist()))}</td>'
        f"<td>{r.certify_prob[i]:.4f}</td><td>{r.reject_prob[i]:.4f}</td>"
        f"<td>{max(0.0, 1 - r.certify_prob[i] - r.reject_prob[i]):.4f}</td></tr>"
        for i in order)
    more = ""
    if len(r.states) > len(order):
        more = (f'<p class="muted">Showing the {len(order)} most decisive of '
                f"{len(r.states):,} states.</p>")

    warn = ""
    if data.experiment.gate(r.n):
        d = data.diagnosis
        if d.region == "delayed" and d.n_star is not None:
            advice = f"Compare the decision rate and cost of repeating this measurement at n={d.n_star}."
        elif d.region == "permanent":
            advice = (
                "A budget-only randomisation ignores the data and attains the same worst-case rate. "
                "Do not deploy it for individual certification. Evaluate a different measurement."
            )
        else:
            advice = "The current calculation does not resolve when a larger block first separates the classes."
        warn = f'<div class="note"><b>No resolved separation at this block length.</b> {advice}</div>'
    return (
        f"<h2>4 · Deployable rule</h2><div class=\"kv\">{body}</div>{warn}"
        f'<h3>Decision table</h3><div class="scroll"><table>{head}<tbody>{trs}</tbody></table></div>'
        f"{more}"
        f'<div class="note">The rule is randomised: draw the verdict from these '
        "probabilities with a recorded seed. Its guarantees hold over the registered "
        "classes and no others.</div>"
    )


def _scope_section(data: ReportData) -> str:
    items = [
        "All quantities are relative to the registered safe and unsafe classes. "
        "Enlarging either class can only shrink the separation.",
        "The report does not verify that the grades were identified by a reference "
        "experiment. Grading units with the same channel under test makes every number "
        "here circular.",
        "Block quantities assume the units within a block are conditionally independent "
        "given a fixed model.",
        "A permutation p-value is not a lower confidence bound on the population "
        "separation, and neither is a bootstrap interval.",
        "Separation established here is a source-domain statement. Whether it survives a "
        "deployment shift is a separate check.",
    ]
    extra = "".join(f"<li>{_E(n)}</li>" for n in data.notes)
    return ("<h2>5 · Scope and limitations</h2><ul>"
            + "".join(f"<li>{_E(i)}</li>" for i in items) + extra + "</ul>")


def build(
    experiment: Experiment,
    *,
    n_grid=(1, 2, 3, 4, 5, 6, 8, 10),
    alpha: float = 0.05,
    beta: float = 0.05,
    rule_n: int | None = None,
    unit_counts=None,
    labels=None,
    blocks=None,
    smoothing: float = 0.5,
    n_permutations: int = 999,
    n_resamples: int = 2000,
    seed: int = 0,
    title: str = "Certification report",
    subject: str | None = None,
    timestamp: str | None = None,
    notes=(),
) -> str:
    """Render a self-contained HTML certification report.

    Parameters
    ----------
    experiment:
        The registered experiment to report on.
    unit_counts, labels, blocks:
        Per-unit counts and grades. Supplying them adds the finite-sample
        calibration section; omitting them states plainly that it was not run.
    rule_n:
        Block length for the decision table. Defaults to ``n_star`` when the gate
        opens, otherwise the largest evaluated grid point.
    timestamp:
        Free text placed in the header. Left out by default, which keeps the
        output byte-deterministic for a given analysis — pass one only when the
        filing process needs it.
    notes:
        Extra scope caveats specific to the deployment, appended to the standing
        list in section 5.

    Returns
    -------
    str
        A complete HTML document with no external dependencies.
    """
    data = _gather(
        experiment, n_grid=n_grid, alpha=alpha, beta=beta, rule_n=rule_n,
        unit_counts=unit_counts, labels=labels, blocks=blocks, smoothing=smoothing,
        n_permutations=n_permutations, n_resamples=n_resamples, seed=seed,
        title=title, subject=subject, timestamp=timestamp, notes=notes,
    )
    from . import __version__

    meta = [("Evidence fingerprint", data.experiment.fingerprint()[:32]),
            ("Error budget", f"α = {alpha:g}, β = {beta:g}"),
            ("Produced by", f"certlim {__version__}")]
    if data.subject:
        meta.insert(0, ("Subject", data.subject))
    if data.timestamp:
        meta.append(("Generated", data.timestamp))
    meta_html = "".join(f"<b>{_E(k)}</b><span>{_E(v)}</span>" for k, v in meta)

    return (
        "<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        f"<title>{_E(data.title)}</title>\n<style>{_CSS}</style>\n</head>\n<body>\n"
        f'<div class="wrap">\n<h1>{_E(data.title)}</h1>\n'
        '<p class="muted">What any Certify / Reject rule can achieve from this evidence, '
        "and what it cannot.</p>\n"
        f'<div class="meta">{meta_html}</div>\n'
        f"{_verdict_block(data)}\n{_diagnosis_section(data)}\n{_frontier_section(data)}\n"
        f"{_calibration_section(data)}\n{_rule_section(data)}\n{_scope_section(data)}\n"
        "<footer>Generated by certlim. Every figure is computed exactly by linear "
        "programming over the registered classes; none is fitted, sampled or tuned. "
        "The composite separation and the decision rule are solved as independent "
        "programs, so their agreement with the certification bound is a check rather "
        "than an identity.</footer>\n</div>\n</body>\n</html>\n"
    )


def write(path, experiment: Experiment, **kwargs) -> str:
    """Render the report and write it to ``path``; returns the HTML."""
    doc = build(experiment, **kwargs)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(doc)
    return doc
