"""The registered experiment: two composite classes over one evidence alphabet."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .core import (
    DEFAULT_MAX_STATES,
    ZERO_TOL,
    StateSpaceTooLarge,
    block_laws,
    count_states,
    decisiveness,
    hull_tv,
    n_states,
    separating_statistic,
    sion_gap,
)

__all__ = ["Experiment", "Diagnosis", "Separator", "pairwise_min_tv"]

#: Below this the fast dual value is re-solved with the exact primal program.
#: The dual is 10-450x faster but loses accuracy as the state space grows
#: (agreement degrades from 1e-9 to about 2e-7 by 20,000 states), and a value
#: near zero is exactly where the gate verdict is decided.
_DUAL_TRUST_FLOOR = 1e-5


@dataclass(frozen=True)
class Separator:
    """Optimal bounded statistic that realises the separation margin.

    ``values`` lives in count-state space. Safe models score at least
    ``threshold + margin`` and unsafe models at most ``threshold - margin``,
    with ``margin`` equal to half the composite separation.
    """

    values: np.ndarray
    threshold: float
    margin: float
    n: int
    states: np.ndarray

    def apply(self, counts) -> float:
        """Score one observed block of ``n`` units given its symbol counts."""
        counts = _as_counts(counts, self.states.shape[1], self.n)
        hit = np.flatnonzero((self.states == counts).all(axis=1))
        if hit.size != 1:
            raise ValueError(f"count vector {counts.tolist()} is not a valid state")
        return float(self.values[hit[0]])

    def expected(self, law) -> float:
        """Expected score under a one-unit law, lifted to ``n`` units."""
        return float(block_laws(np.atleast_2d(law), self.n)[0] @ self.values)

    def side(self, counts, tol: float = ZERO_TOL) -> str:
        """Which side of the threshold a block falls on."""
        score = self.apply(counts)
        if score >= self.threshold + tol:
            return "safe"
        if score <= self.threshold - tol:
            return "unsafe"
        return "undetermined"


def _as_counts(counts, alphabet: int, n: int) -> np.ndarray:
    arr = np.asarray(counts).ravel()
    if not np.all(np.isfinite(arr)):
        raise ValueError("counts contain NaN or infinity")
    if not np.allclose(arr, np.round(arr)):
        raise ValueError("counts must be whole numbers")
    arr = np.round(arr).astype(int)
    if arr.size != alphabet:
        raise ValueError(f"expected {alphabet} counts, got {arr.size}")
    if (arr < 0).any():
        raise ValueError("counts must be non-negative")
    if arr.sum() != n:
        raise ValueError(f"counts must sum to n={n}, got {int(arr.sum())}")
    return arr


def _as_laws(rows, name: str, k: int | None) -> np.ndarray:
    arr = np.atleast_2d(np.asarray(rows, dtype=float))
    if arr.size == 0:
        raise ValueError(f"{name} class is empty; both classes must be non-empty")
    if not np.isfinite(arr).all():
        raise ValueError(f"{name} contains NaN or infinity")
    if k is not None and arr.shape[1] != k:
        raise ValueError(f"{name} laws have alphabet {arr.shape[1]}, expected {k}")
    bad = np.abs(arr.sum(axis=1) - 1.0) > 1e-8
    if bad.any():
        raise ValueError(f"{name} row(s) {np.flatnonzero(bad).tolist()} do not sum to 1")
    if (arr < -1e-12).any():
        raise ValueError(f"{name} contains negative probabilities")
    out = np.clip(arr, 0.0, None)
    out.setflags(write=False)          # the cache below assumes the laws never change
    return out


def pairwise_min_tv(safe: np.ndarray, unsafe: np.ndarray) -> float:
    """Smallest total variation over safe/unsafe *pairs*.

    Reported next to the hull distance on purpose. A positive pairwise distance
    does not establish composite separation: the hull distance can be zero while
    every pair is well separated, and acting on the pairwise number alone
    overstates what any certification rule can do.
    """
    safe = np.atleast_2d(np.asarray(safe, dtype=float))
    unsafe = np.atleast_2d(np.asarray(unsafe, dtype=float))
    diffs = 0.5 * np.abs(safe[:, None, :] - unsafe[None, :, :]).sum(axis=2)
    return float(diffs.min())


@dataclass(frozen=True)
class Diagnosis:
    """Structural verdict for an experiment, independent of sample size.

    ``region`` is one of:

    ``'permanent'``
        A safe and an unsafe model induce the identical one-unit law. No amount
        of this channel can help.
    ``'delayed'``
        The one-unit hulls meet but no pair collides; repetition opens the gate
        at ``n_star``.
    ``'immediate'``
        The gate is already open at one unit.
    ``'undetermined'``
        The search could not be completed, normally because the exact program
        exceeded its budget before reaching the stopping bound. This is **not**
        a permanent obstruction; see ``limit_reason``.
    """

    region: str
    n_star: int | None
    delta_one: float
    pairwise_min_tv: float
    exact_collision: bool
    stopping_bound: int
    searched_to: int
    limit_reason: str | None = None
    collision_pairs: tuple[tuple[int, int], ...] = ()
    collision_from_tied_counts: bool = False

    @property
    def permanent(self) -> bool:
        """True only for a proven permanent obstruction, never for a failed search."""
        return self.region == "permanent"

    def explain(self) -> str:
        if self.region == "permanent":
            base = (
                "Permanent obstruction: a safe and an unsafe model induce the identical "
                "one-unit evidence law, so decisiveness is pinned at alpha+beta for every n. "
                "More of this channel, and any theta-independent re-encoding of it, cannot "
                "help; only a different acquisition protocol can."
            )
            if self.collision_from_tied_counts:
                pairs = ", ".join(f"safe #{i} with unsafe #{j}" for i, j in self.collision_pairs[:3])
                return (
                    base + " CAUTION: the colliding models (" + pairs + ") have identical "
                    "observed counts, so this may be a finite-sample coincidence rather than "
                    "a structural fact. Two units drawn from different populations can tie on "
                    "a small alphabet with few draws. Check whether your registered models are "
                    "cohorts or individual units before acting on this verdict."
                )
            return base
        if self.region == "delayed":
            return (
                f"Delayed separation: the one-unit hulls intersect but no exact pair "
                f"collides, so repetition alone opens the gate at n = {self.n_star}. "
                f"Buying more of the same evidence is the correct move here."
            )
        if self.region == "undetermined":
            return (
                f"Undetermined: evaluated through n = {self.searched_to} "
                f"(structural bound {self.stopping_bound}, {self.limit_reason}). "
                "The search found no exact collision. A numerically unresolved "
                "result is not a permanent obstruction."
            )
        return (
            "Immediate separation: the structural gate is already open at one unit. "
            "What remains is confidence, sampling cost and transport, not structure."
        )


@dataclass(frozen=True)
class Experiment:
    """A registered certification experiment.

    Parameters
    ----------
    safe, unsafe:
        Rows of one-unit evidence probability mass functions, one row per
        registered model. Both classes must be non-empty and share an alphabet.
    labels:
        Optional names for the safe and unsafe rows, used in reports.
    max_states:
        Ceiling on exact enumeration. Exceeding it raises
        :class:`certlim.StateSpaceTooLarge` naming the offending ``(K, n)``.

    Notes
    -----
    Instances are immutable and their law arrays are read-only, because results
    are memoised against them. Build a new experiment rather than editing one.

    Every result is relative to the registered classes. Enlarging them can only
    shrink the separation, never grow it.
    """

    safe: np.ndarray
    unsafe: np.ndarray
    labels: tuple[tuple[str, ...], tuple[str, ...]] | None = None
    max_states: int = DEFAULT_MAX_STATES
    source_counts: tuple[np.ndarray, np.ndarray] | None = field(default=None, repr=False)
    _cache: dict = field(default_factory=dict, repr=False, compare=False)

    def __post_init__(self) -> None:
        safe = _as_laws(self.safe, "safe", None)
        unsafe = _as_laws(self.unsafe, "unsafe", safe.shape[1])
        object.__setattr__(self, "safe", safe)
        object.__setattr__(self, "unsafe", unsafe)
        if int(self.max_states) < 1:
            raise ValueError("max_states must be at least 1")
        object.__setattr__(self, "max_states", int(self.max_states))
        if self.labels is not None:
            s, u = self.labels
            if len(s) != len(safe) or len(u) != len(unsafe):
                raise ValueError("labels do not match the number of rows")

    # numpy arrays make the generated comparison raise, so define both explicitly
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Experiment):
            return NotImplemented
        return (
            np.array_equal(self.safe, other.safe)
            and np.array_equal(self.unsafe, other.unsafe)
            and self.labels == other.labels
            and self.max_states == other.max_states
        )

    def __hash__(self) -> int:
        return hash((self.safe.tobytes(), self.unsafe.tobytes(), self.labels, self.max_states))

    def __repr__(self) -> str:
        ns, nu = self.n_models
        return f"Experiment(safe={ns}, unsafe={nu}, alphabet={self.alphabet_size})"

    # ------------------------------------------------------------------ basics
    @property
    def alphabet_size(self) -> int:
        return int(self.safe.shape[1])

    @property
    def n_models(self) -> tuple[int, int]:
        return int(self.safe.shape[0]), int(self.unsafe.shape[0])

    def fingerprint(self) -> str:
        """Stable SHA-256 over the registered laws, for audit trails."""
        import hashlib

        h = hashlib.sha256()
        for arr in (self.safe, self.unsafe):
            h.update(np.ascontiguousarray(np.round(arr, 12), dtype="<f8").tobytes())
            h.update(b"|")
        return h.hexdigest()

    @classmethod
    def from_counts(
        cls,
        safe_counts,
        unsafe_counts,
        *,
        smoothing: float = 0.5,
        labels=None,
        max_states: int = DEFAULT_MAX_STATES,
    ) -> "Experiment":
        """Build from observed symbol counts with add-``smoothing`` regularisation.

        The default ``0.5`` is Krichevsky--Trofimov. Smoothing matters: with few
        units per model an unobserved symbol is not an impossible symbol, and
        leaving structural zeros in place inflates the separation.
        """
        if smoothing < 0:
            raise ValueError("smoothing must be non-negative")

        def norm(counts, name):
            arr = np.atleast_2d(np.asarray(counts, dtype=float))
            if not np.isfinite(arr).all():
                raise ValueError(f"{name} counts contain NaN or infinity")
            if (arr < 0).any():
                raise ValueError(f"{name} counts must be non-negative")
            arr = arr + smoothing
            totals = arr.sum(axis=1, keepdims=True)
            if (totals <= 0).any():
                raise ValueError(f"{name} has a row with no mass; raise smoothing")
            return arr / totals

        raw = (np.atleast_2d(np.asarray(safe_counts, dtype=float)),
               np.atleast_2d(np.asarray(unsafe_counts, dtype=float)))
        return cls(norm(safe_counts, "safe"), norm(unsafe_counts, "unsafe"),
                   labels=labels, max_states=max_states, source_counts=raw)

    # ------------------------------------------------------------- block views
    def _blocks(self, n: int) -> tuple[np.ndarray, np.ndarray]:
        key = ("blocks", int(n))
        if key not in self._cache:
            self._cache[key] = (
                block_laws(self.safe, n, max_states=self.max_states),
                block_laws(self.unsafe, n, max_states=self.max_states),
            )
        return self._cache[key]

    def state_count(self, n: int) -> int:
        """Number of enumerated count states at block length ``n``."""
        if n < 1:
            raise ValueError(f"block length n must be at least 1; got {n}")
        return n_states(n, self.alphabet_size)

    # --------------------------------------------------------------- quantities
    def delta(self, n: int = 1, *, exact: bool = False) -> float:
        """Composite separation ``Delta(n)``: the hull distance at block length ``n``.

        Solved through the dual separation game, which is far cheaper on large
        state spaces, and re-solved with the exact primal hull program whenever
        the dual value lands near zero — the region where the gate verdict turns.
        Pass ``exact=True`` to force the primal program everywhere.
        """
        if n < 1:
            raise ValueError(f"block length n must be at least 1; got {n}")
        key = ("delta", int(n), bool(exact))
        if key in self._cache:
            return self._cache[key]
        if ("delta", int(n), True) in self._cache:
            return self._cache[("delta", int(n), True)]

        safe, unsafe = self._blocks(n)
        if exact or self.n_models == (1, 1):
            value = hull_tv(safe, unsafe)
            key = ("delta", int(n), True)
        else:
            value = sion_gap(safe, unsafe)
            if abs(value) < _DUAL_TRUST_FLOOR:
                value = hull_tv(safe, unsafe)
                key = ("delta", int(n), True)
            value = max(0.0, min(1.0, value))
            if value <= ZERO_TOL:
                value = 0.0
        self._cache[key] = value
        return value

    def decisiveness(self, n: int = 1, alpha: float = 0.05, beta: float = 0.05) -> float:
        """Exact optimal worst-case decisiveness at block length ``n``."""
        safe, unsafe = self._blocks(n)
        return decisiveness(safe, unsafe, alpha, beta)

    def bound(self, n: int = 1, alpha: float = 0.05, beta: float = 0.05) -> float:
        """Certification bound ``min(1, alpha + beta + Delta(n))``."""
        return min(1.0, alpha + beta + self.delta(n))

    def margin(self, n: int = 1) -> float:
        """Optimal bounded separation margin, equal to ``Delta(n) / 2``."""
        return 0.5 * self.delta(n)

    def gate(self, n: int = 1) -> int:
        """Gate indicator: ``1`` while the hulls still intersect at ``n``.

        Decided on the exact primal value, never on the fast dual.
        """
        return int(self.delta(n) <= (0. if self.n_models == (1, 1) else ZERO_TOL))

    def pairwise_min_tv(self) -> float:
        """Smallest total variation over safe/unsafe pairs at one unit."""
        return pairwise_min_tv(self.safe, self.unsafe)

    def collision_pairs(self, tol: float = 0.) -> tuple[tuple[int, int], ...]:
        """Index pairs ``(safe_i, unsafe_j)`` whose one-unit laws coincide.

        Worth inspecting before acting on a permanent verdict. If the registered
        models are individual physical units rather than cohorts, two units can
        tie by chance on a small alphabet with few draws, and the collision is a
        sampling coincidence rather than a structural obstruction.
        """
        if tol == 0:
            matches = np.all(self.safe[:, None, :] == self.unsafe[None, :, :], axis=2)
        else:
            diffs = .5*np.abs(self.safe[:, None, :] - self.unsafe[None, :, :]).sum(axis=2)
            matches = diffs <= tol
        idx = np.argwhere(matches)
        return tuple((int(i), int(j)) for i, j in idx)

    def _collision_from_tied_counts(self, pairs) -> bool:
        """Whether every collision is explained by identical raw observed counts."""
        if not pairs or self.source_counts is None:
            return False
        safe_raw, unsafe_raw = self.source_counts
        return all(np.array_equal(safe_raw[i], unsafe_raw[j]) for i, j in pairs)

    def has_exact_collision(self, tol: float = 0.) -> bool:
        """Whether a safe and an unsafe model share an identical one-unit law.

        This, not one-unit hull intersection, is what makes an obstruction
        permanent.
        """
        return bool(self.collision_pairs(tol))

    def stopping_bound(self) -> int:
        """Largest block length that still needs checking for a finite class.

        With ``r`` distinct one-unit laws across both classes and no exact
        cross-grade collision, the gate must be open by ``r - 1``. The bound is
        tight for small registered classes and loose for large ones; it bounds
        the *structural* search only, never the number of physical units needed
        for a confidence statement.
        """
        laws = np.vstack([self.safe, self.unsafe])
        distinct = np.unique(laws, axis=0).shape[0]
        return max(1, distinct - 1)

    def n_star(self, max_n: int | None = None, *, strict: bool = False) -> int | None:
        """Smallest block length at which the gate opens, or ``None`` if never.

        ``None`` means a **proven** permanent obstruction: an exact cross-grade
        collision exists. A state-budget limit raises :class:`certlim.StateSpaceTooLarge`.
        If no positive gap is resolved within the search horizon, the method raises
        ``RuntimeError``. Use :meth:`diagnose` for a structured undetermined outcome.
        The legacy ``strict`` keyword remains accepted.
        """
        if self.has_exact_collision():
            return None
        ceiling = self.stopping_bound() if max_n is None else int(max_n)
        for n in range(1, ceiling + 1):
            if not self.gate(n):
                return n
        raise RuntimeError(f"Separation unresolved at numerical precision through n={ceiling}; no exact collision")

    def diagnose(self, max_n: int | None = None) -> Diagnosis:
        """Classify the experiment into permanent, delayed, immediate, or undetermined."""
        pairs = self.collision_pairs()
        collision = bool(pairs)
        tied = self._collision_from_tied_counts(pairs)
        ceiling = self.stopping_bound() if max_n is None else int(max_n)
        delta_one = pair_tv = None
        nstar: int | None = None
        reason: str | None = None
        reached = 0

        try:
            delta_one = self.delta(1)
        except StateSpaceTooLarge as exc:
            raise ValueError(f"one unit already exceeds the state budget: {exc}") from exc
        pair_tv = self.pairwise_min_tv()

        if collision:
            region = "permanent"
            reached = ceiling
        else:
            for n in range(1, ceiling + 1):
                try:
                    closed = self.gate(n)
                except StateSpaceTooLarge as exc:
                    reason = str(exc).split(".")[0]
                    break
                reached = n
                if not closed:
                    nstar = n
                    break
            if nstar == 1:
                region = "immediate"
            elif nstar is not None:
                region = "delayed"
            else:
                region = "undetermined"
                if reason is None:
                    reason = f"no separation found up to n={reached}"

        return Diagnosis(
            region=region,
            n_star=nstar if not collision else None,
            delta_one=delta_one,
            pairwise_min_tv=pair_tv,
            exact_collision=collision,
            stopping_bound=self.stopping_bound(),
            searched_to=reached,
            limit_reason=reason,
            collision_pairs=pairs[:8],
            collision_from_tied_counts=tied,
        )

    def separator(self, n: int = 1) -> Separator:
        """Optimal bounded separator at block length ``n``.

        The returned statistic is indexed by *count states*, not by symbols, so
        apply it through :meth:`Separator.apply` rather than by position.
        """
        f, threshold, margin = separating_statistic(*self._blocks(n))
        return Separator(
            values=f, threshold=threshold, margin=margin, n=int(n),
            states=count_states(n, self.alphabet_size, max_states=self.max_states),
        )
