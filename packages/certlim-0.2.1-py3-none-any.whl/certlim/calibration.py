"""Finite-sample calibration for a plug-in separation estimate.

A plug-in ``Delta`` computed from observed counts is an estimate, and a positive
estimate is not by itself evidence that the channel separates the grades. Two
checks belong next to it:

* a **block permutation test**, which asks whether relabelling the physical
  units at random would produce as much separation. The resampling unit must be
  the physical unit -- the cell, the pack, the battery -- never a row, a cycle or
  a time point, or the test will be anticonservative by orders of magnitude.
* a **whole-unit bootstrap**, which quantifies sampling variability.

Neither is a lower confidence bound on the population ``Delta``. A significant
permutation p-value rejects label exchangeability; it does not certify
separation with coverage.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .experiment import Experiment

__all__ = ["PermutationResult", "BootstrapResult", "permutation_test", "bootstrap_delta"]


@dataclass(frozen=True)
class PermutationResult:
    """Outcome of a unit-blocked label permutation test."""

    observed: float
    p_value: float
    null_mean: float
    null_q95: float
    n_permutations: int
    blocked_by: str | None

    def __str__(self) -> str:
        return (
            f"Delta = {self.observed:.4f}, permutation p = {self.p_value:.4f} "
            f"(null mean {self.null_mean:.4f}, q95 {self.null_q95:.4f}, "
            f"B = {self.n_permutations})"
        )

    @property
    def note(self) -> str:
        return (
            "A permutation p-value tests label exchangeability. It is not a lower "
            "confidence bound on the population separation."
        )


@dataclass(frozen=True)
class BootstrapResult:
    """Whole-unit bootstrap distribution of the plug-in separation."""

    observed: float
    median: float
    ci_low: float
    ci_high: float
    n_resamples: int

    def __str__(self) -> str:
        return (
            f"Delta = {self.observed:.4f}, bootstrap median {self.median:.4f}, "
            f"95% interval [{self.ci_low:.4f}, {self.ci_high:.4f}]"
        )


def _validate(unit_counts: np.ndarray, labels: np.ndarray, blocks) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
    counts = np.atleast_2d(np.asarray(unit_counts, dtype=float))
    labels = np.asarray(labels).ravel()
    if labels.size != counts.shape[0]:
        raise ValueError("one label per physical unit is required")
    uniq = set(np.unique(labels).tolist())
    if not uniq <= {"safe", "unsafe"} or len(uniq) != 2:
        raise ValueError("labels must contain exactly the values 'safe' and 'unsafe'")
    if (counts < 0).any():
        raise ValueError("counts must be non-negative")
    if blocks is None:
        return counts, labels, None
    blocks = np.asarray(blocks).ravel()
    if blocks.size != labels.size:
        raise ValueError("one block id per physical unit is required")
    return counts, labels, blocks


def _plug_in_delta(counts: np.ndarray, labels: np.ndarray, smoothing: float, n: int) -> float:
    safe = counts[labels == "safe"]
    unsafe = counts[labels == "unsafe"]
    if safe.size == 0 or unsafe.size == 0:
        return float("nan")
    return Experiment.from_counts(safe, unsafe, smoothing=smoothing).delta(n)


def permutation_test(
    unit_counts,
    labels,
    *,
    blocks=None,
    n: int = 1,
    smoothing: float = 0.5,
    n_permutations: int = 999,
    seed: int = 0,
) -> PermutationResult:
    """Permute grade labels across physical units and recompute the separation.

    Parameters
    ----------
    unit_counts:
        ``(n_units, alphabet)`` symbol counts, one row per physical unit.
    labels:
        ``'safe'`` or ``'unsafe'`` per unit.
    blocks:
        Optional grouping within which labels are permuted. Blocking on a
        nuisance factor -- chemistry, test rig, temperature -- keeps that factor's
        association with the grade in the null, so a surviving effect cannot be
        explained by it alone.
    """
    counts, labels, blocks = _validate(unit_counts, labels, blocks)
    observed = _plug_in_delta(counts, labels, smoothing, n)
    rng = np.random.default_rng(seed)
    draws = np.empty(n_permutations)
    for b in range(n_permutations):
        shuffled = labels.copy()
        if blocks is None:
            shuffled = rng.permutation(shuffled)
        else:
            for key in np.unique(blocks):
                idx = np.flatnonzero(blocks == key)
                shuffled[idx] = rng.permutation(shuffled[idx])
        draws[b] = _plug_in_delta(counts, shuffled, smoothing, n)
    finite = draws[np.isfinite(draws)]
    hits = int(np.sum(finite >= observed - 1e-12))
    p = (hits + 1) / (finite.size + 1)
    return PermutationResult(
        observed=float(observed),
        p_value=float(p),
        null_mean=float(finite.mean()) if finite.size else float("nan"),
        null_q95=float(np.quantile(finite, 0.95)) if finite.size else float("nan"),
        n_permutations=int(finite.size),
        blocked_by=None if blocks is None else "blocks",
    )


def bootstrap_delta(
    unit_counts,
    labels,
    *,
    n: int = 1,
    smoothing: float = 0.5,
    n_resamples: int = 2000,
    seed: int = 0,
    level: float = 0.95,
) -> BootstrapResult:
    """Resample whole physical units, stratified by grade, and recompute ``Delta``.

    Stratifying keeps both classes non-empty in every resample. Resampling rows
    or cycles instead of units would understate the interval badly, because
    repeated measurements of one unit are not independent evidence about the
    population of units.
    """
    counts, labels, _ = _validate(unit_counts, labels, None)
    observed = _plug_in_delta(counts, labels, smoothing, n)
    safe_idx = np.flatnonzero(labels == "safe")
    unsafe_idx = np.flatnonzero(labels == "unsafe")
    rng = np.random.default_rng(seed)
    draws = np.empty(n_resamples)
    for b in range(n_resamples):
        pick = np.concatenate([
            rng.choice(safe_idx, safe_idx.size, replace=True),
            rng.choice(unsafe_idx, unsafe_idx.size, replace=True),
        ])
        draws[b] = _plug_in_delta(counts[pick], labels[pick], smoothing, n)
    finite = draws[np.isfinite(draws)]
    lo, hi = (1.0 - level) / 2.0, 1.0 - (1.0 - level) / 2.0
    return BootstrapResult(
        observed=float(observed),
        median=float(np.median(finite)),
        ci_low=float(np.quantile(finite, lo)),
        ci_high=float(np.quantile(finite, hi)),
        n_resamples=int(finite.size),
    )
