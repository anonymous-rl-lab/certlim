"""Exact numerics for composite safe/unsafe certification geometry.

Everything here is exact: the block laws are enumerated over count vectors (the
sufficient statistic for i.i.d. draws from a finite alphabet) and the two
optimisation problems are linear programs solved by HiGHS. There is no sampling,
no fitting and no tuning parameter.
"""

from __future__ import annotations

from functools import lru_cache
from math import comb

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, csr_matrix, eye, hstack, vstack
from scipy.special import gammaln

__all__ = [
    "ZERO_TOL",
    "count_states",
    "n_states",
    "multinomial_law",
    "block_laws",
    "hull_tv",
    "decisiveness",
    "separating_statistic",
    "sion_gap",
    "StateSpaceTooLarge",
]

#: Default ceiling on the number of enumerated count states.
#:
#: Chosen from measured solve time, not from memory. The hull-distance program
#: is the bottleneck and its cost grows steeply and unevenly with the state
#: count: roughly 3 s at 6,000 states, 40-100 s at 20,000, and hours beyond
#: that, with a factor of two or more of run-to-run variation at the same size.
#: A ceiling that only guards against memory would let a caller start a job that
#: never finishes.
DEFAULT_MAX_STATES = 20_000

#: Values at or below this are treated as exactly zero throughout the package.
ZERO_TOL = 1e-9


class StateSpaceTooLarge(ValueError):
    """Raised when exact enumeration would exceed the configured ceiling."""


def n_states(n: int, k: int) -> int:
    """Number of count vectors of length ``k`` summing to ``n``."""
    return comb(n + k - 1, k - 1)


def _check_budget(n: int, k: int, max_states: int) -> None:
    size = n_states(n, k)
    if size > max_states:
        raise StateSpaceTooLarge(
            f"alphabet K={k} at n={n} needs {size:,} count states, above the "
            f"ceiling of {max_states:,}. The ceiling is a time budget, not a "
            f"memory one: past roughly 20,000 states the exact program takes "
            f"minutes to hours and its runtime is not predictable from the size. "
            f"Coarsen the alphabet (certlim.NestedQuantizer), lower n, or raise "
            f"max_states explicitly if you accept an open-ended solve."
        )


@lru_cache(maxsize=256)
def _count_states_cached(n: int, k: int) -> tuple[tuple[int, ...], ...]:
    out: list[tuple[int, ...]] = []

    def rec(rem: int, left: int, prefix: tuple[int, ...]) -> None:
        if left == 1:
            out.append(prefix + (rem,))
            return
        for v in range(rem, -1, -1):          # descending: n=1 gives the identity
            rec(rem - v, left - 1, prefix + (v,))

    rec(n, k, ())
    return tuple(out)


def count_states(n: int, k: int, *, max_states: int = DEFAULT_MAX_STATES) -> np.ndarray:
    """All non-negative integer vectors of length ``k`` summing to ``n``.

    These are the sufficient statistics for ``n`` i.i.d. draws from a
    ``k``-symbol alphabet, so working with them instead of raw sequences leaves
    every quantity in this module unchanged while shrinking the problem from
    ``k**n`` to ``C(n+k-1, k-1)``.

    States are enumerated so that ``n = 1`` reproduces the symbol order, i.e.
    ``block_laws(P, 1)`` equals ``P``. Any other block length has its own
    ordering, so index block-space vectors through the returned array rather
    than assuming they line up with symbols.
    """
    if n < 1:
        raise ValueError(f"block length n must be at least 1; got {n}")
    if k < 1:
        raise ValueError(f"alphabet size must be at least 1; got {k}")
    _check_budget(n, k, max_states)
    return np.array(_count_states_cached(int(n), int(k)), dtype=int)


def multinomial_law(p: np.ndarray, n: int, states: np.ndarray | None = None) -> np.ndarray:
    """Probability of each count vector under ``Multinomial(n, p)``.

    Zero-probability symbols use the convention ``0 * log 0 = 0``. Getting this
    wrong produces ``NaN`` for every model with an empty alphabet cell, and a
    ``NaN`` silently mapped to ``-inf`` will zero out those models and report a
    spurious ``Delta = 0``. That failure is covered by a regression test.
    """
    p = np.asarray(p, dtype=float)
    if p.ndim != 1:
        raise ValueError("p must be a one-dimensional probability vector")
    if not np.isfinite(p).all():
        raise ValueError("p contains NaN or infinity")
    if np.any(p < -1e-12) or abs(p.sum() - 1.0) > 1e-8:
        raise ValueError(f"p must be a probability vector; got sum {p.sum():.6g}")
    p = np.clip(p, 0.0, None)
    if states is None:
        states = count_states(n, p.size)
    coef = gammaln(n + 1) - gammaln(states + 1).sum(axis=1)
    positive = p > 0
    log_p = states[:, positive] @ np.log(p[positive])
    if (~positive).any():
        dead = states[:, ~positive].sum(axis=1) > 0
        log_p = np.where(dead, -np.inf, log_p)
    out = np.exp(coef + log_p)
    total = out.sum()
    return out / total if total > 0 else out


def block_laws(
    laws: np.ndarray, n: int, *, max_states: int = DEFAULT_MAX_STATES
) -> np.ndarray:
    """Lift single-unit laws to ``n``-unit block laws over the count space.

    Convexification happens *after* this lift, which is the point: the least
    favourable mixture draws one model for the whole block rather than redrawing
    it per observation.
    """
    laws = np.atleast_2d(np.asarray(laws, dtype=float))
    states = count_states(n, laws.shape[1], max_states=max_states)
    return np.vstack([multinomial_law(row, n, states) for row in laws])


def hull_tv(safe: np.ndarray, unsafe: np.ndarray) -> float:
    """Total-variation distance between the two convex hulls.

    This is ``Delta``: the exact composite separation. It is **not** the minimum
    pairwise distance, which can be arbitrarily larger; use
    :func:`certlim.pairwise_min_tv` to see both.
    """
    safe = np.atleast_2d(np.asarray(safe, dtype=float))
    unsafe = np.atleast_2d(np.asarray(unsafe, dtype=float))
    ns, k = safe.shape
    nu = unsafe.shape[0]
    if unsafe.shape[1] != k:
        raise ValueError("safe and unsafe laws must share an alphabet")
    if ns == nu == 1:
        return float(0.5 * np.abs(safe[0] - unsafe[0]).sum())
    nw = ns + nu

    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    for j in range(k):
        for sign, row in ((1.0, 2 * j), (-1.0, 2 * j + 1)):
            rows += [row] * (nw + 1)
            cols += list(range(nw)) + [nw + j]
            vals += list(sign * safe[:, j]) + list(-sign * unsafe[:, j]) + [-1.0]
    a_ub = coo_matrix((vals, (rows, cols)), shape=(2 * k, nw + k)).tocsr()

    a_eq = np.zeros((2, nw + k))
    a_eq[0, :ns] = 1.0
    a_eq[1, ns:nw] = 1.0
    cost = np.concatenate([np.zeros(nw), 0.5 * np.ones(k)])

    res = linprog(
        cost, A_ub=a_ub, b_ub=np.zeros(2 * k), A_eq=a_eq, b_eq=np.ones(2),
        bounds=(0.0, None), method="highs",
    )
    if not res.success:
        raise RuntimeError(f"hull-TV program failed: {res.message}")
    gap = float(0.5 * np.abs(res.x[:ns] @ safe - res.x[ns:nw] @ unsafe).sum())
    return 0.0 if gap <= ZERO_TOL else gap


def decisiveness(
    safe: np.ndarray, unsafe: np.ndarray, alpha: float = 0.05, beta: float = 0.05
) -> float:
    """Exact optimal worst-case three-state decisiveness.

    The supremum, over randomised ``Certify``/``Alert``/``Reject`` rules obeying
    ``sup_unsafe P(Certify) <= alpha`` and ``sup_safe P(Reject) <= beta``, of the
    worst-case probability of not answering ``Alert``.

    This is solved by its own linear program, independent of :func:`hull_tv`, so
    agreement with the certification bound is a real check rather than a
    same-code identity.
    """
    return _decision_solution(safe, unsafe, alpha, beta)[2]


def _decision_solution(safe, unsafe, alpha, beta):
    """Solve in per-state probability units; check feasibility and a dual upper bound."""
    _check_errors(alpha, beta)
    safe = np.atleast_2d(np.asarray(safe, dtype=float))
    unsafe = np.atleast_2d(np.asarray(unsafe, dtype=float))
    if safe.shape[1] != unsafe.shape[1] or not safe.size or not unsafe.size:
        raise ValueError("Both classes must contain laws on the same nonempty alphabet")
    laws = np.vstack((safe, unsafe))
    if (
        not np.isfinite(laws).all()
        or (laws < 0).any()
        or not np.allclose(laws.sum(axis=1), 1, rtol=0, atol=1e-8)
    ):
        raise ValueError("Expected finite, nonnegative probability laws")

    # For each state the error constraints alone bound its two action probabilities.
    # In the scaled LP the two budget RHSs are 1, even at very small budgets.
    def action_caps(bank, budget):
        return budget / np.maximum(budget, bank.max(axis=0))

    cap_c, cap_r = action_caps(unsafe, alpha), action_caps(safe, beta)
    k = laws.shape[1]

    def zero(m, n):
        return csr_matrix((m, n))

    matrix = vstack(
        (
            hstack((unsafe * cap_c / alpha, zero(len(unsafe), k + 1))),
            hstack((zero(len(safe), k), safe * cap_r / beta, zero(len(safe), 1))),
            csr_matrix(
                np.column_stack((-laws * cap_c, -laws * cap_r, np.ones(len(laws))))
            ),
            hstack((eye(k).multiply(cap_c), eye(k).multiply(cap_r), zero(k, 1))),
        ),
        format="csr",
    )
    rhs = np.r_[np.ones(len(laws)), np.zeros(len(laws)), np.ones(k)]
    obj = np.r_[np.zeros(2 * k), 1.0]
    res = linprog(
        -obj,
        A_ub=matrix,
        b_ub=rhs,
        bounds=(0.0, 1.0),
        method="highs",
        options={
            "primal_feasibility_tolerance": 1e-10,
            "dual_feasibility_tolerance": 1e-10,
        },
    )
    if not res.success:
        raise RuntimeError(
            f"Decision program could not resolve the requested budgets: {res.message}"
        )

    c = np.minimum(1.0, cap_c * np.clip(res.x[:k], 0.0, 1.0))
    r = np.minimum(1.0 - c, cap_r * np.clip(res.x[k : 2 * k], 0.0, 1.0))
    for action, bank, limit in ((c, unsafe, alpha), (r, safe, beta)):
        risk = float((bank @ action).max())
        if risk >= limit * (1.0 - 1e-13):
            action *= min(1.0, limit / risk) * (1.0 - 1e-13)
        if float((bank @ action).max()) > limit:
            raise ArithmeticError(
                "Unresolved side error at the requested numerical precision"
            )
    lower = min(1.0, float((laws @ (c + r)).min()))
    # Any nonnegative dual multiplier supplies an upper bound after correcting
    # its residual using the [0,1] bounds of all primal variables.
    dual = np.maximum(0.0, -res.ineqlin.marginals)
    upper = min(1.0, float(rhs @ dual + np.maximum(0.0, obj - matrix.T @ dual).sum()))
    # A constant randomised rule can always attain the sum of the budgets, capped at one.
    baseline = min(1.0, alpha + beta)
    if (
        not np.isfinite(upper)
        or max(abs(upper - lower), baseline - lower) > 1e-8 * lower
    ):
        raise ArithmeticError(
            "Feasible rule found but the optimal decision rate is numerically unresolved"
        )
    return c, r, lower


def separating_statistic(safe: np.ndarray, unsafe: np.ndarray) -> tuple[np.ndarray, float, float]:
    """Optimal bounded separator ``f``, its threshold, and its symmetric margin.

    Returns ``(f, threshold, margin)`` where ``f`` maps each evidence state to
    ``[0, 1]``, the safe side has mean at least ``threshold + margin`` and the
    unsafe side at most ``threshold - margin``, and ``margin`` equals
    ``hull_tv / 2`` by the Sion identity.
    """
    safe = np.atleast_2d(np.asarray(safe, dtype=float))
    unsafe = np.atleast_2d(np.asarray(unsafe, dtype=float))
    k = safe.shape[1]
    if unsafe.shape[1] != k:
        raise ValueError("safe and unsafe laws must share an alphabet")
    if len(safe) == len(unsafe) == 1:
        # The indicator of positive mass differences attains the TV distance.
        f = (safe[0] > unsafe[0]).astype(float)
        avg = 0.5 * (safe[0] + unsafe[0]) @ f
        margin = 0.5 * ((safe[0] - unsafe[0]) @ f)
        return f, float(avg), float(margin)
    cost = np.concatenate([np.zeros(k), [-1.0, 1.0]])
    rows = []
    for law in safe:
        row = np.zeros(k + 2); row[:k] = -law; row[k] = 1.0; rows.append(row)
    for law in unsafe:
        row = np.zeros(k + 2); row[:k] = law; row[k + 1] = -1.0; rows.append(row)
    res = linprog(
        cost, A_ub=np.array(rows), b_ub=np.zeros(len(rows)),
        bounds=[(0.0, 1.0)] * (k + 2), method="highs",
    )
    if not res.success:
        raise RuntimeError(f"separator program failed: {res.message}")
    f = np.clip(res.x[:k], 0.0, 1.0)
    lo = float((safe @ f).min())
    hi = float((unsafe @ f).max())
    return f, 0.5 * (lo + hi), 0.5 * (lo - hi)


def sion_gap(safe: np.ndarray, unsafe: np.ndarray) -> float:
    """Value of the bounded separation game; equals ``hull_tv`` by Sion minimax."""
    _, _, margin = separating_statistic(safe, unsafe)
    return 2.0 * margin


def _check_errors(alpha: float, beta: float) -> None:
    for name, value in (("alpha", alpha), ("beta", beta)):
        if not 0.0 < value < 1.0:
            raise ValueError(f"{name} must lie in (0, 1); got {value!r}")
