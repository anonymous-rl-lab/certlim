"""Quantisers that keep coarsenings strictly nested.

Comparing a fine and a coarse evidence menu is only a data-processing comparison
when the coarse partition is a merge of the fine one. Quantising each menu
independently -- separate thresholds, separate fits -- produces partitions that
are not nested, and the resulting comparison can show a coarse menu apparently
beating its own refinement. That is a pipeline artefact, not a violation of
anything. This module makes the nested construction the easy one to write.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

__all__ = ["NestedQuantizer", "coarsen_counts", "check_data_processing"]


@dataclass(frozen=True)
class NestedQuantizer:
    """A base partition plus a chain of strict coarsenings of it.

    Parameters
    ----------
    edges:
        Per-feature cut points, one array per feature. Feature ``i`` with
        ``m_i`` cuts contributes ``m_i + 1`` bins; the base alphabet is the
        product of those.
    drop_order:
        Features to drop, in order, to form successive coarsenings. Each drop
        merges bins rather than re-cutting them, so nesting holds by
        construction.
    """

    edges: tuple[np.ndarray, ...]
    drop_order: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        if not self.edges:
            raise ValueError("at least one feature is required")
        for i, e in enumerate(self.edges):
            arr = np.asarray(e, dtype=float)
            if arr.ndim != 1 or arr.size == 0:
                raise ValueError(f"feature {i}: edges must be a non-empty 1-D array")
            if np.any(np.diff(arr) <= 0):
                raise ValueError(f"feature {i}: edges must be strictly increasing")
        if len(set(self.drop_order)) != len(self.drop_order):
            raise ValueError("drop_order must not repeat a feature")
        if any(d < 0 or d >= len(self.edges) for d in self.drop_order):
            raise ValueError("drop_order refers to a feature that does not exist")

    @classmethod
    def from_quantiles(cls, values, bins: int = 2, drop_order=()) -> "NestedQuantizer":
        """Cut each feature at its own equal-frequency quantiles.

        ``values`` is ``(n_samples, n_features)``. Cut points come from the
        pooled sample and must be computed **without** looking at the safety
        grade, otherwise the quantiser encodes the label it is meant to detect.
        """
        arr = np.atleast_2d(np.asarray(values, dtype=float))
        if bins < 2:
            raise ValueError("bins must be at least 2")
        qs = [i / bins for i in range(1, bins)]
        edges = tuple(np.quantile(arr[:, j], qs) for j in range(arr.shape[1]))
        return cls(edges=edges, drop_order=tuple(drop_order))

    @property
    def n_features(self) -> int:
        return len(self.edges)

    @property
    def base_size(self) -> int:
        size = 1
        for e in self.edges:
            size *= len(e) + 1
        return size

    def _active(self, level: int) -> list[int]:
        dropped = set(self.drop_order[:level])
        return [i for i in range(self.n_features) if i not in dropped]

    def size(self, level: int = 0) -> int:
        """Alphabet size at coarsening ``level`` (0 is the base partition)."""
        size = 1
        for i in self._active(level):
            size *= len(self.edges[i]) + 1
        return size

    def encode(self, values, level: int = 0) -> np.ndarray:
        """Map rows of ``values`` to integer symbols at coarsening ``level``."""
        arr = np.atleast_2d(np.asarray(values, dtype=float))
        if arr.shape[1] != self.n_features:
            raise ValueError(f"expected {self.n_features} features, got {arr.shape[1]}")
        if level < 0 or level > len(self.drop_order):
            raise ValueError(f"level must lie in [0, {len(self.drop_order)}]")
        codes = np.zeros(arr.shape[0], dtype=int)
        for i in self._active(level):
            digits = len(self.edges[i]) + 1
            codes = codes * digits + np.digitize(arr[:, i], self.edges[i])
        return codes

    def counts(self, values, level: int = 0) -> np.ndarray:
        """Symbol counts at coarsening ``level``."""
        return np.bincount(self.encode(values, level), minlength=self.size(level)).astype(float)

    def chain(self) -> list[int]:
        """Alphabet sizes along the nesting chain, coarsest last."""
        return [self.size(level) for level in range(len(self.drop_order) + 1)]


def coarsen_counts(counts, groups) -> np.ndarray:
    """Merge symbol counts under an explicit surjective map ``groups``.

    ``groups[s]`` is the coarse symbol that fine symbol ``s`` merges into. The
    map must be surjective onto ``0..max(groups)``, which is what makes the
    result a genuine coarsening.
    """
    counts = np.atleast_2d(np.asarray(counts, dtype=float))
    groups = np.asarray(groups, dtype=int).ravel()
    if groups.size != counts.shape[1]:
        raise ValueError("groups must have one entry per fine symbol")
    if groups.min() != 0 or set(np.unique(groups).tolist()) != set(range(groups.max() + 1)):
        raise ValueError("groups must be surjective onto 0..max, with no gaps")
    out = np.zeros((counts.shape[0], groups.max() + 1))
    for fine, coarse in enumerate(groups):
        out[:, coarse] += counts[:, fine]
    return out


def check_data_processing(fine, coarse, tol: float = 1e-9) -> dict:
    """Verify that coarsening did not increase the separation.

    ``fine`` and ``coarse`` are :class:`certlim.Experiment` objects over a nested
    pair of alphabets. A positive violation means the two menus were not built
    from a nested partition, not that the theory failed.
    """
    d_fine = fine.delta(1)
    d_coarse = coarse.delta(1)
    violation = d_coarse - d_fine
    return {
        "delta_fine": d_fine,
        "delta_coarse": d_coarse,
        "violation": violation,
        "holds": bool(violation <= tol),
        "note": (
            "coarsening did not increase separation"
            if violation <= tol
            else "coarse menu separates more than its refinement, so the two "
                 "partitions are not nested; rebuild the coarse menu by merging "
                 "the fine bins (see certlim.NestedQuantizer)"
        ),
    }
