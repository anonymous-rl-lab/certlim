"""Command line interface: ``certlim``.

Input is a CSV of per-unit symbol counts plus a grade column, or a JSON file of
probability laws. Nothing is fitted and no state is written unless an output path
is given.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

import numpy as np

from . import __version__
from .calibration import bootstrap_delta, permutation_test
from .core import StateSpaceTooLarge
from .experiment import Experiment
from .frontier import frontier as build_frontier
from .report import write as write_report
from .rules import build_rule

_GRADES = ("safe", "unsafe")


def _load(path: Path, grade_col: str, block_col: str | None, evidence_cols=None):
    """Read counts, grades and optional blocks from CSV or laws from JSON."""
    if path.suffix.lower() == ".json":
        if evidence_cols:
            raise ValueError("--evidence-cols applies to CSV input")
        payload = json.loads(path.read_text(encoding="utf-8"))
        safe = np.atleast_2d(np.asarray(payload["safe"], dtype=float))
        unsafe = np.atleast_2d(np.asarray(payload["unsafe"], dtype=float))
        counts = np.vstack([safe, unsafe])
        labels = np.array(["safe"] * len(safe) + ["unsafe"] * len(unsafe))
        return counts, labels, None, True, None

    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        header = reader.fieldnames or []
        if len(set(header)) != len(header):
            raise ValueError("Duplicate CSV column names")
        rows = list(reader)
    if not rows:
        raise SystemExit(f"{path}: no rows")
    if grade_col not in header:
        raise SystemExit(f"{path}: no column {grade_col!r}; columns are {header}")
    if block_col and block_col not in header:
        raise SystemExit(f"{path}: no column {block_col!r}; columns are {header}")
    skip = {grade_col} | ({block_col} if block_col else set())
    candidates = [c for c in header if c not in skip]
    if not candidates:
        raise SystemExit(f"{path}: no count columns besides {sorted(skip)}")

    if evidence_cols is not None:
        value_cols = list(evidence_cols)
        if len(set(value_cols)) != len(value_cols) or not set(value_cols) <= set(candidates):
            raise ValueError("Evidence columns must name distinct non-grade, non-block CSV fields")
    else:
        value_cols = [col for col in candidates if re.fullmatch(r"s[0-9]+", col)]
        if not value_cols and {"x", "y"} <= set(candidates):
            value_cols = ["x", "y"]
        if not value_cols:
            raise SystemExit(f"{path}: no recognised evidence schema; even if a column is numeric, "
                             "use --evidence-cols to select counts explicitly")
    omitted = [c for c in candidates if c not in value_cols]
    if omitted:
        nonnumeric, numeric = [], []
        for col in omitted:
            try:
                for row in rows:
                    float(row[col])
            except (TypeError, ValueError):
                nonnumeric.append(col)
            else:
                numeric.append(col)
        if nonnumeric:
            print(f"certlim: ignoring non-numeric column(s) {nonnumeric}", file=sys.stderr)
        if numeric:
            print(f"certlim: ignoring unselected numeric column(s) {numeric}", file=sys.stderr)
    print(f"certlim: evidence columns: {value_cols}", file=sys.stderr)

    labels, counts, blocks = [], [], []
    for row in rows:
        grade = str(row[grade_col]).strip().lower()
        if grade not in _GRADES:
            continue
        labels.append(grade)
        counts.append([float(row[c]) for c in value_cols])
        if block_col:
            blocks.append(row[block_col])
    if not labels:
        raise SystemExit(f"{path}: column {grade_col!r} has no 'safe'/'unsafe' values")
    if len(set(labels)) != 2:
        raise SystemExit(f"{path}: only grade {labels[0]!r} present; both are required")
    return np.array(counts, float), np.array(labels), (np.array(blocks) if block_col else None), False, value_cols


def _experiment(counts, labels, smoothing, already_laws, max_states):
    safe, unsafe = counts[labels == "safe"], counts[labels == "unsafe"]
    if already_laws:
        return Experiment(safe, unsafe, max_states=max_states)
    return Experiment.from_counts(safe, unsafe, smoothing=smoothing, max_states=max_states)


def _emit(payload: dict, out: str | None) -> None:
    text = json.dumps(payload, indent=2, default=float)
    if out:
        Path(out).write_text(text + "\n", encoding="utf-8")
        print(f"written: {out}")
    else:
        print(text)


def _add_common(p: argparse.ArgumentParser) -> None:
    p.add_argument("input", type=Path, help="CSV of per-unit counts, or JSON of laws")
    p.add_argument("--evidence-cols", nargs="+", metavar="COLUMN", help="ordered CSV count columns; otherwise use s0,s1,... or x,y")
    p.add_argument("--grade-col", default="grade", help="grade column (default: grade)")
    p.add_argument("--smoothing", type=float, default=0.5,
                   help="add-delta smoothing on counts (default: 0.5)")
    p.add_argument("--max-states", type=int, default=250_000,
                   help="ceiling on exact enumeration (default: 250000)")
    p.add_argument("--block-col", default=None,
                   help="metadata column to treat as a block, not a count")
    p.add_argument("--json", dest="out", default=None, help="write the report to this path")


def cmd_diagnose(args) -> int:
    counts, labels, _, laws, columns = _load(args.input, args.grade_col, args.block_col, args.evidence_cols)
    exp = _experiment(counts, labels, args.smoothing, laws, args.max_states)
    d = exp.diagnose()
    n_safe, n_unsafe = exp.n_models
    payload = {
        "evidence_columns": columns,
        "alphabet": exp.alphabet_size,
        "models": {"safe": n_safe, "unsafe": n_unsafe},
        "region": d.region,
        "n_star": d.n_star,
        "delta_one": d.delta_one,
        "pairwise_min_tv": d.pairwise_min_tv,
        "exact_collision": d.exact_collision,
        "stopping_bound": d.stopping_bound,
        "verdict": d.explain(),
    }
    if not args.out:
        print(f"region            {d.region}")
        print(f"Delta(1)          {d.delta_one:.6f}")
        print(f"min pairwise TV   {d.pairwise_min_tv:.6f}")
        print(f"n*                {d.n_star}   (search ceiling {d.stopping_bound})")
        print()
        print(d.explain())
        if d.delta_one <= 1e-9 < d.pairwise_min_tv:
            print()
            print("Note: every safe/unsafe pair is separated, yet the hulls still meet. "
                  "A pairwise criterion would have reported success here.")
        return 0
    _emit(payload, args.out)
    return 0


def cmd_frontier(args) -> int:
    counts, labels, _, laws, columns = _load(args.input, args.grade_col, args.block_col, args.evidence_cols)
    exp = _experiment(counts, labels, args.smoothing, laws, args.max_states)
    try:
        f = build_frontier(exp, n_grid=args.n, alpha=args.alpha, beta=args.beta)
    except StateSpaceTooLarge as exc:
        raise SystemExit(str(exc)) from exc
    if args.out:
        _emit({"evidence_columns": columns, "alpha": f.alpha, "beta": f.beta, "points": f.to_records(),
               "bound_holds": f.bound_holds(), "monotone": f.is_monotone()}, args.out)
        return 0
    print(f)
    print()
    print(f"bound holds: {f.bound_holds()}    monotone: {f.is_monotone()}")
    if args.target:
        n = f.units_for(args.target)
        print(f"units for decisiveness >= {args.target}: {n if n else 'not reached on this grid'}")
    return 0


def cmd_calibrate(args) -> int:
    counts, labels, blocks, laws, columns = _load(args.input, args.grade_col, args.block_col, args.evidence_cols)
    if laws:
        raise SystemExit("calibrate needs per-unit counts (CSV), not aggregate laws (JSON)")
    perm = permutation_test(counts, labels, blocks=blocks, n=args.n,
                            smoothing=args.smoothing, n_permutations=args.permutations,
                            seed=args.seed)
    boot = bootstrap_delta(counts, labels, n=args.n, smoothing=args.smoothing,
                           n_resamples=args.resamples, seed=args.seed)
    payload = {
        "evidence_columns": columns,
        "units": int(len(labels)),
        "permutation": {"observed": perm.observed, "p_value": perm.p_value,
                        "null_mean": perm.null_mean, "null_q95": perm.null_q95,
                        "n_permutations": perm.n_permutations,
                        "blocked": perm.blocked_by is not None},
        "bootstrap": {"median": boot.median, "ci_low": boot.ci_low,
                      "ci_high": boot.ci_high, "n_resamples": boot.n_resamples},
        "note": perm.note,
    }
    if args.out:
        _emit(payload, args.out)
        return 0
    print(f"units             {len(labels)}")
    print(perm)
    print(boot)
    print()
    print(perm.note)
    return 0


def cmd_rule(args) -> int:
    counts, labels, _, laws, columns = _load(args.input, args.grade_col, args.block_col, args.evidence_cols)
    exp = _experiment(counts, labels, args.smoothing, laws, args.max_states)
    rule = build_rule(exp, n=args.n, alpha=args.alpha, beta=args.beta)
    profile = rule.error_profile(exp)
    payload = {
        "evidence_columns": columns,
        "n": rule.n, "alphabet": rule.alphabet,
        "alpha": rule.alpha, "beta": rule.beta,
        "decisiveness": rule.decisiveness,
        "alert_floor": rule.alert_rate_floor(),
        "certify_prob": rule.certify_prob.tolist(),
        "reject_prob": rule.reject_prob.tolist(),
        "states": rule.states.tolist(),
        "error_profile": profile,
    }
    if args.out:
        _emit(payload, args.out)
        return 0
    print(f"block length n    {rule.n}")
    print(f"decisiveness      {rule.decisiveness:.6f}")
    print(f"forced Alert rate {rule.alert_rate_floor():.6f}")
    print(f"unsafe->certify   {profile['unsafe_to_certify']:.6f} (alpha {rule.alpha})")
    print(f"safe->reject      {profile['safe_to_reject']:.6f} (beta {rule.beta})")
    if exp.gate(rule.n):
        print()
        print("The hulls still intersect at this block length, so the optimal rule "
              "ignores the data and answers at the allowed error rates. That is the "
              "point to check diagnose() for delayed separation or a permanent collision.")
    return 0


def cmd_report(args) -> int:
    counts, labels, blocks, laws, columns = _load(args.input, args.grade_col, args.block_col, args.evidence_cols)
    exp = _experiment(counts, labels, args.smoothing, laws, args.max_states)
    write_report(
        args.output, exp, n_grid=args.n, alpha=args.alpha, beta=args.beta,
        rule_n=args.rule_n,
        unit_counts=None if laws else counts, labels=None if laws else labels,
        blocks=None if laws else blocks, smoothing=args.smoothing,
        n_permutations=args.permutations, n_resamples=args.resamples, seed=args.seed,
        title=args.title, subject=args.subject, timestamp=args.timestamp,
        notes=tuple(args.note or ()) + (("Evidence columns: " + ", ".join(columns),) if columns else ()),
    )
    print(f"written: {args.output}")
    if laws:
        print("certlim: aggregate laws given, so the calibration section is marked not run")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="certlim",
        description="Finite-evidence certification limits: what any Certify/Reject "
                    "rule can achieve from the evidence you have.",
    )
    p.add_argument("--version", action="version", version=f"certlim {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    d = sub.add_parser("diagnose", help="is the obstruction permanent, delayed, or absent?")
    _add_common(d)
    d.set_defaults(func=cmd_diagnose)

    f = sub.add_parser("frontier", help="Delta(n), decisiveness and the bound over a grid")
    _add_common(f)
    f.add_argument("--n", type=int, nargs="+", default=[1, 2, 3, 4, 5, 6, 8, 10])
    f.add_argument("--alpha", type=float, default=0.05)
    f.add_argument("--beta", type=float, default=0.05)
    f.add_argument("--target", type=float, default=None,
                   help="report the units needed for this decisiveness")
    f.set_defaults(func=cmd_frontier)

    c = sub.add_parser("calibrate", help="unit-blocked permutation test and whole-unit bootstrap")
    _add_common(c)
    c.add_argument("--n", type=int, default=1)
    c.add_argument("--permutations", type=int, default=999)
    c.add_argument("--resamples", type=int, default=2000)
    c.add_argument("--seed", type=int, default=0)
    c.set_defaults(func=cmd_calibrate)

    r = sub.add_parser("rule", help="build the deployable Certify/Alert/Reject rule")
    _add_common(r)
    r.add_argument("--n", type=int, default=1)
    r.add_argument("--alpha", type=float, default=0.05)
    r.add_argument("--beta", type=float, default=0.05)
    r.set_defaults(func=cmd_rule)

    rep = sub.add_parser("report", help="one-page self-contained HTML certification report")
    _add_common(rep)
    rep.add_argument("-o", "--output", default="certification_report.html")
    rep.add_argument("--n", type=int, nargs="+", default=[1, 2, 3, 4, 5, 6, 8, 10])
    rep.add_argument("--alpha", type=float, default=0.05)
    rep.add_argument("--beta", type=float, default=0.05)
    rep.add_argument("--rule-n", type=int, default=None,
                     help="block length for the decision table (default: n* if the gate opens)")
    rep.add_argument("--permutations", type=int, default=999)
    rep.add_argument("--resamples", type=int, default=2000)
    rep.add_argument("--seed", type=int, default=0)
    rep.add_argument("--title", default="Certification report")
    rep.add_argument("--subject", default=None, help="what is being certified")
    rep.add_argument("--timestamp", default=None,
                     help="free text for the header; omitting it keeps the output byte-identical")
    rep.add_argument("--note", action="append", help="extra scope caveat (repeatable)")
    rep.set_defaults(func=cmd_report)
    from .measurement_cli import add_commands
    add_commands(sub)
    return p


def _check_output_paths(args):
    """Refuse collisions between CLI inputs and any files the command writes."""
    sources = [getattr(args, name, None) for name in ("input", "registry", "ledger")]
    outputs = [getattr(args, "out", None), getattr(args, "output", None)]
    if args.command == "recheck":
        sources.append(args.rules)
    elif args.command == "design":
        outputs.append(args.rules)
    others = [Path(x).resolve() for x in sources if x]
    for out in (Path(x).resolve() for x in outputs if x):
        for path in others:
            if out == path or (out.exists() and path.exists() and out.samefile(path)):
                raise ValueError("Input files and output files must have distinct paths")
        others.append(out)


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        _check_output_paths(args)
        return args.func(args)
    except (KeyError, OSError, ValueError, RuntimeError, ArithmeticError) as exc:
        print(f"certlim: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
