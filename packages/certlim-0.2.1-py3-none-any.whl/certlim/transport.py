"""Whether separation established in one domain survives the move to another."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .experiment import Experiment

__all__ = ["TransportReport", "class_drift", "transport_margin"]


def _hausdorff_tv(a: np.ndarray, b: np.ndarray) -> float:
    """Hausdorff distance between two finite sets of laws under total variation."""
    a = np.atleast_2d(np.asarray(a, dtype=float))
    b = np.atleast_2d(np.asarray(b, dtype=float))
    d = 0.5 * np.abs(a[:, None, :] - b[None, :, :]).sum(axis=2)
    return float(max(d.min(axis=1).max(), d.min(axis=0).max()))


def class_drift(source: Experiment, deployment: Experiment) -> tuple[float, float]:
    """Per-class drift ``(rho_safe, rho_unsafe)`` between two domains.

    Both experiments must register the same grades over the same alphabet. This
    compares *class geometry*, not point predictions: an RMSE or an AUC that
    holds up across domains says nothing about whether the two hulls moved.
    """
    if source.alphabet_size != deployment.alphabet_size:
        raise ValueError("source and deployment must share an evidence alphabet")
    return (
        _hausdorff_tv(source.safe, deployment.safe),
        _hausdorff_tv(source.unsafe, deployment.unsafe),
    )


@dataclass(frozen=True)
class TransportReport:
    """Sufficient certificate for separation surviving a registered shift."""

    delta_source: float
    rho_safe: float
    rho_unsafe: float
    margin: float
    certified: bool
    delta_deployment_lower: float

    def __str__(self) -> str:
        verdict = "certified" if self.certified else "NOT certified"
        return (
            f"transport {verdict}: margin = {self.margin:.4f} "
            f"(source Delta {self.delta_source:.4f}, drift {self.rho_safe:.4f} + "
            f"{self.rho_unsafe:.4f})"
        )

    @property
    def note(self) -> str:
        if self.certified:
            return (
                "The deployment separation is at least the margin, so the source "
                "certificate survives the registered shift."
            )
        return (
            "A non-positive margin means the source evidence does not certify "
            "transport. It does not prove that the deployment domain collides: "
            "the bound is sufficient, not necessary."
        )


def transport_margin(source: Experiment, deployment: Experiment, n: int = 1) -> TransportReport:
    """Margin ``Delta_source - rho_safe - rho_unsafe`` at block length ``n``.

    A positive margin certifies that the deployment separation stays positive.
    The drift terms are measured on the same grades as the source, so a policy
    change that redefines which units count as safe is **not** a shift this
    covers -- it needs its own registration.
    """
    rho_s, rho_u = class_drift(source, deployment)
    if n > 1:
        rho_s *= n
        rho_u *= n
    delta_s = source.delta(n)
    margin = delta_s - rho_s - rho_u
    return TransportReport(
        delta_source=delta_s,
        rho_safe=rho_s,
        rho_unsafe=rho_u,
        margin=margin,
        certified=bool(margin > 0),
        delta_deployment_lower=max(0.0, margin),
    )
