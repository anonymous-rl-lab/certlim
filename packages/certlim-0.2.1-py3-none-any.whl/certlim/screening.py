"""Audit a frozen capacity screen against reference discharges."""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from numbers import Integral
from typing import Iterable, Literal

from scipy.stats import beta as beta_dist

from .core import _check_errors

Grade = Literal["qualified", "below", "unknown"]
Action = Literal["PASS", "FAIL", "REFER"]


@dataclass(frozen=True)
class ScreenRecord:
    """One record or identical grade/action group. Hours are the group's total."""

    grade: Grade
    action: Action
    count: int = 1
    reference_hours: float | None = None

    def __post_init__(self):
        if self.grade not in ("qualified", "below", "unknown") or self.action not in (
            "PASS",
            "FAIL",
            "REFER",
        ):
            raise ValueError("Expected qualified/below/unknown and PASS/FAIL/REFER")
        if (
            isinstance(self.count, bool)
            or not isinstance(self.count, Integral)
            or self.count < 1
        ):
            raise ValueError("count must be a positive integer")
        if self.reference_hours is not None and (
            not isfinite(self.reference_hours) or self.reference_hours < 0
        ):
            raise ValueError("reference_hours must be nonnegative and finite")


def audit_screen(
    records: Iterable[ScreenRecord],
    *,
    inference="archive",
    alpha=0.05,
    beta=0.05,
    confidence=0.95,
    min_decisiveness=None,
):
    """Evaluate frozen actions; optionally add simultaneous one-sided iid error bounds.

    In archive mode, the status describes only the adjudicated supplied records.
    In iid mode, each known grade must have representative independent records;
    repeated visits in the same cell or pack do not establish this assumption.
    Errors use *all* records of the corresponding known grade, including referrals.
    """
    _check_errors(alpha, beta)
    if inference not in ("archive", "iid") or not 0 < confidence < 1:
        raise ValueError("Choose archive or iid, and confidence in (0,1)")
    if min_decisiveness is not None and not 0 <= min_decisiveness <= 1:
        raise ValueError("min_decisiveness must lie in [0,1]")
    tail = (1 - confidence) / (2 if min_decisiveness is None else 4)
    decision_flags = []
    table = {
        g: dict.fromkeys(("PASS", "FAIL", "REFER"), 0)
        for g in ("below", "qualified", "unknown")
    }
    hours, missing_hours = 0.0, 0
    for row in records:
        table[row.grade][row.action] += int(row.count)
        if row.action != "REFER":
            if row.reference_hours is None:
                missing_hours += row.count
            else:
                hours += row.reference_hours
    total = sum(sum(row.values()) for row in table.values())
    if not total:
        raise ValueError("Empty screening ledger")
    sides, flags, coverage = {}, [], []
    for grade, wrong, budget in [("below", "PASS", alpha), ("qualified", "FAIL", beta)]:
        n = sum(table[grade].values())
        k = table[grade][wrong]
        d = n - table[grade]["REFER"]
        rate = k / n if n else None
        upper = None
        if n and inference == "iid":
            upper = 1.0 if k == n else float(beta_dist.isf(tail, k + 1, n - k))
        metric = upper if inference == "iid" else rate
        flags.append(None if metric is None else metric <= budget)
        lower = None
        if min_decisiveness is not None:
            if n and inference == "iid":
                lower = float(beta_dist.ppf(tail, d, n - d + 1)) if d else 0.0
            value = lower if inference == "iid" else (d / n if n else None)
            decision_flags.append(None if value is None else value >= min_decisiveness)
        if n:
            coverage.append(d / n)
        sides[grade] = dict(
            records=n,
            errors=k,
            empirical_error=rate,
            error_upper=upper,
            decisive=d,
            decisiveness_lower=lower,
            empirical_decisiveness=d / n if n else None,
        )
    if False in flags:
        status = (
            "budget_exceeded_on_archive"
            if inference == "archive"
            else "budgets_not_certified"
        )
    elif None in flags:
        status = "missing_grade"
    else:
        status = (
            "budgets_met_on_archive"
            if inference == "archive"
            else "passes_iid_error_bounds"
        )
    joint_status = None
    if decision_flags:
        checks = flags + decision_flags
        if False in checks:
            joint_status = (
                "requirements_not_certified"
                if inference == "iid"
                else "requirements_missed_on_archive"
            )
        elif None in checks:
            joint_status = "missing_grade"
        else:
            joint_status = (
                "joint_iid_bounds_pass"
                if inference == "iid"
                else "requirements_met_on_archive"
            )
    return dict(
        scope=inference,
        min_decisiveness_target=min_decisiveness,
        joint_status=joint_status,
        confidence=confidence if inference == "iid" else None,
        false_approval_budget=alpha,
        false_rejection_budget=beta,
        records=total,
        unknown_reference=sum(table["unknown"].values()),
        actions_by_grade=table,
        grade_metrics=sides,
        decisive=sum(r["PASS"] + r["FAIL"] for r in table.values()),
        min_empirical_class_decisiveness=min(coverage) if len(coverage) == 2 else None,
        reference_hours_on_decisions=None if missing_hours else hours,
        decisions_missing_reference_hours=missing_hours,
        status=status,
    )
