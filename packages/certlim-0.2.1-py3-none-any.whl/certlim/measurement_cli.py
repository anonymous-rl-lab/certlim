"""CLI adapters for registered channel comparisons and frozen-rule acceptance."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import numpy as np

from .cases import (
    PAPER_CASES,
    nasa_registry,
    read_registry,
    screening_example,
    read_ledger,
)
from .design import _grades, _counts, design_measurement, evaluate_rule
from .rules import ThreeStateRule
from .screening import audit_screen

SYMBOLS = {
    2: ["no_event", "event"],
    4: ["low_no_event", "low_event", "high_no_event", "high_event"],
}


def _payload(ch):
    if ch is None:
        return None
    return {
        **asdict(ch.audit),
        "decisiveness_lower": ch.lower,
        "all_rule_upper": ch.upper,
    }


def _rule(ch):
    rule = ch.rule
    return dict(
        symbols=SYMBOLS[rule.alphabet],
        n=rule.n,
        alpha=rule.alpha,
        beta=rule.beta,
        decisiveness=rule.decisiveness,
        states=rule.states.tolist(),
        certify_prob=rule.certify_prob.tolist(),
        reject_prob=rule.reject_prob.tolist(),
    )


def _load_rule(payload):
    k = len(payload["symbols"])
    if k not in SYMBOLS or payload["symbols"] != SYMBOLS[k]:
        raise ValueError("Unsupported symbol names or order")
    return ThreeStateRule(
        payload["n"],
        k,
        np.array(payload["certify_prob"]),
        np.array(payload["reject_prob"]),
        payload["alpha"],
        payload["beta"],
        payload["decisiveness"],
        np.array(payload["states"]),
    )


def _emit(payload, path):
    text = json.dumps(payload, indent=2, allow_nan=False) + "\n"
    if path:
        Path(path).write_text(text, encoding="utf-8")
    else:
        print(text, end="")


def _registry(args):
    return nasa_registry() if args.nasa else read_registry(args.registry)


def _digest(obj):
    encoded = json.dumps(
        obj, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _registry_digest(models, *, legacy=False):
    rows = []
    for m in sorted(models, key=lambda m: m.model):
        if legacy:
            rows.append(
                {
                    k: getattr(m, k)
                    for k in (
                        "model",
                        "q_high",
                        "low_lo",
                        "low_hi",
                        "high_lo",
                        "high_hi",
                    )
                }
            )
        else:
            rows.append([m.model, *map(str, m._exact)])
    return _digest(rows)


def design(args):
    models = _registry(args)
    result = design_measurement(
        models,
        n=args.n,
        alpha=args.alpha,
        beta=args.beta,
        target=args.target,
        safe_max=args.safe_max,
        unsafe_min=args.unsafe_min,
    )
    payload = dict(
        source_registry_sha256=_registry_digest(models),
        counts=result.counts,
        n=args.n,
        alpha=args.alpha,
        beta=args.beta,
        target=result.target,
        safe_max=float(args.safe_max),
        unsafe_min=float(args.unsafe_min),
        grade_cutoffs_exact=dict(safe_max=args.safe_max, unsafe_min=args.unsafe_min),
        status=result.status,
        event=_payload(result.event),
        band_event=_payload(result.band_event),
    )
    if args.rules:
        if result.event is None:
            raise ValueError("Both grades are required to export a lookup")
        if args.out and Path(args.out).resolve() == Path(args.rules).resolve():
            raise ValueError("Use distinct paths for the rules and the summary")
        frozen = dict(
            format="certlim.band-rule.v2",
            target=args.target,
            safe_max=args.safe_max,
            unsafe_min=args.unsafe_min,
            source_registry_sha256=payload["source_registry_sha256"],
            event=_rule(result.event),
            band_event=_rule(result.band_event),
        )
        frozen["sha256"] = _digest(frozen)
        _emit(frozen, args.rules)
    _emit(payload, args.out)
    return 0


def recheck(args):
    payload = json.loads(Path(args.rules).read_text(encoding="utf-8"))
    version = payload["format"]
    if version not in ("certlim.band-rule.v1", "certlim.band-rule.v2"):
        raise ValueError("Unknown frozen-rule format")
    if payload.pop("sha256", None) != _digest(payload):
        raise ValueError("Frozen lookup checksum mismatch")
    legacy = version == "certlim.band-rule.v1"
    target = args.target if legacy else payload["target"]
    if target is not None and (
        not isinstance(target, (int, float)) or not 0 <= target <= 1
    ):
        raise ValueError("A decision-rate target must be in [0,1]")
    if not legacy and (
        target is None or (args.target is not None and args.target != target)
    ):
        raise ValueError("Use the decision-rate target saved with this frozen rule")
    rule = _load_rule(payload[args.channel])
    from .core import _check_errors

    _check_errors(rule.alpha, rule.beta)
    models = _registry(args)
    safe, unsafe = _grades(models, payload["safe_max"], payload["unsafe_min"])
    scope = dict(
        target=target,
        target_source=("supplied_at_recheck" if target is not None else "unspecified")
        if legacy
        else "frozen",
        counts=_counts(models, safe, unsafe),
        source_registry_sha256=payload["source_registry_sha256"],
        target_registry_sha256=_registry_digest(models, legacy=legacy),
        channel=args.channel,
        alpha=rule.alpha,
        beta=rule.beta,
        status_scope="error_budgets_only",
    )
    if not safe or not unsafe:
        _emit(
            dict(
                joint_status="insufficient_grades",
                error_budgets_met=None,
                target_met=None,
                status="insufficient_grades",
                **scope,
            ),
            args.out,
        )
        return 0
    result = evaluate_rule(
        rule,
        models,
        safe_max=payload["safe_max"],
        unsafe_min=payload["unsafe_min"],
    )
    passed = (
        result.unsafe_approval_upper <= rule.alpha
        and result.safe_rejection_upper <= rule.beta
    )
    meets_target = result.decisiveness_lower >= target if target is not None else None
    if not passed:
        joint = "requirements_not_certified"
    elif target is None:
        joint = "target_unspecified"
    elif meets_target:
        joint = "joint_requirements_certified"
    else:
        joint = "requirements_not_certified"
    # status retains its v1 error-only interpretation for existing consumers.
    _emit(
        dict(
            joint_status=joint,
            error_budgets_met=passed,
            target_met=meets_target,
            **asdict(result),
            **scope,
            status="certified_on_target_set"
            if passed
            else "not_certified_on_target_set",
        ),
        args.out,
    )
    return 0


def audit(args):
    if args.example:
        groups = screening_example(args.example)
    else:
        groups = {"ledger": read_ledger(args.ledger)}
    _emit(
        {
            scope: audit_screen(
                rows,
                inference=args.inference,
                alpha=args.alpha,
                beta=args.beta,
                confidence=args.confidence,
                min_decisiveness=args.target,
            )
            for scope, rows in groups.items()
        },
        args.out,
    )
    return 0


def _inputs(cmd):
    src = cmd.add_mutually_exclusive_group(required=True)
    src.add_argument(
        "--nasa", action="store_true", help="use the published v25 confidence registry"
    )
    src.add_argument("--registry", help="CSV of registered joint-mass bounds")


def _budgets(cmd):
    cmd.add_argument(
        "--alpha",
        type=float,
        default=0.05,
        help="unsafe approval / below-spec PASS budget",
    )
    cmd.add_argument(
        "--beta",
        type=float,
        default=0.05,
        help="safe rejection / qualified FAIL budget",
    )


def add_commands(sub):
    cmd = sub.add_parser(
        "design", help="bound attainable decisions with and without the measured band"
    )
    _inputs(cmd)
    _budgets(cmd)
    cmd.add_argument("--n", type=int, default=5)
    cmd.add_argument("--safe-max", default="0.15")
    cmd.add_argument("--unsafe-min", default="0.35")
    cmd.add_argument(
        "--target", type=float, required=True, help="minimum useful decision fraction"
    )
    cmd.add_argument("--rules", help="export frozen randomised lookups as JSON")
    cmd.add_argument("--json", dest="out")
    cmd.set_defaults(func=design)
    cmd = sub.add_parser(
        "recheck", help="audit a frozen lookup against target model rectangles"
    )
    cmd.add_argument("rules")
    cmd.add_argument(
        "--target",
        type=float,
        help="decision-rate target for v1 rules lacking a stored target",
    )
    cmd.add_argument("--channel", choices=("event", "band_event"), default="band_event")
    _inputs(cmd)
    cmd.add_argument("--json", dest="out")
    cmd.set_defaults(func=recheck)
    cmd = sub.add_parser(
        "audit", help="count reference discharges, decisions and class-specific errors"
    )
    src = cmd.add_mutually_exclusive_group(required=True)
    src.add_argument(
        "--ledger", help="CSV with grade, action, optional count and reference_hours"
    )
    src.add_argument("--example", choices=PAPER_CASES)
    _budgets(cmd)
    cmd.add_argument("--inference", choices=("archive", "iid"), default="archive")
    cmd.add_argument(
        "--target",
        type=float,
        help="joint minimum decision rate within each reference grade",
    )
    cmd.add_argument("--confidence", type=float, default=0.95)
    cmd.add_argument("--json", dest="out")
    cmd.set_defaults(func=audit)
