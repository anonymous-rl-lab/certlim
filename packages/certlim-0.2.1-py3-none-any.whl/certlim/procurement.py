"""Choosing which evidence to buy, once more than one option is valid.

Separation says whether a channel *can* certify. Procurement says which of the
qualifying channels to pay for. The two are different questions and the second
only makes sense after the first.

Costs stay as a vector -- units, time, energy, peak stress, hardware -- and are
never collapsed into one currency. A plan is dropped only when another plan is
no worse on every recorded axis and strictly better on one. If two plans were
measured on different cost ledgers, they are not comparable and this module will
tell you so rather than rank them.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = ["Plan", "ProcurementResult", "screen"]


@dataclass(frozen=True)
class Plan:
    """One acquisition option: a channel, a block length, and its measured cost."""

    name: str
    n: int
    decisiveness: float
    cost: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.n < 1:
            raise ValueError(f"plan {self.name!r}: n must be at least 1")
        if not 0.0 <= self.decisiveness <= 1.0:
            raise ValueError(f"plan {self.name!r}: decisiveness must lie in [0, 1]")
        for axis, value in self.cost.items():
            if value is None or float(value) < 0:
                raise ValueError(f"plan {self.name!r}: cost axis {axis!r} must be non-negative")

    def dominates(self, other: "Plan", axes: tuple[str, ...]) -> bool:
        if self.decisiveness < other.decisiveness - 1e-12:
            return False
        strictly_better = self.decisiveness > other.decisiveness + 1e-12
        for axis in axes:
            if float(self.cost[axis]) > float(other.cost[axis]) + 1e-12:
                return False
            if float(self.cost[axis]) < float(other.cost[axis]) - 1e-12:
                strictly_better = True
        return strictly_better


@dataclass(frozen=True)
class ProcurementResult:
    """Feasible plans, the non-dominated subset, and what was excluded."""

    feasible: tuple[Plan, ...]
    frontier: tuple[Plan, ...]
    infeasible: tuple[Plan, ...]
    axes: tuple[str, ...]
    target: float

    def __str__(self) -> str:
        if not self.feasible:
            return f"no plan reaches decisiveness {self.target:.3f}"
        lines = [f"non-dominated at decisiveness >= {self.target:.3f} on axes {list(self.axes)}:"]
        for p in self.frontier:
            costs = ", ".join(f"{a}={p.cost[a]:g}" for a in self.axes)
            lines.append(f"  {p.name} (n={p.n}) D={p.decisiveness:.4f}  {costs}")
        dropped = [p for p in self.feasible if p not in self.frontier]
        for p in dropped:
            lines.append(f"  dominated: {p.name} (n={p.n})")
        return "\n".join(lines)


def screen(plans, target: float, axes: tuple[str, ...] | None = None) -> ProcurementResult:
    """Keep the plans that reach ``target`` decisiveness and are non-dominated.

    Parameters
    ----------
    plans:
        :class:`Plan` objects. Every plan must record the same cost axes; a
        missing axis raises rather than being treated as zero, because an
        unmeasured cost is not a free cost.
    target:
        Required worst-case decisiveness. Use an achievable value with a
        confidence statement behind it, not the theoretical upper bound: the
        bound says what no rule can exceed, not what this rule attains.
    """
    plans = list(plans)
    if not plans:
        raise ValueError("no plans supplied")
    if not 0.0 < target <= 1.0:
        raise ValueError("target must lie in (0, 1]")

    if axes is None:
        common = set(plans[0].cost)
        for p in plans:
            common &= set(p.cost)
        axes = tuple(sorted(common))
    for p in plans:
        missing = [a for a in axes if a not in p.cost]
        if missing:
            raise ValueError(
                f"plan {p.name!r} is missing cost axes {missing}; plans measured on "
                f"different ledgers cannot be ranked against each other"
            )
    if not axes:
        raise ValueError("plans share no cost axis, so none can be compared")

    feasible = [p for p in plans if p.decisiveness >= target - 1e-12]
    infeasible = [p for p in plans if p not in feasible]
    front = [p for p in feasible if not any(q.dominates(p, axes) for q in feasible if q is not p)]
    front.sort(key=lambda p: (tuple(float(p.cost[a]) for a in axes), -p.decisiveness))
    return ProcurementResult(
        feasible=tuple(feasible),
        frontier=tuple(front),
        infeasible=tuple(infeasible),
        axes=tuple(axes),
        target=float(target),
    )
