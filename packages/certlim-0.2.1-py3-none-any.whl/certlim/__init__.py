"""certlim -- finite-evidence certification limits for safety-critical decisions.

The question this package answers is not "is my model accurate?" but "does the
evidence I can actually buy support a reliable Certify or Reject decision, and if
not, is that fixable by collecting more of the same or only by changing the
measurement?"

Given two registered classes of systems -- those that are safe under a proposed
policy and those that are unsafe -- and the evidence law each induces, it computes

* ``Delta(n)``, the exact composite separation from ``n`` independent units;
* the exact best achievable three-state decisiveness under two-sided error control;
* whether an obstruction is temporary (repetition opens it at a finite ``n``) or
  permanent (only a different measurement can);
* the deployable Certify / Alert / Reject rule itself;
* finite-sample calibration, transport margin, and procurement screening.

Quick start
-----------
>>> import numpy as np
>>> from certlim import Experiment, frontier
>>> exp = Experiment(safe=[[0.25, 0.75], [0.75, 0.25]], unsafe=[[0.5, 0.5]])
>>> exp.diagnose().region
'delayed'
>>> exp.n_star()
2
>>> round(exp.delta(2), 6)
0.125
>>> round(exp.decisiveness(1), 6)   # hulls intersect: no rule beats alpha + beta
0.1

Scope
-----
Every number is relative to the registered classes and to the evidence alphabet.
The package computes population geometry exactly; it does not know whether your
classes are correctly registered, whether your grades were identified by a
reference experiment rather than by the channel under test, or whether your
sampling unit is the physical unit it should be. Those are design decisions and
the package will not make them for you.
"""

from __future__ import annotations

from .calibration import (
    BootstrapResult,
    PermutationResult,
    bootstrap_delta,
    permutation_test,
)
from .core import (
    DEFAULT_MAX_STATES,
    ZERO_TOL,
    StateSpaceTooLarge,
    block_laws,
    count_states,
    decisiveness,
    hull_tv,
    multinomial_law,
    n_states,
    separating_statistic,
    sion_gap,
)
from .experiment import Diagnosis, Experiment, Separator, pairwise_min_tv
from .frontier import Frontier, FrontierPoint, frontier
from .procurement import Plan, ProcurementResult, screen
from .report import build as certification_report
from .report import write as write_report
from .quantize import NestedQuantizer, check_data_processing, coarsen_counts
from .rules import ALERT, CERTIFY, REJECT, Decision, ThreeStateRule, build_rule
from .transport import TransportReport, class_drift, transport_margin

from .design import BandModel, ChannelBounds, MeasurementDesign, RuleAudit, design_measurement, evaluate_rule, registry_from_counts
from .screening import ScreenRecord, audit_screen
from .cases import nasa_likelihood_ratio_rule, nasa_registry, read_registry, read_ledger, screening_example

__version__ = "0.2.1"

__all__ = [
    "__version__",
    "BandModel", "ChannelBounds", "MeasurementDesign", "RuleAudit",
    "registry_from_counts", "design_measurement", "evaluate_rule",
    "nasa_likelihood_ratio_rule", "ScreenRecord", "audit_screen", "nasa_registry", "read_registry", "read_ledger", "screening_example",
    # experiment and geometry
    "Experiment",
    "Diagnosis",
    "Separator",
    "pairwise_min_tv",
    "hull_tv",
    "decisiveness",
    "sion_gap",
    "separating_statistic",
    # frontier
    "frontier",
    "Frontier",
    "FrontierPoint",
    # rule
    "build_rule",
    "ThreeStateRule",
    "Decision",
    "CERTIFY",
    "ALERT",
    "REJECT",
    # evidence menus
    "NestedQuantizer",
    "coarsen_counts",
    "check_data_processing",
    # finite-sample calibration
    "permutation_test",
    "bootstrap_delta",
    "PermutationResult",
    "BootstrapResult",
    # deployment
    "transport_margin",
    "class_drift",
    "TransportReport",
    # report
    "certification_report",
    "write_report",
    # procurement
    "screen",
    "Plan",
    "ProcurementResult",
    # low-level
    "count_states",
    "n_states",
    "multinomial_law",
    "block_laws",
    "StateSpaceTooLarge",
    "DEFAULT_MAX_STATES",
    "ZERO_TOL",
]
