"""The deployable artifact: a three-state Certify / Alert / Reject rule."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .core import count_states, _decision_solution
from .experiment import Experiment

__all__ = ["Decision", "ThreeStateRule", "build_rule"]

CERTIFY = "certify"
ALERT = "alert"
REJECT = "reject"


@dataclass(frozen=True)
class Decision:
    """One decision, with the probabilities it was drawn from."""

    outcome: str
    p_certify: float
    p_reject: float
    p_alert: float
    state: int


class _FrozenArray:
    """Store immutable bytes and return a fresh array header on each access."""

    def __set_name__(self, owner, name):
        self.key = "_" + name

    def __get__(self, obj, owner=None):
        if obj is None:
            raise AttributeError(self.key)
        data, dtype, shape = getattr(obj, self.key)
        return np.frombuffer(data, dtype=dtype).reshape(shape)

    def __set__(self, obj, value):
        array = np.asarray(value)
        if array.dtype.kind not in "iuf":
            raise ValueError(f"Expected a numeric array for {self.key[1:]}")
        object.__setattr__(
            obj, self.key, (array.tobytes(order="C"), array.dtype, array.shape)
        )


@dataclass(frozen=True)
class ThreeStateRule:
    """Randomised lookup for a fixed evidence alphabet and block length.

    For each count state, the two stored probabilities give Certify and Reject.
    The remaining probability gives Alert. Use the originating solver's bounds
    for its registered experiment and re-evaluate the lookup on a new domain.
    """

    n: int
    alphabet: int
    certify_prob: np.ndarray = _FrozenArray()
    reject_prob: np.ndarray = _FrozenArray()
    alpha: float
    beta: float
    decisiveness: float
    states: np.ndarray = _FrozenArray()

    # ----------------------------------------------------------------- lookups
    def _state_index(self, counts) -> int:
        values = np.asarray(counts)
        if (
            values.dtype.kind not in "iuf"
            or not np.isfinite(values).all()
            or not np.all(values == np.floor(values))
            or (values > self.n).any()
            or (values < 0).any()
        ):
            raise ValueError(
                "counts must be non-negative whole numbers within the block"
            )
        counts = values.astype(int).ravel()
        if counts.size != self.alphabet:
            raise ValueError(f"expected {self.alphabet} counts, got {counts.size}")
        if counts.sum() != self.n:
            raise ValueError(f"counts must sum to n={self.n}, got {int(counts.sum())}")
        if (counts < 0).any():
            raise ValueError("counts must be non-negative")
        matches = np.flatnonzero((self.states == counts).all(axis=1))
        if matches.size != 1:
            raise ValueError(f"count vector {counts.tolist()} is not a valid state")
        return int(matches[0])

    def probabilities(self, counts) -> tuple[float, float, float]:
        """``(P(Certify), P(Reject), P(Alert))`` for one observed block."""
        s = self._state_index(counts)
        c = float(self.certify_prob[s])
        r = float(self.reject_prob[s])
        return c, r, max(0.0, 1.0 - c - r)

    def decide(self, counts, rng: np.random.Generator | None = None) -> Decision:
        """Draw a verdict for one observed block of ``n`` units.

        The optimal rule is genuinely randomised. Pass a seeded ``rng`` when the
        decision must be reproducible, which in a certification workflow it
        normally must.
        """
        s = self._state_index(counts)
        c, r, a = self.probabilities(counts)
        gen = np.random.default_rng() if rng is None else rng
        draw = gen.random()
        if draw < c:
            outcome = CERTIFY
        elif draw < c + r:
            outcome = REJECT
        else:
            outcome = ALERT
        return Decision(outcome=outcome, p_certify=c, p_reject=r, p_alert=a, state=s)

    def most_likely(self, counts) -> str:
        """Deterministic reading of the verdict with the largest probability.

        Convenient for reporting, but it is *not* the optimal rule and does not
        inherit the error guarantees. Use :meth:`decide` for anything binding.
        """
        c, r, a = self.probabilities(counts)
        return max(((c, CERTIFY), (r, REJECT), (a, ALERT)))[1]

    def error_profile(self, experiment: Experiment) -> dict:
        """Realised worst-case side errors and decisiveness on a given experiment.

        Run this against the experiment the rule was built for as a self-check,
        and against a deployment-domain experiment to see what the shift costs.
        """
        safe, unsafe = experiment._blocks(self.n)  # noqa: SLF001 - same package
        if safe.shape[1] != self.certify_prob.size:
            raise ValueError("experiment state space does not match the rule")
        certify_unsafe = float((unsafe @ self.certify_prob).max())
        reject_safe = float((safe @ self.reject_prob).max())
        decisive = float(
            np.min(np.vstack([safe, unsafe]) @ (self.certify_prob + self.reject_prob))
        )
        return {
            "unsafe_to_certify": certify_unsafe,
            "safe_to_reject": reject_safe,
            "worst_case_decisiveness": decisive,
            "alpha_respected": certify_unsafe <= self.alpha,
            "beta_respected": reject_safe <= self.beta,
        }

    def alert_rate_floor(self) -> float:
        """Fraction of decisions that must be ``Alert`` on the worst model."""
        return 1.0 - self.decisiveness


def build_rule(
    experiment: Experiment, n: int = 1, alpha: float = 0.05, beta: float = 0.05
) -> ThreeStateRule:
    """Construct a feasible rule and verify its worst-case rate against a dual bound."""
    safe, unsafe = experiment._blocks(n)
    c, r, lower = _decision_solution(safe, unsafe, alpha, beta)
    return ThreeStateRule(
        n=int(n),
        alphabet=experiment.alphabet_size,
        certify_prob=c,
        reject_prob=r,
        alpha=float(alpha),
        beta=float(beta),
        decisiveness=lower,
        states=count_states(
            n, experiment.alphabet_size, max_states=experiment.max_states
        ),
    )
