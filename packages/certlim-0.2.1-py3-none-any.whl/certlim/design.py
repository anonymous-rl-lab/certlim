"""Two-band event measurements under a common registered risk/evidence rectangle.

The four masses are (1-q-x, x, q-y, y), where x and y are event *joint*
masses in the low and high bands. One model and one point in its rectangle
are held fixed for all conditionally independent readings in a block.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import comb, isfinite
from fractions import Fraction
from typing import Iterable

import numpy as np
from scipy.optimize import linprog
from scipy.stats import beta as beta_dist, binom

from .core import count_states, n_states, _check_errors
from .rules import ThreeStateRule


@dataclass(frozen=True)
class BandModel:
    """One registered model. Bounds are joint masses; their sum bounds event risk."""

    model: str
    q_high: float
    low_lo: float
    low_hi: float
    high_lo: float
    high_hi: float

    _exact: tuple[Fraction, ...] = field(init=False, repr=False)

    def __post_init__(self):
        if not isinstance(self.model, str) or not self.model.strip():
            raise ValueError("A registered model needs a nonempty identifier")
        names = ("q_high", "low_lo", "low_hi", "high_lo", "high_hi")
        q, a, b, c, d = (Fraction(str(getattr(self, key))) for key in names)
        # Preserve the existing tolerance on physical band caps; no tolerance is
        # used to move an object across a reference grade threshold.
        tol = Fraction(1, 10**14)
        if not (0 <= q <= 1 and 0 <= a <= b <= 1 - q + tol and 0 <= c <= d <= q + tol):
            raise ValueError(f"Invalid band probabilities for {self.model}")
        exact = (q, min(a, 1 - q), min(b, 1 - q), min(c, q), min(d, q))
        object.__setattr__(self, "_exact", exact)
        # Preserve v1 float-valued LP inputs and v1 registry fingerprints.
        # Grade thresholds and v2 fingerprints use the exact tuple above.
        q_float = float(self.q_high)
        object.__setattr__(self, "q_high", q_float)
        for name, cap in zip(names[1:], (1 - q_float, 1 - q_float, q_float, q_float)):
            object.__setattr__(self, name, min(float(getattr(self, name)), cap))


def registry_from_counts(rows, *, confidence=0.95):
    """Fixed-horizon, simultaneous Bonferroni/Clopper-Pearson rectangles.

    Rows contain model, q_high, and (low_hits, low_total, high_hits, high_total).
    Each stratum uses binomial sampling. Empty strata retain [0,1] conditional
    event risk. The allocation covers both strata of every submitted model.
    """
    rows = list(rows)
    if not rows or not 0 < confidence < 1:
        raise ValueError("Provide a nonempty fixed registry and confidence in (0,1)")
    tail = (1 - confidence) / (4 * len(rows))

    def interval(h, n):
        if (
            any(
                isinstance(v, (bool, np.bool_)) or not isinstance(v, (int, np.integer))
                for v in (h, n)
            )
            or not 0 <= h <= n
        ):
            raise ValueError("Event counts must be integers with 0 <= hits <= total")
        lo = beta_dist.ppf(tail, h, n - h + 1) if h else 0.0
        hi = beta_dist.isf(tail, h + 1, n - h) if h < n else 1.0
        return lo, hi

    models = []
    for row in rows:
        q = row["q_high"]
        lo = interval(row["low_hits"], row["low_total"])
        hi = interval(row["high_hits"], row["high_total"])
        models.append(
            BandModel(
                row["model"], q, (1 - q) * lo[0], (1 - q) * lo[1], q * hi[0], q * hi[1]
            )
        )
    _unique(models)
    return models


def _unique(models):
    if len({m.model for m in models}) != len(models):
        raise ValueError("Registered model identifiers must be unique")


@dataclass(frozen=True)
class RuleAudit:
    unsafe_approval_upper: float
    safe_rejection_upper: float
    decisiveness_lower: float


@dataclass(frozen=True)
class ChannelBounds:
    lower: float
    upper: float
    audit: RuleAudit
    rule: ThreeStateRule


@dataclass(frozen=True)
class MeasurementDesign:
    counts: dict[str, int]
    event: ChannelBounds | None
    band_event: ChannelBounds | None
    target: float
    status: str


def _grades(models, safe_max, unsafe_min):
    _unique(models)
    safe_max = Fraction(str(safe_max))
    unsafe_min = Fraction(str(unsafe_min))
    if not 0 <= safe_max < unsafe_min <= 1:
        raise ValueError("Require 0 <= safe_max < unsafe_min <= 1")
    safe = [m for m in models if m._exact[2] + m._exact[4] <= safe_max]
    unsafe = [m for m in models if m._exact[1] + m._exact[3] >= unsafe_min]
    return safe, unsafe


def _counts(models, safe, unsafe):
    return dict(
        registered=len(models),
        safe=len(safe),
        unsafe=len(unsafe),
        unresolved=len(models) - len(safe) - len(unsafe),
    )


def _check_size(n, k, size):
    if isinstance(n, bool) or not isinstance(n, (int, np.integer)) or n < 1:
        raise ValueError("n must be a positive integer")
    states = n_states(n, k)
    entries = size * states * (n + 1) ** (1 if k == 2 else 2)
    if entries > 8_000_000 or states > 1000:
        raise ValueError(
            "The dense Bernstein bank exceeds the solver's memory limit; reduce n or registry size"
        )


def _bernstein(n, m, lo, hi):
    """Degree-n coefficients for m Bernoulli draws on [lo,hi], without inversion."""
    out = np.zeros((len(lo), n + 1, m + 1))
    for r in range(m + 1):
        low = binom.pmf(np.arange(m - r + 1), m - r, lo[:, None])
        high = binom.pmf(np.arange(r + 1), r, hi[:, None])
        probs = np.zeros((len(lo), m + 1))
        for a in range(r + 1):
            probs[:, a : a + m - r + 1] += high[:, a, None] * low
        for i in range(r, n - m + r + 1):
            weight = comb(i, r) * comb(n - i, m - r) / comb(n, m)
            out[:, i, :] += weight * probs
    return out


def _banks(models, n, k, grid):
    """Outer law bank of Bernstein coefficients and inner bank of attainable laws."""
    q, a, b, c, d = np.array(
        [[m.q_high, m.low_lo, m.low_hi, m.high_lo, m.high_hi] for m in models],
        dtype=float,
    ).T
    states = count_states(n, k)
    x = np.linspace(0, 1, n + 1)
    if k == 2:
        lo, hi = a + c, b + d
        outer = _bernstein(n, n, lo, hi)[:, :, states[:, 1]]
        inner = (
            binom.pmf(
                states[:, 1], n, (lo[:, None] + (hi - lo)[:, None] * x)[:, :, None]
            )
            if grid
            else None
        )
    else:

        def rate(v, mass):
            return np.clip(
                np.divide(v, mass, out=np.zeros_like(v), where=mass > 0), 0, 1
            )

        la, lb, hc, hd = rate(a, 1 - q), rate(b, 1 - q), rate(c, q), rate(d, q)
        outer = np.empty((len(q), n + 1, n + 1, len(states)))
        inner = np.empty_like(outer) if grid else None
        for m in range(n + 1):
            left = _bernstein(n, m, la, lb)
            right = _bernstein(n, n - m, hc, hd)
            if grid:
                lg = binom.pmf(
                    np.arange(m + 1),
                    m,
                    (la[:, None] + (lb - la)[:, None] * x)[:, :, None],
                )
                hg = binom.pmf(
                    np.arange(n - m + 1),
                    n - m,
                    (hc[:, None] + (hd - hc)[:, None] * x)[:, :, None],
                )
            pm = binom.pmf(m, n, 1 - q)[:, None, None]
            for s in np.flatnonzero(states[:, :2].sum(axis=1) == m):
                i, j = states[s, [1, 3]]
                outer[:, :, :, s] = pm * left[:, :, i, None] * right[:, None, :, j]
                if grid:
                    inner[:, :, :, s] = pm * lg[:, :, i, None] * hg[:, None, :, j]
    banks = [outer, inner] if grid else [outer]
    for bank in banks:
        if not np.isfinite(bank).all() or not np.allclose(
            bank.sum(axis=-1), 1, rtol=0, atol=1e-10
        ):
            raise ArithmeticError("Invalid probability bank")
    return tuple(bank.reshape(-1, len(states)) for bank in banks)


def _solve(safe, unsafe, alpha, beta):
    """Cutting-plane LP and dual upper bound with variable-box residual correction."""
    k = safe.shape[1]
    c_obj = np.zeros(2 * k + 1)
    c_obj[-1] = 1.0
    simplex = np.column_stack((np.eye(k), np.eye(k), np.zeros(k)))
    banks = (unsafe, safe, safe, unsafe)
    active = [{0} for _ in banks]
    for _ in range(350):
        blocks, rhs = [simplex], [np.ones(k)]
        for j, bank in enumerate(banks):
            laws = bank[sorted(active[j])]
            rows = np.zeros((len(laws), 2 * k + 1))
            if j < 2:
                rows[:, j * k : (j + 1) * k] = laws
            else:
                rows[:, :k] = rows[:, k : 2 * k] = -laws
                rows[:, -1] = 1
            blocks.append(rows)
            rhs.append(np.full(len(laws), (alpha, beta, 0.0, 0.0)[j]))
        A, b = np.vstack(blocks), np.concatenate(rhs)
        sol = linprog(
            -c_obj,
            A_ub=A,
            b_ub=b,
            bounds=(0, 1),
            method="highs",
            options={
                "primal_feasibility_tolerance": 1e-9,
                "dual_feasibility_tolerance": 1e-9,
            },
        )
        if not sol.success:
            raise RuntimeError(sol.message)
        c, r, t = sol.x[:k], sol.x[k : 2 * k], sol.x[-1]
        violations = (
            unsafe @ c - alpha,
            safe @ r - beta,
            t - safe @ (c + r),
            t - unsafe @ (c + r),
        )
        if max(v.max() for v in violations) <= 5e-9:
            dual = np.maximum(0, -sol.ineqlin.marginals)
            # Valid for any nonnegative dual, since all variables lie in [0,1].
            upper = b @ dual + np.maximum(0, c_obj - A.T @ dual).sum()
            return c, r, min(1.0, float(upper) + 1e-10)
        for chosen, v in zip(active, violations):
            bad = np.flatnonzero(v > 2e-9)
            chosen.update(bad[np.argsort(v[bad])[-6:]])
    raise RuntimeError("Constraint generation did not converge")


def _audit(s, u, c, r):
    return RuleAudit(
        float((u @ c).max()),
        float((s @ r).max()),
        float(min((s @ (c + r)).min(), (u @ (c + r)).min())),
    )


def _fit(safe, unsafe, n, k, alpha, beta):
    s, sg = _banks(safe, n, k, True)
    u, ug = _banks(unsafe, n, k, True)
    c, r, _ = _solve(s, u, alpha, beta)
    _, _, upper = _solve(sg, ug, alpha, beta)
    c, r = np.maximum(c, 0), np.maximum(r, 0)
    scale = np.maximum(1, c + r)
    c, r = c / scale, r / scale
    audit = _audit(s, u, c, r)
    for arr, limit, err in [
        (c, alpha, audit.unsafe_approval_upper),
        (r, beta, audit.safe_rejection_upper),
    ]:
        if err > 0:
            arr *= min(1, limit * (1 - 1e-10) / err)
    audit = _audit(s, u, c, r)
    lower = max(0.0, audit.decisiveness_lower - 1e-11)
    if (
        lower > upper
        or audit.unsafe_approval_upper > alpha
        or audit.safe_rejection_upper > beta
    ):
        raise ArithmeticError("Numerical certificate failed its final check")
    rule = ThreeStateRule(n, k, c, r, alpha, beta, lower, count_states(n, k))
    return ChannelBounds(lower, upper, audit, rule)


def design_measurement(
    models: Iterable[BandModel],
    *,
    n=1,
    alpha=0.05,
    beta=0.05,
    safe_max=0.15,
    unsafe_min=0.35,
    target=0.25,
):
    """Compare the event alone to band plus event on exactly the same graded models."""
    models = list(models)
    _check_errors(alpha, beta)
    if not isfinite(target) or not 0 <= target <= 1:
        raise ValueError("target must be in [0,1]")
    safe, unsafe = _grades(models, safe_max, unsafe_min)
    counts = _counts(models, safe, unsafe)
    _check_size(n, 4, len(safe) + len(unsafe))
    if not safe or not unsafe:
        return MeasurementDesign(counts, None, None, target, "insufficient_grades")
    event = _fit(safe, unsafe, n, 2, alpha, beta)
    fine = _fit(safe, unsafe, n, 4, alpha, beta)
    if event.lower >= target:
        status = "event_sufficient"
    elif event.upper < target <= fine.lower:
        status = "additional_band_required"
    elif fine.upper < target:
        status = "neither_reaches_target"
    elif fine.lower >= target:
        status = "band_sufficient_event_unresolved"
    else:
        status = "unresolved"
    return MeasurementDesign(counts, event, fine, target, status)


def evaluate_rule(
    rule: ThreeStateRule, models: Iterable[BandModel], *, safe_max=0.15, unsafe_min=0.35
):
    """Audit an unchanged lookup on target rectangles, with conditional iid block laws."""
    safe, unsafe = _grades(list(models), safe_max, unsafe_min)
    if not safe or not unsafe:
        raise ValueError("Both target grades are required for a two-sided rule audit")
    k, n = rule.alphabet, rule.n
    if k not in (2, 4):
        raise ValueError("Expected event or band-event alphabet")
    _check_size(n, k, len(safe) + len(unsafe))
    if not np.array_equal(rule.states, count_states(n, k)):
        raise ValueError("Lookup uses a different state ordering")
    c, r = np.asarray(rule.certify_prob), np.asarray(rule.reject_prob)
    if (
        c.shape != r.shape
        or c.shape != (len(rule.states),)
        or not np.isfinite(c + r).all()
        or (c < 0).any()
        or (r < 0).any()
        or (c + r > 1 + 1e-14).any()
    ):
        raise ValueError("Invalid lookup probabilities")
    return _audit(_banks(safe, n, k, False)[0], _banks(unsafe, n, k, False)[0], c, r)
