"""Load small v25 examples or a user's registered measurements and action ledgers."""

from __future__ import annotations

import csv
import gzip
from importlib.resources import files
from pathlib import Path

from .design import BandModel
from .screening import ScreenRecord

PAPER_CASES = ("cetl", "relib", "leaf")


def _bands(reader):
    return [
        BandModel(
            r["model"],
            *(
                r[k]
                for k in ("q_high", "low_lo", "low_hi", "high_lo", "high_hi")
            ),
        )
        for r in reader
    ]


def read_registry(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return _bands(csv.DictReader(f))


def nasa_registry():
    """Published simultaneous confidence inputs for all 1,539 NASA stage-policy objects."""
    with files("certlim").joinpath("data", "nasa.csv.gz").open("rb") as f:
        with gzip.open(f, "rt", encoding="utf-8", newline="") as source:
            return _bands(csv.DictReader(source))


def _record(row):
    count = row.get("count") or "1"
    hrs = row.get("reference_hours")
    return ScreenRecord(
        row["grade"],
        row["action"],
        int(count),
        float(hrs) if hrs not in (None, "") else None,
    )


def read_ledger(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return [_record(r) for r in csv.DictReader(f)]


def screening_example(name):
    """Map each published scope to its losslessly aggregated grade/action counts."""
    if name not in PAPER_CASES:
        raise ValueError(f"Pick one of {PAPER_CASES}")
    out = {}
    with (
        files("certlim")
        .joinpath("data", "capacity.csv")
        .open(encoding="utf-8", newline="") as f
    ):
        for row in csv.DictReader(f):
            if row["case"] == name:
                out.setdefault(row["scope"], []).append(_record(row))
    return out


def nasa_likelihood_ratio_rule():
    """Frozen five-reading likelihood-ratio comparator from the v25 pooled registry."""
    import numpy as np
    from .core import count_states
    from .rules import ThreeStateRule

    with (
        files("certlim")
        .joinpath("data", "nasa_lr.csv")
        .open(encoding="utf-8", newline="") as f
    ):
        rows = {
            tuple(int(r[k]) for k in ("low_no", "low_cut", "high_no", "high_cut")): (
                float(r["certify"]),
                float(r["reject"]),
            )
            for r in csv.DictReader(f)
        }
    states = count_states(5, 4)
    c, r = np.array([rows[tuple(s)] for s in states]).T
    # CSV rounding in published coordinates can put a state infinitesimally off the simplex.
    scale = np.maximum(1, np.maximum(c, 0) + np.maximum(r, 0))
    c, r = np.maximum(c, 0) / scale, np.maximum(r, 0) / scale
    from .design import evaluate_rule

    rule = ThreeStateRule(5, 4, c, r, 0.05, 0.05, 0.0, states)
    checked = evaluate_rule(rule, nasa_registry())
    return ThreeStateRule(5, 4, c, r, 0.05, 0.05, checked.decisiveness_lower, states)
