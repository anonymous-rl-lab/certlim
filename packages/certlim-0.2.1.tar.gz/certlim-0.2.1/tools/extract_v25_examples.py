"""Regenerate the compact installed examples from an unpacked TII v25 evidence directory."""

import argparse
import csv
import gzip
import io
from collections import defaultdict
from hashlib import sha256
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("evidence", type=Path)
parser.add_argument("out", type=Path)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
inputs = {}


def rows(path):
    p = args.evidence / path
    inputs[path] = sha256(p.read_bytes()).hexdigest()
    with p.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write(path, header, content):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(content)


registry = io.StringIO()
writer = csv.writer(registry, lineterminator="\n")
writer.writerow("model q_high low_lo low_hi high_lo high_hi".split())
for row in rows("NASA_chain_v2/results/legacy_confidence_sets.csv"):
    writer.writerow(
        ["/".join(row[k] for k in ("cell", "stage", "policy"))]
        + [row[k] for k in ("qhi", "lo0", "hi0", "lo1", "hi1")]
    )
with (args.out / "nasa.csv.gz").open("wb") as f:
    with gzip.GzipFile(filename="", fileobj=f, mode="wb", mtime=0) as g:
        g.write(registry.getvalue().encode())
keys = ["low_no", "low_cut", "high_no", "high_cut", "certify", "reject"]
lr = [
    r
    for r in rows("review_v21/results/lookups.csv")
    if (r["source"], r["policy"], r["n"], r["method"])
    == ("confidence", "pooled", "5", "LR")
]
assert len(lr) == 56
write(args.out / "nasa_lr.csv", keys, ([r[k] for k in keys] for r in lr))

groups = defaultdict(lambda: [0, 0.0, True])


def add(case, scope, grade, action, count=1, hours=None):
    if count == 0:
        return
    entry = groups[case, scope, grade, action]
    entry[0] += count
    if hours is None:
        entry[2] = False
    else:
        entry[1] += hours


for row in rows("CETL/results/predictions.csv"):
    if row["split"] == "test":
        for ch in ("A", "B"):
            add(
                "cetl",
                f"complete_{ch}",
                "qualified" if row["grade"] == "True" else "below",
                ("REFER", "FAIL", "PASS")[int(row[ch])],
                hours=float(row["discharge_h"]),
            )
for row in rows("CETL/results/audit_all_heldout.csv"):
    if row["scope"] == "refer_on_charge_invalid":
        qualified = row["grade"] == "P"
        n, e, d = [int(row[k]) for k in ("n", "errors", "decisions")]
        for action, k in (
            ("REFER", n - d),
            ("FAIL", e if qualified else d - e),
            ("PASS", d - e if qualified else e),
        ):
            add(
                "cetl",
                "all_" + row["channel"],
                "qualified" if qualified else "below",
                action,
                k,
            )
for scope in ("public_results", "public_census"):
    for row in rows(f"ReLiB/{scope}/cell_results.csv"):
        add("relib", scope, row["grade"], row["action"])
sealed = {
    (r["cell"], r["visit"]): r["previous"] for r in rows("Leaf/results/actions.csv")
}
for row in rows("Leaf/results/traces.csv"):
    key = (row["cell"], row["visit"])
    g, h = row["grade"], float(row["reference_h"])
    if key in sealed:
        add("leaf", "prior_optional", g, sealed[key], hours=h)
    add("leaf", "prior_all", g, sealed.get(key, "REFER"), hours=h)
    add("leaf", "same_visit_all", g, row["same_visit"], hours=h)
write(
    args.out / "capacity.csv",
    ["case", "scope", "grade", "action", "count", "reference_hours"],
    (
        [*key, count, format(hours, ".15g") if known else ""]
        for key, (count, hours, known) in sorted(groups.items())
    ),
)
write(args.out / "sources.csv", ["v25_evidence_path", "sha256"], sorted(inputs.items()))
