"""Every finding from the 0.1.0 audit, kept as a test that fails if it returns.

The 0.1.0 suite had 87% line coverage and caught none of these. Coverage measures
which lines ran, not which wrong answers the package is willing to give. These
tests attack the interface rather than exercise it.
"""

from __future__ import annotations

import numpy as np
import pytest

import certlim as cl


# ------------------------------------------------------- S1: the dangerous one
def test_budget_exhaustion_is_not_reported_as_permanent():
    """A search that ran out of budget must never look like a permanent obstruction.

    'Permanent' tells an engineer to abandon a channel and buy new hardware.
    Reporting it because an internal ceiling was hit would turn 'collect two more
    units' into a procurement decision.
    """
    exp = cl.Experiment(safe=[[0.75, 0.25], [0.25, 0.75]], unsafe=[[0.5, 0.5]], max_states=2)
    d = exp.diagnose()
    assert d.region == "undetermined"
    assert d.permanent is False
    assert d.exact_collision is False
    assert d.limit_reason and "ceiling" in d.limit_reason
    assert "not a permanent obstruction" in d.explain()


def test_strict_n_star_raises_instead_of_returning_none():
    exp = cl.Experiment(safe=[[0.75, 0.25], [0.25, 0.75]], unsafe=[[0.5, 0.5]], max_states=2)
    with pytest.raises(cl.StateSpaceTooLarge):
        exp.n_star()


def test_n_star_none_means_a_proven_collision_only():
    law = [0.4, 0.6]
    assert cl.Experiment(safe=[law], unsafe=[law]).n_star() is None


# ------------------------------------------------------------ S2: honest ceiling
def test_default_ceiling_matches_what_is_actually_solvable():
    """The ceiling is a time budget. Measured cost is minutes by 20,000 states."""
    assert cl.DEFAULT_MAX_STATES == 20_000
    exp = cl.Experiment(safe=[[1 / 8] * 8], unsafe=[[0.3] + [0.7 / 7] * 7])
    with pytest.raises(cl.StateSpaceTooLarge, match="time budget, not a memory one"):
        exp.delta(12)


# --------------------------------------------------- E1/E2: immutability, equality
def test_experiment_is_immutable_so_the_cache_cannot_go_stale():
    exp = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    exp.delta(1)
    with pytest.raises((AttributeError, ValueError)):
        exp.safe = np.array([[0.1, 0.9]])
    with pytest.raises(ValueError, match="read-only"):
        exp.safe[0, 0] = 0.5


def test_experiment_equality_and_hashing_do_not_raise():
    a = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    b = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    c = cl.Experiment(safe=[[0.8, 0.2]], unsafe=[[0.1, 0.9]])
    assert a == b and not (a == c)
    assert a != "not an experiment"
    assert len({a, b, c}) == 2
    assert a in [c, b]


def test_fingerprint_is_stable_and_discriminating():
    a = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    b = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    c = cl.Experiment(safe=[[0.8, 0.2]], unsafe=[[0.1, 0.9]])
    assert a.fingerprint() == b.fingerprint() != c.fingerprint()
    assert len(a.fingerprint()) == 64


# ---------------------------------------------------- fast dual, exact near zero
def test_dual_fast_path_agrees_with_the_exact_program():
    rng = np.random.default_rng(17)
    for _ in range(30):
        k = int(rng.integers(2, 5))
        exp = cl.Experiment(safe=rng.dirichlet(np.ones(k), 3), unsafe=rng.dirichlet(np.ones(k), 3))
        for n in (1, 2, 3):
            assert exp.delta(n) == pytest.approx(exp.delta(n, exact=True), abs=1e-6)


def test_gate_verdict_uses_the_exact_program():
    """Near zero the dual is only good to ~1e-7, which would flip the gate."""
    exp = cl.Experiment(safe=[[0.75, 0.25], [0.25, 0.75]], unsafe=[[0.5, 0.5]])
    assert exp.delta(1) == 0.0
    assert exp.gate(1) == 1
    assert exp.gate(2) == 0


# -------------------------------------------------------------- E3: grid ordering
def test_unsorted_grid_cannot_fake_a_monotonicity_failure():
    exp = cl.Experiment(safe=[[0.7, 0.3]], unsafe=[[0.4, 0.6]])
    f = cl.frontier(exp, n_grid=[5, 1, 3, 1])
    assert f.n_grid == (1, 3, 5)
    assert f.is_monotone() and f.bound_holds()
    with pytest.raises(ValueError, match="at least 1"):
        cl.frontier(exp, n_grid=[0, 1])
    with pytest.raises(ValueError, match="empty"):
        cl.frontier(exp, n_grid=[])


# ------------------------------------------------------------- E4: one tolerance
def test_a_single_zero_tolerance_is_used_everywhere():
    from certlim import core, experiment

    assert core.ZERO_TOL == cl.ZERO_TOL
    assert experiment.ZERO_TOL is core.ZERO_TOL


# ------------------------------------------------------------ E5: no dead params
def test_units_for_has_no_parameters_it_ignores():
    import inspect

    params = set(inspect.signature(cl.Frontier.units_for).parameters)
    assert params == {"self", "target"}


# ------------------------------------------------------- E6/E7: hostile numbers
@pytest.mark.parametrize("bad", [[[np.nan, 0.5]], [[np.inf, -np.inf]]])
def test_non_finite_laws_are_rejected(bad):
    with pytest.raises(ValueError, match="NaN or infinity"):
        cl.Experiment(safe=bad, unsafe=[[0.5, 0.5]])


def test_non_finite_counts_are_rejected():
    with pytest.raises(ValueError, match="NaN or infinity"):
        cl.Experiment.from_counts([[np.inf, 1]], [[1, 1]])
    with pytest.raises(ValueError, match="NaN or infinity"):
        cl.Experiment.from_counts([[1, 1]], [[np.nan, 1]])


@pytest.mark.parametrize("n", [0, -1])
def test_meaningless_block_lengths_are_rejected(n):
    exp = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    with pytest.raises(ValueError, match="at least 1"):
        exp.delta(n)
    with pytest.raises(ValueError, match="at least 1"):
        exp.state_count(n)


def test_max_states_must_be_positive():
    with pytest.raises(ValueError, match="max_states"):
        cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]], max_states=0)


def test_separator_rejects_fractional_and_hostile_counts():
    exp = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    sep = exp.separator(2)
    with pytest.raises(ValueError, match="whole numbers"):
        sep.apply([1.5, 0.5])
    with pytest.raises(ValueError, match="NaN or infinity"):
        sep.apply([np.nan, 1])
    with pytest.raises(ValueError, match="non-negative"):
        sep.apply([3, -1])


# ------------------------------- tied observed counts must not read as structural
def test_a_chance_tie_between_units_is_flagged_not_asserted():
    """Two units with identical histograms are an exact collision by definition.

    On a small alphabet with few draws that happens by chance, and the verdict
    would otherwise tell the user to abandon a perfectly good channel.
    """
    safe = [[11, 9], [15, 5], [18, 2]]
    unsafe = [[11, 9], [6, 14], [4, 16]]
    d = cl.Experiment.from_counts(safe, unsafe).diagnose()
    assert d.region == "permanent"
    assert d.collision_pairs == ((0, 0),)
    assert d.collision_from_tied_counts is True
    assert "finite-sample coincidence" in d.explain()


def test_a_structural_collision_is_not_flagged_as_a_tie():
    law = [0.4, 0.6]
    d = cl.Experiment(safe=[law], unsafe=[law]).diagnose()
    assert d.region == "permanent"
    assert d.collision_from_tied_counts is False
    assert "finite-sample coincidence" not in d.explain()


# ------------------------------------------------------------- property sweeps
def test_bound_survives_hostile_inputs():
    """3000 mixed instances including sparse, near-uniform, colliding and degenerate."""
    rng = np.random.default_rng(2026)
    for t in range(600):
        k = int(rng.integers(2, 6))
        ns, nu = int(rng.integers(1, 4)), int(rng.integers(1, 4))
        style = t % 4
        if style == 0:
            safe, unsafe = rng.dirichlet(np.ones(k) * 0.2, ns), rng.dirichlet(np.ones(k) * 0.2, nu)
        elif style == 1:
            safe, unsafe = rng.dirichlet(np.ones(k) * 50, ns), rng.dirichlet(np.ones(k) * 50, nu)
        elif style == 2:
            base = rng.dirichlet(np.ones(k))
            safe, unsafe = np.tile(base, (ns, 1)), np.tile(base, (nu, 1))
        else:
            safe = np.eye(k)[rng.integers(0, k, ns)] * 1.0
            unsafe = np.eye(k)[rng.integers(0, k, nu)] * 1.0
        a, b = float(rng.uniform(0.01, 0.4)), float(rng.uniform(0.01, 0.4))
        exp = cl.Experiment(safe, unsafe)
        assert exp.decisiveness(1, a, b) <= min(1.0, a + b + exp.delta(1)) + 1e-9


def test_delta_never_decreases_with_more_units():
    rng = np.random.default_rng(31)
    for _ in range(40):
        k = int(rng.integers(2, 4))
        exp = cl.Experiment(safe=rng.dirichlet(np.ones(k), 2), unsafe=rng.dirichlet(np.ones(k), 2))
        deltas = [exp.delta(n) for n in range(1, 6)]
        assert all(b >= a - 1e-9 for a, b in zip(deltas, deltas[1:]))


# ------------------------------------------------------------------- the report
def test_report_is_self_contained_and_deterministic(tmp_path):
    exp = cl.Experiment.from_counts([[150, 50], [140, 60]], [[60, 140], [70, 130]])
    kwargs = dict(n_grid=[1, 2, 3], title="Audit", subject="Lot 7")
    first = cl.certification_report(exp, **kwargs)
    second = cl.certification_report(exp, **kwargs)
    assert first == second, "same inputs must give byte-identical output"
    for forbidden in ("http://", "https://", "<script", " src=", "@import"):
        assert forbidden not in first, f"report reaches outside itself: {forbidden}"
    assert first.startswith("<!doctype html>") and first.rstrip().endswith("</html>")
    assert exp.fingerprint()[:32] in first

    path = tmp_path / "r.html"
    cl.write_report(path, exp, **kwargs)
    assert path.read_text(encoding="utf-8") == first


def test_report_states_plainly_when_calibration_was_not_run():
    exp = cl.Experiment.from_counts([[150, 50]], [[60, 140]])
    doc = cl.certification_report(exp, n_grid=[1, 2])
    assert "Not run" in doc and "separate question" in doc


def test_report_carries_the_calibration_when_units_are_supplied():
    rng = np.random.default_rng(5)
    units = np.array([rng.multinomial(20, [0.8, 0.2]) for _ in range(8)]
                     + [rng.multinomial(20, [0.25, 0.75]) for _ in range(8)], float)
    labels = np.array(["safe"] * 8 + ["unsafe"] * 8)
    exp = cl.Experiment.from_counts(units[:8], units[8:])
    doc = cl.certification_report(exp, n_grid=[1, 2], unit_counts=units, labels=labels,
                                  n_permutations=49, n_resamples=50)
    assert "Permutation p-value" in doc and "not a lower confidence bound" in doc


def test_report_warns_when_the_rule_would_ignore_the_data():
    law = [0.4, 0.6]
    exp = cl.Experiment(safe=[law], unsafe=[law])
    doc = cl.certification_report(exp, n_grid=[1, 2])
    assert "ignores the data" in doc and "Do not deploy it" in doc


def test_report_escapes_hostile_text():
    exp = cl.Experiment.from_counts([[150, 50]], [[60, 140]])
    doc = cl.certification_report(exp, n_grid=[1, 2], title="<script>alert(1)</script>",
                                  subject="a & b", notes=("<img onerror=x>",))
    assert "<script>alert(1)</script>" not in doc
    assert "&lt;script&gt;" in doc and "a &amp; b" in doc


def test_report_cli_writes_a_file(tmp_path, capsys):
    from certlim.cli import main

    csv_path = tmp_path / "units.csv"
    csv_path.write_text(
        "unit,s0,s1,grade\nu1,16,4,safe\nu2,15,5,safe\nu3,4,16,unsafe\nu4,5,15,unsafe\n"
    )
    out = tmp_path / "report.html"
    assert main(["report", str(csv_path), "-o", str(out), "--n", "1", "2",
                 "--permutations", "19", "--resamples", "20"]) == 0
    doc = out.read_text(encoding="utf-8")
    assert "Certification report" in doc and "Structural diagnosis" in doc
    assert "written:" in capsys.readouterr().out
