import json
from dataclasses import replace

import numpy as np
import pytest
from scipy.stats import binom

import certlim as cl
from certlim.cli import main
from certlim.design import _banks


def test_bernstein_mixture_matches_multinomial_off_grid():
    model = cl.BandModel("m", 0.4, 0.03, 0.3, 0.08, 0.24)
    n = 4
    for k in (2, 4):
        (outer,) = _banks([model], n, k, False)
        u, v = 0.223, 0.841
        wu = binom.pmf(np.arange(n + 1), n, u)
        if k == 4:
            w = np.outer(wu, binom.pmf(np.arange(n + 1), n, v)).ravel()
            x, y = 0.03 + 0.27 * u, 0.08 + 0.16 * v
            p = [0.6 - x, x, 0.4 - y, y]
        else:
            w = wu
            p_event = 0.11 + (0.54 - 0.11) * u
            p = [1 - p_event, p_event]
        np.testing.assert_allclose(
            w @ outer, cl.multinomial_law(p, n), rtol=1e-12, atol=1e-14
        )


@pytest.mark.parametrize("q", [0.0, 0.5, 1.0])
def test_collapsed_rectangle_matches_old_point_kernel_asymmetric_budgets(q):
    def model(key, risk):
        return cl.BandModel(key, q, (1 - q) * risk, (1 - q) * risk, q * risk, q * risk)

    s, u = model("s", 0.1), model("u", 0.8)
    ans = cl.design_measurement([s, u], n=2, alpha=0.03, beta=0.07, target=0.8)
    old = cl.Experiment([[0.9, 0.1]], [[0.2, 0.8]]).decisiveness(
        2, alpha=0.03, beta=0.07
    )
    for side in (ans.event, ans.band_event):
        assert side.lower <= old + 1e-9 <= side.upper + 3e-9
        assert side.upper - side.lower < 1e-7
        assert (
            side.audit.unsafe_approval_upper <= 0.03
            and side.audit.safe_rejection_upper <= 0.07
        )


def test_counts_missing_strata_and_duplicate_models():
    row = dict(
        model="s", q_high=0.3, low_hits=0, low_total=100, high_hits=0, high_total=0
    )
    (m,) = cl.registry_from_counts([row])
    assert m.high_lo == 0 and m.high_hi == 0.3 and m.low_lo == 0
    bad = cl.design_measurement([m], n=5)
    assert (
        bad.status == "insufficient_grades"
        and bad.counts["unresolved"] == 1
        and bad.event is None
    )
    with pytest.raises(ValueError, match="unique"):
        cl.registry_from_counts([row, row])
    with pytest.raises(ValueError):
        cl.registry_from_counts([dict(row, high_hits=1)])
    with pytest.raises(ValueError):
        cl.BandModel("m", 0.3, 0, 0.9, 0, 0.2)


def test_pooled_nasa_action_bounds_and_comparator():
    models = cl.nasa_registry()
    d = cl.design_measurement(models, n=5, target=0.243)
    assert d.counts == dict(registered=1539, safe=26, unsafe=250, unresolved=1263)
    assert d.status == "additional_band_required"
    assert (
        abs(d.event.upper - 0.24179129) < 1e-7
        and abs(d.band_event.lower - 0.24366665) < 1e-7
    )
    assert d.band_event.upper - d.band_event.lower < 1e-7
    lr = cl.nasa_likelihood_ratio_rule()
    audited = cl.evaluate_rule(lr, models)
    assert audited.unsafe_approval_upper < 0.05 and audited.safe_rejection_upper < 0.05
    assert abs(audited.decisiveness_lower - 0.24364432) < 1e-7
    assert 0 <= 100 * (d.band_event.upper - audited.decisiveness_lower) < 0.002235
    with pytest.raises(ValueError):
        d.band_event.rule.decide([5.1, 0, 0, 0])


def test_recheck_detects_frozen_target_violation_and_wrong_state_order():
    source = [cl.BandModel("s", 0, 0, 0, 0, 0), cl.BandModel("u", 1, 0, 0, 1, 1)]
    target = [
        cl.BandModel("s", 1, 0, 0, 0.1, 0.15),
        cl.BandModel("u", 0, 0.35, 0.5, 0, 0),
    ]
    rule = cl.design_measurement(source, n=1).band_event.rule
    assert cl.evaluate_rule(rule, target).unsafe_approval_upper > 0.05
    with pytest.raises(ValueError, match="ordering"):
        cl.evaluate_rule(replace(rule, states=rule.states[::-1]), source)


def test_cli_freeze_read_archive_and_missing_grade(tmp_path):
    dest, rules = tmp_path / "out.json", tmp_path / "frozen.json"
    assert (
        main(
            [
                "design",
                "--nasa",
                "--n",
                "1",
                "--target",
                ".2",
                "--rules",
                str(rules),
                "--json",
                str(dest),
            ]
        )
        == 0
    )
    assert main(["recheck", str(rules), "--nasa", "--json", str(dest)]) == 0
    assert json.loads(dest.read_text())["status"] == "certified_on_target_set"
    with rules.open() as src:
        j = json.load(src)
    j["band_event"]["symbols"].reverse()
    rules.write_text(json.dumps(j))
    assert main(["recheck", str(rules), "--nasa"]) == 2
    path = tmp_path / "custom.csv"
    path.write_text("grade,action,reference_hours\nunknown,REFER,\nbelow,FAIL,1.25\n")
    assert main(["audit", "--ledger", str(path), "--json", str(dest)]) == 0
    r = json.loads(dest.read_text())["ledger"]
    assert r["status"] == "missing_grade" and r["reference_hours_on_decisions"] == 1.25


def test_screening_scopes_and_denominators():
    def calc(name, **opt):
        return {
            scope: cl.audit_screen(rows, **opt)
            for scope, rows in cl.screening_example(name).items()
        }

    c = calc("cetl", inference="iid")
    cb = c["complete_B"]
    assert cb["records"] == 1057 and cb["decisive"] == 484
    assert cb["grade_metrics"]["below"]["errors"] == 2
    assert cb["grade_metrics"]["below"]["error_upper"] == pytest.approx(0.0499506330549)
    assert cb["status"] == "passes_iid_error_bounds"
    assert c["all_B"]["min_empirical_class_decisiveness"] == pytest.approx(
        0.30769230769
    )
    assert cb["reference_hours_on_decisions"] - c["complete_A"][
        "reference_hours_on_decisions"
    ] == pytest.approx(576.1875)
    r = calc("relib")["public_census"]
    assert (
        r["records"],
        r["unknown_reference"],
        r["grade_metrics"]["qualified"]["errors"],
    ) == (6909, 2, 5356)
    assert r["status"] == "budget_exceeded_on_archive"
    assert r["grade_metrics"]["below"]["empirical_error"] is None
    assert r["reference_hours_on_decisions"] is None
    leaf = calc("leaf")
    assert [
        (leaf[k]["decisive"], leaf[k]["records"])
        for k in ("prior_optional", "prior_all", "same_visit_all")
    ] == [(31, 41), (31, 88), (65, 88)]
    assert leaf["prior_all"]["reference_hours_on_decisions"] == pytest.approx(406.9175)


def test_joint_screening_target_allocates_all_four_bounds():
    rows = cl.screening_example("cetl")["complete_B"]
    result = cl.audit_screen(rows, inference="iid", min_decisiveness=0.2)
    assert result["joint_status"] == "requirements_not_certified"
    assert result["grade_metrics"]["below"]["error_upper"] > 0.05
    assert result["grade_metrics"]["qualified"]["decisiveness_lower"] > 0.2
    absent = cl.audit_screen(
        [cl.ScreenRecord("unknown", "PASS")], inference="iid", min_decisiveness=0.2
    )
    assert (
        absent["joint_status"] == "missing_grade"
        and absent["decisions_missing_reference_hours"] == 1
    )
    with pytest.raises(ValueError):
        cl.audit_screen([])
    with pytest.raises(ValueError):
        cl.ScreenRecord("qualified", "PASS", count=1.5)
