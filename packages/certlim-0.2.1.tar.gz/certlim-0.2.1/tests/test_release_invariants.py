"""Independent numerical and file-interface invariants for the audit repairs."""

from dataclasses import replace
import hashlib
import json
import os

import numpy as np
import pytest

import certlim as cl
from certlim.cli import main


@pytest.mark.parametrize("reverse", [False, True])
def test_decision_rate_matches_analytic_optimum_in_both_directions(reverse):
    pure, mixed = [[1, 0]], [[1e-10, 1 - 1e-10]]
    exp = cl.Experiment(mixed, pure) if reverse else cl.Experiment(pure, mixed)
    alpha, beta = (0.05, 1e-12) if reverse else (1e-12, 0.05)
    rule = cl.build_rule(exp, n=1, alpha=alpha, beta=beta)
    assert rule.decisiveness == pytest.approx(0.06, abs=1e-12)
    assert exp.decisiveness(1, alpha, beta) == pytest.approx(0.06, abs=1e-12)
    profile = rule.error_profile(exp)
    assert profile["unsafe_to_certify"] <= alpha
    assert profile["safe_to_reject"] <= beta

    # Deliberately move the erroneous action above the tiny budget.
    field, verdict = (
        ("reject_prob", "beta_respected")
        if reverse
        else ("certify_prob", "alpha_respected")
    )
    edited = getattr(rule, field).copy()
    edited[np.flatnonzero(rule.states[:, 0] == 1)[0]] = 0.20
    assert not replace(rule, **{field: edited}).error_profile(exp)[verdict]


def test_lookup_owns_data_and_array_metadata():
    source = np.array([0.25, 0.50])
    rule = cl.ThreeStateRule(
        1, 2, source, np.zeros(2), 0.5, 0.1, 0.25, cl.count_states(1, 2)
    )
    source[0] = 1
    for field in ("certify_prob", "reject_prob", "states"):
        view = getattr(rule, field)
        expected = view.copy()
        with pytest.raises(ValueError):
            view.setflags(write=True)
        view.shape = (view.size, 1)
        view.dtype = np.uint8
        assert np.array_equal(getattr(rule, field), expected)
    assert rule.certify_prob[0] == 0.25


def test_ordered_schema_excludes_numeric_identifiers(tmp_path):
    inp, out = tmp_path / "counts.csv", tmp_path / "output.json"
    inp.write_text("grade,hit,miss,id\nsafe,10,10,1\nunsafe,10,10,1000\n")
    args = ["diagnose", str(inp), "--json", str(out)]
    with pytest.raises(SystemExit, match="evidence-cols"):
        main(args)
    assert main(args + ["--evidence-cols", "miss", "hit"]) == 0
    got = json.loads(out.read_text())
    assert (got["region"], got["evidence_columns"]) == ("permanent", ["miss", "hit"])


@pytest.mark.parametrize("hard", [False, True])
def test_aliased_files_are_preserved(tmp_path, hard):
    inp, alias = tmp_path / "units.csv", tmp_path / "linked.json"
    data = b"grade,x,y\nsafe,10,1\nunsafe,1,10\n"
    inp.write_bytes(data)
    if hard:
        os.link(inp, alias)
    else:
        try:
            alias.symlink_to(inp)
        except OSError:
            pytest.skip("symbolic links unavailable on this platform")
    assert main(["diagnose", str(inp), "--json", str(alias)]) != 0
    assert main(["report", str(inp), "-o", str(alias)]) != 0
    assert (
        main(
            [
                "design",
                "--nasa",
                "--target",
                "0.2",
                "--json",
                str(inp),
                "--rules",
                str(alias),
            ]
        )
        != 0
    )
    assert inp.read_bytes() == alias.read_bytes() == data


def test_grade_thresholds_follow_exact_csv_decimals_on_both_sides(tmp_path):
    inp, out = tmp_path / "registry.csv", tmp_path / "summary.json"
    inp.write_text(
        "model,q_high,low_lo,low_hi,high_lo,high_hi\n"
        "safe,0.5,0.10,0.10,0.05,0.05\n"
        "above,0.5,0.10,0.1000000000000000000000001,0.05,0.05\n"
        "unsafe,0.5,0.30,0.30,0.05,0.05\n"
        "below,0.5,0.2999999999999999999999999,0.30,0.05,0.05\n"
    )

    def counts(*opts):
        args = [
            "design",
            "--registry",
            str(inp),
            "--n",
            "1",
            "--target",
            ".2",
            "--json",
            str(out),
        ]
        assert main(args + list(opts)) == 0
        return json.loads(out.read_text())["counts"]

    assert counts() == {"registered": 4, "safe": 1, "unsafe": 1, "unresolved": 2}
    assert (
        counts(
            "--safe-max",
            ".1500000000000000000000001",
            "--unsafe-min",
            ".3499999999999999999999999",
        )["unresolved"]
        == 0
    )


def test_joint_verdict_and_legacy_unspecified_target(tmp_path):
    frozen, out, src = (
        tmp_path / "frozen.json",
        tmp_path / "out.json",
        tmp_path / "source.csv",
    )
    src.write_text(
        "model,q_high,low_lo,low_hi,high_lo,high_hi\ns,.5,0,0,0,0\nu,.5,.5,.5,.5,.5\n"
    )
    assert (
        main(
            [
                "design",
                "--registry",
                str(src),
                "--n",
                "1",
                "--target",
                ".25",
                "--rules",
                str(frozen),
                "--json",
                str(out),
            ]
        )
        == 0
    )
    check = ["recheck", str(frozen), "--registry", str(src), "--json", str(out)]
    assert main(check) == 0
    result = json.loads(out.read_text())
    assert (result["joint_status"], result["target_source"]) == (
        "joint_requirements_certified",
        "frozen",
    )
    assert main(check + ["--target", ".10"]) != 0

    old = json.loads(frozen.read_text())
    del old["sha256"], old["target"]
    old["format"] = "certlim.band-rule.v1"
    old["sha256"] = hashlib.sha256(
        json.dumps(old, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    frozen.write_text(json.dumps(old))
    assert main(check) == 0
    result = json.loads(out.read_text())
    assert result["error_budgets_met"] and result["target_met"] is None
    assert result["joint_status"] == "target_unspecified"
    assert main(check + ["--target", ".25"]) == 0
    result = json.loads(out.read_text())
    assert result["target_met"] and result["target_source"] == "supplied_at_recheck"


def test_positive_singleton_gap_remains_visible_in_the_frontier():
    exp = cl.Experiment([[0.5, 0.5]], [[0.5 + 1e-10, 0.5 - 1e-10]])
    assert exp.diagnose().region == "immediate" and exp.n_star() == 1
    expected = pytest.approx(1e-10, rel=1e-6)
    assert exp.delta() == expected
    assert cl.hull_tv(exp.safe, exp.unsafe) == expected
    assert cl.sion_gap(exp.safe, exp.unsafe) == expected
    assert 2 * exp.separator().margin == expected
    assert cl.frontier(exp, n_grid=[1]).to_records()[0]["gate"] == 0
