"""Regression cases retained from the certlim 0.2.0 release audit."""

import json
import subprocess
import sys

import certlim as cl


def cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "certlim.cli", *map(str, args)],
        capture_output=True,
        text=True,
    )


def test_small_error_budget_has_no_false_pass():
    exp = cl.Experiment([[1, 0]], [[1e-10, 1 - 1e-10]])
    try:
        rule = cl.build_rule(exp, 1, alpha=1e-12, beta=0.05)
    except (ValueError, ArithmeticError, RuntimeError):
        return  # Explicitly declining an unresolved numerical certificate is valid.
    actual = (
        1e-10 * rule.probabilities([1, 0])[0]
        + (1 - 1e-10) * rule.probabilities([0, 1])[0]
    )
    assert actual <= 1e-12 or not rule.error_profile(exp)["alpha_respected"]


def test_near_collision_is_not_permanent():
    e = cl.Experiment([[0.5, 0.5]], [[0.5 + 1e-10, 0.5 - 1e-10]])
    assert e.diagnose().region != "permanent"


def test_delayed_report_allows_repetition():
    e = cl.Experiment([[0.25, 0.75], [0.75, 0.25]], [[0.5, 0.5]])
    assert e.n_star() == 2
    html = cl.certification_report(e, n_grid=[1, 2], rule_n=1)
    assert "Do not deploy it; change the measurement." not in html


def test_in_place_rule_edit_cannot_leave_stale_certificate():
    ms = cl.nasa_registry()
    ch = cl.design_measurement(ms, n=5, target=0.243).band_event
    try:
        ch.rule.certify_prob[:] = 1.0
        ch.rule.reject_prob[:] = 0.0
    except (ValueError, TypeError, AttributeError):
        return
    assert (
        abs(
            cl.evaluate_rule(ch.rule, ms).unsafe_approval_upper
            - ch.audit.unsafe_approval_upper
        )
        < 1e-10
    )


def test_numeric_identifier_is_not_diagnostic_evidence(tmp_path):
    csv = tmp_path / "counts.csv"
    out = tmp_path / "out.json"
    csv.write_text("grade,x,y,unit_id\nsafe,10,10,1\nunsafe,10,10,1000\n")
    proc = cli("diagnose", csv, "--json", out)
    if proc.returncode:
        return  # Requiring an explicit schema for ambiguous numeric fields is valid.
    assert json.loads(out.read_text())["region"] != "immediate"


def test_audit_output_preserves_input(tmp_path):
    csv = tmp_path / "ledger.csv"
    body = "grade,action\nqualified,PASS\nbelow,FAIL\n"
    csv.write_text(body)
    proc = cli("audit", "--ledger", csv, "--json", csv)
    assert proc.returncode != 0 and csv.read_text() == body


def test_decimal_cutoff_includes_exact_decimal_sum(tmp_path):
    registry = tmp_path / "models.csv"
    registry.write_text(
        "model,q_high,low_lo,low_hi,high_lo,high_hi\na,0.5,0,0.10,0,0.05\nb,0.5,0.4,0.4,0,0\n"
    )
    out = tmp_path / "summary.json"
    proc = cli(
        "design", "--registry", registry, "--n", 1, "--target", "0.2", "--json", out
    )
    assert proc.returncode == 0
    assert json.loads(out.read_text())["counts"]["safe"] == 1


def test_recheck_separates_error_acceptance_from_original_target(tmp_path):
    frozen = tmp_path / "rules.json"
    src = tmp_path / "source.json"
    target = tmp_path / "target.csv"
    proc = cli(
        "design",
        "--nasa",
        "--n",
        5,
        "--target",
        ".243",
        "--rules",
        frozen,
        "--json",
        src,
    )
    assert proc.returncode == 0
    target.write_text(
        "model,q_high,low_lo,low_hi,high_lo,high_hi\ns,1,0,0,0,0\nu,0.65,0.35,0.35,0,0\n"
    )
    proc = cli("recheck", frozen, "--registry", target)
    assert proc.returncode == 0
    report = json.loads(proc.stdout)
    assert report["decisiveness_lower"] < 0.243
    # Any explicit original-target verdict or an error-only status avoids a broad pass.
    explicit_target = any(
        k in report
        for k in (
            "target_met",
            "target_status",
            "joint_status",
            "decisiveness_target_met",
        )
    )
    assert explicit_target or report["status"] != "certified_on_target_set"
