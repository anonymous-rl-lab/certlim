"""Test suite for certlim.

The landmark cases are taken from the theory this package implements. The two
regression tests at the top encode defects that were shipped once and caught in
review; they stay here so they cannot come back.
"""

from __future__ import annotations

import json
import math

import numpy as np
import pytest
from scipy.optimize import linprog

import certlim as cl


# ------------------------------------------------------------- regression tests
def test_zero_probability_symbol_is_not_nan():
    """0 * log 0 must be 0.

    Regression: mapping the resulting NaN to -inf zeroed every model with an
    empty alphabet cell and produced a spurious Delta = 0.
    """
    states = cl.count_states(3, 3)
    law = cl.multinomial_law(np.array([0.5, 0.5, 0.0]), 3, states)
    assert np.isfinite(law).all()
    assert law.sum() == pytest.approx(1.0, abs=1e-12)
    assert (law[states[:, 2] > 0] == 0).all()
    assert law[np.all(states == [3, 0, 0], axis=1)][0] == pytest.approx(0.125, abs=1e-12)


def _dense_decisiveness(safe, unsafe, alpha, beta):
    """Pre-sparsification reference implementation."""
    k = safe.shape[1]
    nvar = 2 * k + 1
    rows, rhs = [], []
    for law in unsafe:
        r = np.zeros(nvar); r[:k] = law; rows.append(r); rhs.append(alpha)
    for law in safe:
        r = np.zeros(nvar); r[k:2 * k] = law; rows.append(r); rhs.append(beta)
    for law in np.vstack([safe, unsafe]):
        r = np.zeros(nvar); r[:k] = -law; r[k:2 * k] = -law; r[-1] = 1.0
        rows.append(r); rhs.append(0.0)
    for j in range(k):
        r = np.zeros(nvar); r[j] = 1.0; r[k + j] = 1.0; rows.append(r); rhs.append(1.0)
    cost = np.zeros(nvar); cost[-1] = -1.0
    res = linprog(cost, A_ub=np.array(rows), b_ub=np.array(rhs),
                  bounds=[(0.0, 1.0)] * (2 * k) + [(0.0, 1.0)], method="highs")
    assert res.success
    return float(res.x[-1])


def test_sparse_matches_dense():
    """The sparse rewrite must reproduce the dense program exactly."""
    rng = np.random.default_rng(7)
    for _ in range(25):
        k = int(rng.integers(2, 7))
        safe = rng.dirichlet(np.ones(k), size=int(rng.integers(1, 5)))
        unsafe = rng.dirichlet(np.ones(k), size=int(rng.integers(1, 5)))
        a, b = float(rng.uniform(0.01, 0.3)), float(rng.uniform(0.01, 0.3))
        assert cl.decisiveness(safe, unsafe, a, b) == pytest.approx(
            _dense_decisiveness(safe, unsafe, a, b), abs=1e-9)


# ------------------------------------------------------------ landmark theory
def test_finite_block_landmarks():
    """Safe {1/4, 3/4} vs unsafe {1/2}: Delta(1)=0, Delta(2)=1/8, margin 1/16, n*=2."""
    exp = cl.Experiment(safe=[[0.75, 0.25], [0.25, 0.75]], unsafe=[[0.5, 0.5]])
    assert exp.delta(1) == pytest.approx(0.0, abs=1e-12)
    assert exp.delta(2) == pytest.approx(0.125, abs=1e-9)
    assert exp.margin(2) == pytest.approx(0.0625, abs=1e-9)
    assert exp.n_star() == 2
    assert exp.diagnose().region == "delayed"


def test_hull_is_not_pairwise():
    """Every pair separated, yet the hulls collide: the headline failure mode."""
    exp = cl.Experiment(safe=[[0.75, 0.25], [0.25, 0.75]], unsafe=[[0.5, 0.5]])
    assert exp.pairwise_min_tv() == pytest.approx(0.25, abs=1e-12)
    assert exp.delta(1) == pytest.approx(0.0, abs=1e-12)
    assert exp.pairwise_min_tv() > exp.delta(1)


def test_intersecting_hulls_pin_decisiveness_at_alpha_plus_beta():
    exp = cl.Experiment(safe=[[0.75, 0.25], [0.25, 0.75]], unsafe=[[0.5, 0.5]])
    assert exp.decisiveness(1, 0.05, 0.05) == pytest.approx(0.10, abs=1e-9)
    assert exp.decisiveness(1, 0.02, 0.07) == pytest.approx(0.09, abs=1e-9)


def test_exact_collision_is_permanent():
    law = [0.3, 0.7]
    exp = cl.Experiment(safe=[law], unsafe=[law])
    d = exp.diagnose()
    assert d.exact_collision and d.permanent
    assert d.region == "permanent" and d.n_star is None
    for n in (1, 3, 7):
        assert exp.delta(n) == pytest.approx(0.0, abs=1e-12)
        assert exp.decisiveness(n, 0.05, 0.05) == pytest.approx(0.10, abs=1e-9)


def test_bound_holds_and_is_generally_strict():
    """D <= min(1, alpha+beta+Delta) always; equality is a boundary phenomenon."""
    rng = np.random.default_rng(5)
    strict = 0
    for _ in range(40):
        k = int(rng.integers(2, 6))
        exp = cl.Experiment(safe=rng.dirichlet(np.ones(k), 2), unsafe=rng.dirichlet(np.ones(k), 2))
        d, bound = exp.decisiveness(1), exp.bound(1)
        assert d <= bound + 1e-9
        strict += d < bound - 1e-6
    assert strict > 0


def test_sion_identity():
    rng = np.random.default_rng(11)
    for _ in range(20):
        k = int(rng.integers(2, 6))
        safe, unsafe = rng.dirichlet(np.ones(k), 3), rng.dirichlet(np.ones(k), 3)
        assert cl.sion_gap(safe, unsafe) == pytest.approx(cl.hull_tv(safe, unsafe), abs=1e-8)


def test_separating_statistic_realises_the_margin():
    exp = cl.Experiment(safe=[[0.9, 0.1], [0.8, 0.2]], unsafe=[[0.2, 0.8]])
    sep = exp.separator(1)
    assert sep.margin == pytest.approx(exp.margin(1), abs=1e-9)
    assert min(sep.expected(r) for r in exp.safe) >= sep.threshold + sep.margin - 1e-9
    assert max(sep.expected(r) for r in exp.unsafe) <= sep.threshold - sep.margin + 1e-9


def test_separator_is_indexed_by_states_not_symbols():
    """Regression: applying the statistic positionally silently flips the verdict
    for any block length whose state order differs from the symbol order."""
    exp = cl.Experiment(safe=[[0.9, 0.1], [0.8, 0.2]], unsafe=[[0.2, 0.8]])
    sep = exp.separator(1)
    assert sep.side([1, 0]) == "safe"
    assert sep.side([0, 1]) == "unsafe"
    with pytest.raises(ValueError, match="sum to n"):
        sep.apply([2, 0])


def test_block_laws_at_one_unit_are_the_input_laws():
    laws = [[0.3, 0.7], [0.9, 0.1]]
    assert np.allclose(cl.block_laws(laws, 1), laws)
    assert np.array_equal(cl.count_states(1, 2), [[1, 0], [0, 1]])


def test_monotone_frontier():
    exp = cl.Experiment(safe=[[0.7, 0.3]], unsafe=[[0.4, 0.6]])
    f = cl.frontier(exp, n_grid=[1, 2, 3, 5, 8], alpha=0.05, beta=0.05)
    assert f.bound_holds() and f.is_monotone()
    assert f.max_excess() <= 1e-9
    assert f.units_for(0.5) is not None


def test_stopping_bound_is_respected():
    """n* never exceeds r - 1 for a finite class with no exact collision."""
    rng = np.random.default_rng(3)
    checked = 0
    for _ in range(60):
        k = int(rng.integers(2, 4))
        ms, mu = int(rng.integers(1, 4)), int(rng.integers(1, 4))
        exp = cl.Experiment(safe=rng.dirichlet(np.ones(k), ms),
                            unsafe=rng.dirichlet(np.ones(k), mu))
        if exp.delta(1) > 1e-9 or exp.has_exact_collision():
            continue
        nstar = exp.n_star()
        checked += 1
        assert nstar is not None and nstar <= exp.stopping_bound()
    assert checked > 0


# ------------------------------------------------------------------ data flow
def test_from_counts_smoothing_removes_structural_zeros():
    exp = cl.Experiment.from_counts([[5, 0, 0]], [[0, 0, 5]], smoothing=0.5)
    assert (exp.safe > 0).all() and (exp.unsafe > 0).all()
    raw = cl.Experiment.from_counts([[5, 0, 0]], [[0, 0, 5]], smoothing=0.0)
    assert raw.delta(1) == pytest.approx(1.0, abs=1e-9)
    assert exp.delta(1) < raw.delta(1)


def test_input_validation():
    with pytest.raises(ValueError, match="do not sum to 1"):
        cl.Experiment(safe=[[0.4, 0.4]], unsafe=[[0.5, 0.5]])
    with pytest.raises(ValueError, match="alphabet"):
        cl.Experiment(safe=[[0.5, 0.5]], unsafe=[[0.3, 0.3, 0.4]])
    with pytest.raises(ValueError, match="empty"):
        cl.Experiment(safe=np.zeros((0, 2)), unsafe=[[0.5, 0.5]])
    with pytest.raises(ValueError):
        cl.Experiment(safe=[[0.5, 0.5]], unsafe=[[0.5, 0.5]]).decisiveness(1, alpha=0.0)


def test_state_space_ceiling_is_actionable():
    exp = cl.Experiment(safe=[[0.5] * 2], unsafe=[[0.3, 0.7]], max_states=10)
    with pytest.raises(cl.StateSpaceTooLarge, match="Coarsen the alphabet"):
        exp.delta(50)
    f = cl.frontier(exp, n_grid=[1, 2, 50])
    assert f.n_grid == (1, 2) and len(f.skipped) == 1


# ----------------------------------------------------------------------- rule
def test_rule_respects_its_error_budget():
    exp = cl.Experiment(safe=[[0.85, 0.15]], unsafe=[[0.2, 0.8]])
    rule = cl.build_rule(exp, n=3, alpha=0.05, beta=0.05)
    profile = rule.error_profile(exp)
    assert profile["alpha_respected"] and profile["beta_respected"]
    assert rule.decisiveness == pytest.approx(exp.decisiveness(3), abs=1e-9)
    assert rule.alert_rate_floor() == pytest.approx(1.0 - rule.decisiveness, abs=1e-12)


def test_rule_decisions_are_reproducible_and_valid():
    exp = cl.Experiment(safe=[[0.85, 0.15]], unsafe=[[0.2, 0.8]])
    rule = cl.build_rule(exp, n=2)
    a = rule.decide([2, 0], np.random.default_rng(42))
    b = rule.decide([2, 0], np.random.default_rng(42))
    assert a.outcome == b.outcome
    assert a.outcome in (cl.CERTIFY, cl.ALERT, cl.REJECT)
    assert a.p_certify + a.p_reject + a.p_alert == pytest.approx(1.0, abs=1e-9)
    with pytest.raises(ValueError, match="sum to n"):
        rule.decide([1, 0])


def test_collision_rule_cannot_beat_alpha_plus_beta():
    """At a collision the optimum is alpha + beta however the solver spends it."""
    law = [0.4, 0.6]
    exp = cl.Experiment(safe=[law], unsafe=[law])
    rule = cl.build_rule(exp, n=1, alpha=0.05, beta=0.05)
    assert rule.decisiveness == pytest.approx(0.10, abs=1e-9)
    profile = rule.error_profile(exp)
    assert profile["alpha_respected"] and profile["beta_respected"]
    assert profile["worst_case_decisiveness"] == pytest.approx(0.10, abs=1e-9)
    assert rule.alert_rate_floor() == pytest.approx(0.90, abs=1e-9)


# ------------------------------------------------------------------ quantizer
def test_nested_quantizer_chain_is_nested():
    rng = np.random.default_rng(0)
    values = rng.normal(size=(200, 3))
    q = cl.NestedQuantizer.from_quantiles(values, bins=2, drop_order=(2, 1))
    assert q.chain() == [8, 4, 2]
    fine = q.encode(values, 0)
    for level in (1, 2):
        coarse = q.encode(values, level)
        mapping = {}
        for f_code, c_code in zip(fine, coarse):
            mapping.setdefault(f_code, c_code)
            assert mapping[f_code] == c_code   # each fine bin lands in exactly one coarse bin


def test_coarsening_cannot_increase_separation():
    rng = np.random.default_rng(1)
    for _ in range(20):
        safe = rng.dirichlet(np.ones(4), 3)
        unsafe = rng.dirichlet(np.ones(4), 3)
        groups = np.array([0, 0, 1, 1])
        fine = cl.Experiment(safe, unsafe)
        coarse = cl.Experiment(cl.coarsen_counts(safe, groups), cl.coarsen_counts(unsafe, groups))
        report = cl.check_data_processing(fine, coarse)
        assert report["holds"], report["note"]


def test_coarsen_counts_rejects_a_non_surjective_map():
    with pytest.raises(ValueError, match="surjective"):
        cl.coarsen_counts([[1.0, 1.0, 1.0, 1.0]], [0, 0, 2, 2])


def test_nested_quantizer_rejects_bad_edges():
    with pytest.raises(ValueError, match="strictly increasing"):
        cl.NestedQuantizer(edges=(np.array([1.0, 1.0]),))
    with pytest.raises(ValueError, match="does not exist"):
        cl.NestedQuantizer(edges=(np.array([0.0]),), drop_order=(3,))


# --------------------------------------------------------------- calibration
def _synthetic_units(rng, n_safe=12, n_unsafe=12, draws=20, separated=True):
    p_safe = [0.8, 0.2] if separated else [0.5, 0.5]
    p_unsafe = [0.2, 0.8] if separated else [0.5, 0.5]
    counts, labels = [], []
    for _ in range(n_safe):
        counts.append(rng.multinomial(draws, p_safe)); labels.append("safe")
    for _ in range(n_unsafe):
        counts.append(rng.multinomial(draws, p_unsafe)); labels.append("unsafe")
    return np.array(counts, float), np.array(labels)


def test_permutation_detects_a_real_effect_and_not_a_null_one():
    rng = np.random.default_rng(4)
    counts, labels = _synthetic_units(rng, separated=True)
    hit = cl.permutation_test(counts, labels, n_permutations=199, seed=1)
    assert hit.p_value <= 0.05 and hit.observed > 0

    counts, labels = _synthetic_units(rng, separated=False)
    miss = cl.permutation_test(counts, labels, n_permutations=199, seed=1)
    assert miss.p_value > 0.05


def test_bootstrap_interval_brackets_the_estimate():
    rng = np.random.default_rng(6)
    counts, labels = _synthetic_units(rng, separated=True)
    boot = cl.bootstrap_delta(counts, labels, n_resamples=200, seed=2)
    assert boot.ci_low <= boot.median <= boot.ci_high
    assert 0.0 <= boot.ci_low and boot.ci_high <= 1.0


def test_calibration_rejects_bad_labels():
    with pytest.raises(ValueError, match="safe"):
        cl.permutation_test([[1.0, 1.0]], ["good"], n_permutations=5)


# ----------------------------------------------------------------- transport
def test_transport_margin_certifies_only_when_positive():
    source = cl.Experiment(safe=[[0.95, 0.05]], unsafe=[[0.05, 0.95]])
    same = cl.Experiment(safe=[[0.95, 0.05]], unsafe=[[0.05, 0.95]])
    assert cl.transport_margin(source, same).certified

    shifted = cl.Experiment(safe=[[0.45, 0.55]], unsafe=[[0.55, 0.45]])
    report = cl.transport_margin(source, shifted)
    assert report.margin < 0 and not report.certified
    assert "does not prove" in report.note

    modest = cl.Experiment(safe=[[0.9, 0.1]], unsafe=[[0.1, 0.9]])
    assert cl.transport_margin(source, modest).certified


def test_class_drift_requires_a_shared_alphabet():
    a = cl.Experiment(safe=[[0.5, 0.5]], unsafe=[[0.2, 0.8]])
    b = cl.Experiment(safe=[[0.3, 0.3, 0.4]], unsafe=[[0.2, 0.2, 0.6]])
    with pytest.raises(ValueError, match="alphabet"):
        cl.class_drift(a, b)


# --------------------------------------------------------------- procurement
def test_screening_drops_dominated_plans():
    cheap = cl.Plan("passive", n=1, decisiveness=0.63, cost={"seconds": 780, "c_rate": 0.0})
    dear = cl.Plan("pulse", n=1, decisiveness=0.53, cost={"seconds": 940, "c_rate": 0.5})
    weak = cl.Plan("nameplate", n=6, decisiveness=0.10, cost={"seconds": 0, "c_rate": 0.0})
    result = cl.screen([cheap, dear, weak], target=0.4)
    assert weak in result.infeasible
    assert cheap in result.frontier and dear not in result.frontier


def test_screening_refuses_mismatched_ledgers():
    a = cl.Plan("a", n=1, decisiveness=0.9, cost={"seconds": 1.0, "c_rate": 0.0})
    b = cl.Plan("b", n=1, decisiveness=0.9, cost={"seconds": 1.0})
    with pytest.raises(ValueError, match="different ledgers"):
        cl.screen([a, b], target=0.5, axes=("seconds", "c_rate"))


def test_screening_reports_when_nothing_qualifies():
    plan = cl.Plan("weak", n=1, decisiveness=0.10, cost={"seconds": 1.0})
    result = cl.screen([plan], target=0.9)
    assert not result.frontier and "no plan reaches" in str(result)


# ----------------------------------------------------------------------- cli
def _write_csv(path, counts, labels, blocks=None):
    import csv as _csv
    cols = [f"s{i}" for i in range(counts.shape[1])]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = _csv.writer(fh)
        w.writerow(cols + ["grade"] + (["block"] if blocks is not None else []))
        for i, row in enumerate(counts):
            w.writerow(list(row) + [labels[i]] + ([blocks[i]] if blocks is not None else []))


def test_cli_end_to_end(tmp_path, capsys):
    from certlim.cli import main

    rng = np.random.default_rng(9)
    counts, labels = _synthetic_units(rng, separated=True)
    csv_path = tmp_path / "units.csv"
    _write_csv(csv_path, counts, labels)

    assert main(["diagnose", str(csv_path)]) == 0
    assert "region" in capsys.readouterr().out

    assert main(["frontier", str(csv_path), "--n", "1", "2", "3"]) == 0
    assert "bound holds: True" in capsys.readouterr().out

    out = tmp_path / "rule.json"
    assert main(["rule", str(csv_path), "--n", "2", "--json", str(out)]) == 0
    payload = json.loads(out.read_text())
    assert payload["error_profile"]["alpha_respected"]
    assert len(payload["certify_prob"]) == cl.n_states(2, counts.shape[1])


def test_cli_reads_laws_json(tmp_path, capsys):
    from certlim.cli import main

    path = tmp_path / "laws.json"
    path.write_text(json.dumps({"safe": [[0.75, 0.25], [0.25, 0.75]], "unsafe": [[0.5, 0.5]]}))
    assert main(["diagnose", str(path)]) == 0
    text = capsys.readouterr().out
    assert "delayed" in text and "pairwise criterion" in text


def test_cli_rejects_single_grade(tmp_path):
    from certlim.cli import main

    path = tmp_path / "one.csv"
    path.write_text("s0,s1,grade\n1,2,safe\n3,4,safe\n")
    with pytest.raises(SystemExit, match="both are required"):
        main(["diagnose", str(path)])


def test_cli_calibrate_refuses_aggregate_laws(tmp_path):
    from certlim.cli import main

    path = tmp_path / "laws.json"
    path.write_text(json.dumps({"safe": [[0.5, 0.5]], "unsafe": [[0.2, 0.8]]}))
    with pytest.raises(SystemExit, match="per-unit counts"):
        main(["calibrate", str(path)])


def test_version_is_exposed():
    assert isinstance(cl.__version__, str)
    assert len(cl.__version__.split(".")) == 3
    assert not math.isnan(float(cl.__version__.split(".")[0]))


def test_cli_skips_metadata_columns(tmp_path, capsys):
    """Real CSVs carry ids and metadata; those must be ignored, not fatal."""
    from certlim.cli import main

    path = tmp_path / "meta.csv"
    path.write_text(
        "unit_id,s0,s1,grade,chem\n"
        "u1,16,4,safe,A\nu2,15,5,safe,B\nu3,4,16,unsafe,A\nu4,5,15,unsafe,B\n"
    )
    assert main(["diagnose", str(path)]) == 0
    captured = capsys.readouterr()
    assert "ignoring non-numeric column(s)" in captured.err
    assert "'unit_id'" in captured.err and "'chem'" in captured.err
    assert "region" in captured.out


def test_cli_block_col_is_available_everywhere(tmp_path, capsys):
    from certlim.cli import main

    path = tmp_path / "blocked.csv"
    path.write_text(
        "s0,s1,grade,chem\n16,4,safe,A\n15,5,safe,B\n4,16,unsafe,A\n5,15,unsafe,B\n"
    )
    for cmd in (["diagnose"], ["frontier", "--n", "1", "2"], ["rule", "--n", "1"]):
        assert main(cmd[:1] + [str(path), "--block-col", "chem"] + cmd[1:]) == 0
        assert "ignoring non-numeric" not in capsys.readouterr().err


def test_cli_errors_when_no_numeric_columns(tmp_path):
    from certlim.cli import main

    path = tmp_path / "bad.csv"
    path.write_text("name,grade\nfoo,safe\nbar,unsafe\n")
    with pytest.raises(SystemExit, match="is numeric"):
        main(["diagnose", str(path)])
