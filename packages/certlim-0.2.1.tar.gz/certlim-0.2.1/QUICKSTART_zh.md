# certlim 0.2.1 使用说明

在 wheel 所在目录安装，运行 `python -m pip install ./certlim-0.2.1-py3-none-any.whl`。依赖为 NumPy 和 SciPy。原有 `Experiment`、`frontier`、`build_rule` 和命令行接口继续使用。

## 多记录一个字段值得吗？

```sh
certlim design --nasa --n 5 --target 0.243 --rules frozen.json
certlim recheck frozen.json --nasa
```

第一条命令在同一批可定级对象和双侧各 5% 的错误预算上比较两种测量，并导出两张三态规则表。结果中 `event.all_rule_upper` 是所有仅观测截止事件规则的决断率上界，`band_event.decisiveness_lower` 是已有含电流档规则可达到的下界。若应用方把最低有用决断率定为 24.30%，两界分别为 24.179% 和 24.367%，因此新增字段改变了测量选择。此门槛是论文示例。结论适用于 1,539 个注册对象中可定级的 276 个，假定同一模型下的五个读数条件独立。

第二条命令对导出的规则重新核验。换用 `--registry target.csv` 可在目标区域逐侧检查同一张规则表。部署验收读取 `joint_status`。只有 `joint_requirements_certified` 表示两侧错误上界与最低有用决断率三项均已证实。`error_budgets_met` 与 `target_met` 分别给出判断。兼容字段 `status` 单独表示错误预算。新版冻结文件保留设计门槛。旧 v1 文件可用 `certlim recheck old.json --nasa --target 0.243` 显式补充门槛，省略时决断率达标项为 `null`。CSV 模板和参考等级阈值见英文 README。评估似然比简化规则时，使用 `nasa_likelihood_ratio_rule()` 和 `evaluate_rule()`，可量化进一步增加规则复杂度的收益上限。

## 怎样指定诊断证据列？

对逐对象计数 CSV，可运行 `certlim diagnose counts.csv --evidence-cols cutoff no_cutoff --json diagnosis.json`。证据顺序采用命令行所列顺序，并写入输出。默认模式识别按表头排列的 `s0`、`s1` 等列，或 `x,y` 两列。注册表 CSV 按输入的精确十进制值判定风险等级。例如两档事件上界 0.10 与 0.05 之和恰好达到 0.15，计入安全类。

## 冻结容量规则能承担多少参考放电？

```sh
certlim audit --example cetl --inference iid
certlim audit --example relib
certlim audit --example leaf --target 0.20
certlim audit --ledger my_holdout.csv --inference archive
```

CETL 显示完整输入和全部分配记录的分母。ReLiB 对固定 CETL-B 规则给出外部档案误退数。Leaf 按可选复验和全部访次分别统计，保留两种测量时点的区别。默认 `archive` 直接计算所给档案。`iid` 由使用者声明等级内独立抽样，程序据此计算类条件误差上界。加 `--target` 后同时保护两个错误上界和两个最低决断率下界；如结果要用于放行，使用该行对应的分母与推断条件。含有重复访次的 Leaf 默认按有限档案解读。

规则输出 `PASS / FAIL / REFER` 对应放行、判退、转做参考测试。`reference_hours_on_decisions` 是决断记录对应的已测参考放电通道小时。原始波形回放入口、模型权重及逐条签封记录见单独交付的 TII v25 实验总包。
