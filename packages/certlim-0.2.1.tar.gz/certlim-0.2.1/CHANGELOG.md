# Changelog

## 0.2.1

- Scale the point-law linear program to the requested error budgets. Recompute both errors and the feasible decision rate and check optimality against the dual. An unresolved rate raises an arithmetic error.
- Freeze lookup probabilities and count states independently of constructor inputs. In-place array edits cannot invalidate cached certificates.
- Identify permanent collisions using identical registered laws. Reports of delayed separation give the first resolved block length.
- Select CSV count columns by schema or an explicit ordered list and record the selected columns. Reject input/output aliases before writing.
- Grade the joint event bounds in CSV registries using their exact decimal values.
- Freeze the minimum decision rate in v2 rule exports. Rechecking reports error-budget, decision-target and joint verdicts. Existing v1 exports can be rechecked with an explicitly supplied target.

## 0.2.0

- Compare a binary event with its two-band refinement using common uncertainty for risk grades and block laws. Obtain an executable lookup, an all-rule upper bound, graded denominators and a measurement choice at a user-set target.
- Recheck unchanged lookups on target rectangles. Accept fixed-horizon binomial count registries or previously constructed simultaneous intervals.
- Audit frozen screens with separate error denominators, missing reference grades, workload and optional jointly protected minimum decisiveness.
- Bundle offline NASA, CETL, ReLiB and Leaf examples. Prior public functions and CLI subcommands remain available. Count-vector lookup now rejects fractional counts.


## 0.1.1

An adversarial audit of 0.1.0 found nine defects. The numerical core survived it
— 3,000 randomised instances with no violation of the certification bound, an
independent non-linear search agreeing with the hull program on every case, and
side errors respected to 1e-15 — but the interface around it did not. All nine
are fixed and each is now a test that fails if it returns.

### Fixed, in order of how badly they could mislead

- **A search that ran out of budget was reported as a permanent obstruction.**
  `n_star()` swallowed the state-space error and returned `None`, whose meaning
  is "abandon this channel". `diagnose()` now returns a distinct `'undetermined'`
  region that says in words that this is not a permanent obstruction, and
  `n_star()` raises rather than guessing.
- **The default state ceiling was an order of magnitude above what is solvable.**
  Lowered from 250,000 to 20,000, chosen from measured solve time rather than
  memory: the exact program takes minutes at 20,000 states and its runtime is not
  predictable from the size. The message now says so.
- **A chance tie between two units read as a structural obstruction.** Two units
  with identical histograms are an exact collision by definition, and on a small
  alphabet with few draws that happens by accident. `Diagnosis` now reports which
  models collide and whether their raw counts were identical, and says plainly
  that this may be a finite-sample coincidence.
- `Experiment` is immutable and its law arrays are read-only, so the memoised
  results can no longer go stale behind a caller's edit.
- `Experiment` equality and hashing no longer raise on the numpy comparison.
- An unsorted `n_grid` no longer makes `is_monotone()` report a false failure.
- One zero tolerance (`ZERO_TOL`) replaces two that disagreed.
- `units_for` no longer advertises `alpha` and `beta` parameters it ignored.
- NaN, infinity, `n < 1` and fractional counts are rejected instead of silently
  producing a plausible-looking answer.

### Faster

`delta()` is solved through the dual separation game, 10x to 450x quicker than
the primal hull program on large state spaces (40 s to 0.22 s at 20,000 states).
Because the dual loses accuracy as the space grows, and a value near zero is
exactly where the gate verdict turns, any result below 1e-5 is re-solved with
the exact program. `delta(n, exact=True)` forces it everywhere.

A vectorised rewrite of the constraint assembly was tried first and gave no
speedup at all; the cost is in the solve, not the setup.

### Added

- `certlim.report` — a self-contained single-file HTML certification report
  combining the diagnosis, the frontier with an inline chart, the calibration and
  the decision table, plus the standing scope caveats. No external stylesheet,
  script, font or image, and byte-deterministic unless a timestamp is supplied.
  Reachable as `certification_report()` / `write_report()` and `certlim report`.
- `Experiment.fingerprint()`, a stable digest of the registered laws for audit
  trails.
- `Experiment.collision_pairs()` and `delta(exact=...)`.
- The CLI ignores non-numeric metadata columns instead of failing on them, and
  `--block-col` is available on every subcommand.

## 0.1.0

First release.

- `Experiment`: registered safe/unsafe classes over one evidence alphabet, with
  `delta`, `decisiveness`, `bound`, `margin`, `gate`, `n_star`, `diagnose`.
- `frontier`: the frontier over a grid, with `bound_holds`, `is_monotone` and
  `units_for`.
- `build_rule`: the deployable randomised Certify / Alert / Reject rule.
- `NestedQuantizer`, `coarsen_counts`, `check_data_processing`.
- `permutation_test`, `bootstrap_delta`: whole-unit calibration.
- `transport_margin`, `class_drift`; `screen`, `Plan`.
- `certlim` CLI with `diagnose`, `frontier`, `calibrate`, `rule`.
