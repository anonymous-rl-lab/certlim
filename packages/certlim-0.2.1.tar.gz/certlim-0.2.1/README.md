# certlim

**How often can a battery test give a decision when false approval and false rejection have separate budgets?** `certlim` compares measurement channels, constructs a three-action rule (approve, reject, or refer for reference testing), and bounds the performance achievable by any rule on the same registered task. A second workflow audits a frozen capacity screen on held-out records and reports the reference-discharge hours associated with its decisions.

Python 3.10+ · NumPy and SciPy · MIT-licensed code. The installed examples run offline.

```sh
pip install certlim
certlim design --nasa --n 5 --target 0.243 --rules rules.json
certlim recheck rules.json --nasa
certlim audit --example cetl --inference iid
certlim audit --example relib
certlim audit --example leaf --target 0.20
```

## Decide whether to record the current band

In the NASA example, each registered object is a cell stage under a bench policy. Both channels observe the cutoff event. The richer channel also records the low/high current band. A common set of probability intervals determines each object's risk grade and its possible evidence laws. Risk at most 0.15 qualifies as safe, and risk at least 0.35 qualifies as unsafe. Intervals crossing a grade boundary leave an object unresolved.

```python
from certlim import design_measurement, evaluate_rule, nasa_likelihood_ratio_rule, nasa_registry

registry = nasa_registry()
result = design_measurement(registry, n=5, alpha=0.05, beta=0.05, target=0.243)
print(result.counts)                    # 1539 registered, 26 safe, 250 unsafe, 1263 unresolved
print(result.status)                    # additional_band_required
print(round(100 * result.event.upper, 3))       # 24.179
print(round(100 * result.band_event.lower, 3))  # 24.367

lookup = result.band_event.rule
pc, pr, pa = lookup.probabilities([2, 1, 2, 0])
simple = evaluate_rule(nasa_likelihood_ratio_rule(), registry)
gap_pp = 100 * (result.band_event.upper - simple.decisiveness_lower)
print(round(gap_pp, 6))                 # 0.002233 percentage points (rounded)
```

The 24.30% target is illustrative. The cutoff-only **upper** bound falls below it, while the **lower** bound attained by an executable band-plus-cutoff rule exceeds it. The likelihood-ratio comparison also bounds what further rule complexity could buy. These are worst-case decisions over the 276 gradeable objects under five conditionally independent readings from one fixed model. The two error budgets apply per attempted block within each grade, including referrals.

**Bring a registry.** Use `certlim design --registry models.csv --n 5 --target 0.30`. Each row supplies a fixed high-band mass and joint event mass intervals in the two bands. In the following row the event risk ranges from 0.03 to 0.13, and the band masses are 0.60 and 0.40.

```csv
model,q_high,low_lo,low_hi,high_lo,high_hi
lot_A,0.40,0.01,0.05,0.02,0.08
lot_B,0.40,0.21,0.31,0.18,0.30
```

For each block, the same model and the same point in its rectangle generate all readings. The solver uses nonnegative tensor Bernstein coefficients to protect the whole rectangle, audits the resulting action probabilities, and computes an upper bound from attainable fixed laws and the LP dual. It reports floating-point bounds. A wide gap or a missing grade remains visible. Bounds are conditional on supplied intervals. `registry_from_counts` constructs simultaneous exact-binomial rectangles for a fixed registry and sampling horizon, including fully unknown empty strata. The bundled NASA registry uses the paper's stage-wise confidence procedure. The source identities are recorded in `certlim/data/sources.csv`.

**Recheck a frozen rule.** `certlim recheck rules.json --registry new_models.csv` holds the lookup, symbol order, grade thresholds and error budgets fixed while evaluating target rectangles. The exported JSON carries a content checksum and a source-registry fingerprint. Rechecking reports the target fingerprint and both grade denominators. Exports using `certlim.band-rule.v2` also freeze the minimum decision rate. For a deployment requiring all three bounds, read `joint_status`. The value `joint_requirements_certified` requires both error upper bounds to meet their budgets and the worst-case decision lower bound to reach the frozen target. `error_budgets_met` and `target_met` show the two checks separately. The legacy `status` field covers the error budgets only. When rechecking a v1 export, supply its intended decision threshold via `--target` to evaluate the joint requirement. With no threshold, v1 reports `target_met: null`. Risk grades in registry CSVs compare the supplied decimals exactly, including equality at either cutoff. The existing `transport_margin` interface evaluates the separate question of geometric separation.

## Audit a capacity screen before replacing a discharge

```sh
certlim audit --ledger heldout.csv --inference archive
certlim audit --ledger heldout.csv --inference iid --confidence 0.95 --target 0.30
```

Input CSV columns are `grade` (qualified, below, unknown) and frozen `action` (PASS, FAIL, REFER). Each row can also give `count` (default 1) and `reference_hours`, the total reference-discharge hours for that row or group. Missing reference labels stay in the action totals. A grade with zero observations has an unevaluable error rate. An unrecorded workload stays unknown.

| Installed case | Decision and denominator | Result reproduced from v25 |
|---|---|---|
| CETL | Screen after charging. Compare frozen A (initial voltage) and B (charge trajectory). | B decides on 484/1,057 complete records. Its smaller grade-specific decision fraction is 41.97%, or 30.77% across all 1,400 assigned records. B's complete-case error upper limits under within-grade independent sampling are 4.9951% and 3.3557%. |
| ReLiB | Apply the frozen CETL-B rule to the 15.5 Ah archive. The original 1,024 records are included in the census. | Of 6,909 records, 5,358 are rejected. Of 6,907 known qualified records, 5,356 are falsely rejected. Two lack a reference grade; the below-spec side is unobserved. |
| Leaf | A separate method validation on eight units from two donor packs. Compare schedules on matching visits. | The prior-capacity schedule decides on 31/41 optional visits, or 31/88 including mandatory anchors. The secondary same-visit charge schedule decides on 65/88. Their decided visits correspond to 406.92 and 850.98 recorded discharge-channel hours. |

Archive mode gives direct counts and empirical rates. Within-grade independent sampling must be justified to use `--inference iid`. Without a decision target, the two one-sided error bounds share the confidence budget. With `--target`, two additional grade-specific decision-rate lower bounds share the same familywise budget across **four** bounds. Results then report the joint acceptance status. The allocation covers one frozen rule in one specified cohort. Grouping repeated records into rows supplies counts; it does not establish physical independence. In the examples the reference discharges were performed, and hours describe retrospective workload.

The wheel contains sufficient grade/action summaries for these audits and the NASA measurement-design inputs. Raw waveforms, fitted capacity predictors and the row-by-row experimental replay are in the companion TII v25 code package. Capabilities for general finite-alphabet point laws, delayed separation and measurement menus follow below.

## Finite-alphabet experiments


```python
import certlim as cl

# Two safe populations and one unsafe one, over a two-symbol evidence alphabet.
exp = cl.Experiment(safe=[[0.25, 0.75], [0.75, 0.25]],
                    unsafe=[[0.50, 0.50]])

d = exp.diagnose()
print(d.region)            # 'delayed'
print(d.n_star)            # 2
print(d.explain())
```

> Delayed separation: the one-unit hulls intersect but no exact pair collides,
> so repetition alone opens the gate at n = 2. Buying more of the same evidence
> is the correct move here.

Note what just happened. Every safe/unsafe **pair** in this example is well
separated — the minimum pairwise total variation is `0.25` — yet one unit of
evidence certifies nothing at all:

```python
exp.pairwise_min_tv()      # 0.25   "looks separable"
exp.delta(1)               # 0.0    actually is not
exp.decisiveness(1)        # 0.10 = alpha + beta, i.e. no better than a coin
exp.delta(2)               # 0.125  two units break the tie
```

A criterion built on pairwise distances would have declared success here. The
composite geometry is what governs, and it is what `certlim` computes.

---

## The frontier

```python
f = cl.frontier(exp, n_grid=[1, 2, 3, 5, 10], alpha=0.05, beta=0.05)
print(f)
```

```
   n   states     Delta         D     bound     slack  gate
   1        2  0.000000  0.100000  0.100000  0.000000     1
   2        3  0.125000  0.112500  0.225000  0.112500     0
   3        4  0.187500  0.116667  0.287500  0.170833     0
   5        6  0.273438  0.138889  0.373438  0.234549     0
  10       11  0.409561  0.196970  0.509561  0.312591     0
```

`Delta` is the composite separation, `D` the best worst-case decisiveness any
valid rule attains, `bound` the ceiling `min(1, alpha + beta + Delta)`, and
`gate` flags block lengths where the two hulls still meet.

`f.units_for(0.9)` returns the smallest gridded block reaching 90 % decisiveness,
or `None` if the grid does not get there.

---

## The deployable rule

```python
rule = cl.build_rule(exp, n=3, alpha=0.05, beta=0.05)
rule.decisiveness          # what it actually attains
rule.alert_rate_floor()    # the fraction of blocks that must come back Alert

decision = rule.decide([2, 1], rng=np.random.default_rng(7))
decision.outcome           # 'certify' | 'alert' | 'reject'

rule.error_profile(exp)    # realised worst-case side errors, self-check
```

The optimal rule is genuinely randomised, so pass a seeded generator whenever the
verdict has to be reproducible — in a certification workflow it usually does.

When the hulls still intersect, the optimum is a rule that **ignores the data**
and answers at the allowed error rates. `certlim` says so plainly rather than
dressing it up. Use the separation diagnosis to check whether a larger block or a different measurement can open the gate.

---

## From raw measurements

Start from per-unit symbol counts, one row per physical unit:

```python
exp = cl.Experiment.from_counts(safe_counts, unsafe_counts, smoothing=0.5)
```

Building the evidence menu is where most mistakes happen, so the quantiser
enforces the one property that makes menus comparable:

```python
q = cl.NestedQuantizer.from_quantiles(features, bins=2, drop_order=(2, 1))
q.chain()                  # [8, 4, 2] — strictly nested, by construction
counts = q.counts(features, level=0)
```

Quantising each menu independently produces partitions that are **not** nested,
and the resulting comparison can show a coarse menu beating its own refinement.
That is a pipeline artefact. `cl.check_data_processing(fine, coarse)` will tell
you when you have hit it.

---

## Finite-sample calibration

A plug-in `Delta` from observed counts is an estimate:

```python
cl.permutation_test(unit_counts, labels, blocks=chemistry, n_permutations=999)
cl.bootstrap_delta(unit_counts, labels, n_resamples=2000)
```

Both resample **whole physical units**. Resampling rows, cycles or time points
instead will understate the interval and inflate significance by orders of
magnitude, because repeated measurements of one unit are not independent
evidence about the population of units.

Neither is a lower confidence bound on the population separation. A significant
permutation p-value rejects label exchangeability; it does not certify anything
with coverage. `certlim` keeps that distinction in the result objects.

---

## Deployment and procurement

```python
report = cl.transport_margin(source_exp, deployment_exp)
report.certified           # separation survives the registered shift?
```

The margin is `Delta_source - drift_safe - drift_unsafe`, measured as class
geometry rather than point-prediction error. A non-positive margin means the
source evidence does not certify transport — not that the deployment domain
collides.

```python
cl.screen([
    cl.Plan("passive",   n=1, decisiveness=0.63, cost={"seconds": 780, "c_rate": 0.0}),
    cl.Plan("active",    n=1, decisiveness=0.53, cost={"seconds": 940, "c_rate": 0.5}),
    cl.Plan("nameplate", n=6, decisiveness=0.10, cost={"seconds": 0,   "c_rate": 0.0}),
], target=0.4)
```

Costs stay a vector and are never collapsed into one currency. A plan is dropped
only when another is no worse on every recorded axis. Plans measured on
different ledgers raise rather than being ranked — an unmeasured cost is not a
free cost.

---

## The report

One command turns the whole analysis into a filing-ready page:

```bash
certlim report units.csv -o certification.html --subject "Lot 2026-08"
```

```python
cl.write_report("certification.html", exp,
                unit_counts=counts, labels=labels, blocks=site,
                subject="Lot 2026-08",
                notes=("Grades come from the bench protocol, not from this channel.",))
```

The page carries the structural verdict and the action it implies, the frontier
as a table and an inline chart, the finite-sample calibration, the decision table
and the standing scope caveats. It is a single file with no external stylesheet,
script, font or image, so it survives being archived or opened offline, and it is
byte-deterministic unless you pass a `timestamp` — two runs of the same analysis
produce the same file, and a diff means something actually changed.

## Command line

```bash
certlim diagnose  units.csv                          # permanent, delayed, or open?
certlim frontier  units.csv --n 1 2 3 5 10 --target 0.9
certlim calibrate units.csv --block-col chemistry
certlim rule      units.csv --n 3 --json rule.json
certlim report    units.csv -o certification.html
```

Input is either a CSV of per-unit counts with a `grade` column holding `safe` /
`unsafe`, or a JSON file of probability laws:

```json
{"safe": [[0.25, 0.75], [0.75, 0.25]], "unsafe": [[0.5, 0.5]]}
```

For count CSVs, the default evidence columns are the `s0`, `s1`, … fields in header order, or the pair `x,y`. For other names or a different order, pass the schema explicitly, for example `certlim diagnose units.csv --evidence-cols cutoff no_cutoff`. Numeric identifiers and remaining metadata are excluded. The machine-readable output names the selected columns. Use `--json out.json` for computations and `report -o out.html` for the HTML report. Each output needs a distinct path.

---

## What certlim does not do

Geometry is computed on the supplied population laws using floating-point arithmetic. A precision or search limit can leave separation unresolved. It does **not** know whether:

- your two classes were registered before you looked at the data;
- your grades were identified by a reference experiment rather than by the
  channel you are evaluating — grading units with the channel under test makes
  every number here meaningless;
- your sampling unit is the physical unit it should be;
- your evidence is conditionally i.i.d. within a block;
- your registered models are cohorts rather than individual units. If each model
  is one physical unit, two units can produce identical histograms by chance,
  which is an exact collision by definition. `certlim` flags that case rather
  than letting it read as a structural obstruction, but it cannot decide for you
  how the classes should have been registered.

Those are design decisions and the package will not make them for you. Every
result is relative to the registered classes: enlarging them can only shrink the
separation, never grow it.

---

## Method notes

Block laws are enumerated over count vectors, the sufficient statistic for i.i.d.
draws from a finite alphabet, so the problem is `C(n+K-1, K-1)` rather than
`K**n`. The composite distance and the optimal decision rule are solved as two
**independent** linear programs, so their agreement with the certification bound
is a real check rather than a same-code identity. There is no sampling, no
fitting and no tuning parameter anywhere in the core.

`delta()` is solved through the dual separation game, which is 10x to 450x
faster than the primal hull program on large state spaces. The dual loses
accuracy as the space grows, and a value near zero is exactly where the gate
verdict turns, so anything below `1e-5` is re-solved with the exact program;
`delta(n, exact=True)` forces it everywhere.

Exact enumeration has a ceiling (`max_states`, default 20 000). It is a **time**
budget, not a memory one — measured cost is about 3 s at 6 000 states, 40-100 s
at 20 000, and hours beyond, with run-to-run variation of a factor of two at the
same size. Exceeding it raises with the offending `(K, n)` and what to do about
it, rather than silently approximating or starting a job that never finishes.

For a finite registered class with `r` distinct one-unit laws and no exact
collision, the gate must be open by `r - 1`; `Experiment.stopping_bound()`
returns it, and `n_star()` searches exhaustively up to it. The bound is tight for
small classes and loose for large ones, and it bounds the *structural* search
only — never the number of physical units needed for a confidence statement.

## Licence

MIT for software. Data credits, source digests and reuse notices are in the installed data directory.
